namespace website.Web.Models // Aseg�rate que el namespace coincida con tu proyecto
{
    public class Servicio
    {
        public string Titulo { get; set; } = "";
        public string Descripcion { get; set; } = "";
        public string Icono { get; set; } = "";
        public string ColorClase { get; set; } = ""; // Para diferenciar por colores
        public List<string> Especialidades { get; set; } = new();
        public string VentajaTexto { get; set; } = "";
    }
}
