﻿using Microsoft.Extensions.DependencyInjection;
using website.ServiceDefaults.Interface;
using website.ServiceDefaults.Service;

namespace website.ServiceDefaults
{
    public static class ConfigureServices
    {
        /// <summary>
        /// Adds all the dependency injection of the services used in the Application Layer
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            services.AddScoped<IEmailService, EmailService>();       
            return services;
        }
    }
}
