﻿using MedfarLabs.Core.Domain.Extensions;

namespace Domain.UnitTests.Extensions
{
    [TestFixture]
    public class JsonStringExtensionsTests
    {
        private const string ValidJson = "{\"provider_url\":\"https://retrieval.jumio.ai/test\",\"customer_number\":\"806570\"}";
        private const string InvalidJson = "{ invalid json }";
        private const string MissingPropertyJson = "{\"customer_number\":\"806570\"}";

        #region Tests para ExtractProviderUrl

        [Test]
        [Description("Debe extraer la URL correctamente de un JSON válido")]
        public void ExtractProviderUrl_WithValidJson_ReturnsUrl()
        {
            // Act
            var result = ValidJson.ExtractData("provider_url");

            // Assert
            Assert.That(result, Is.EqualTo("https://retrieval.jumio.ai/test"));
        }

        [Test]
        [Description("Debe retornar string.Empty si la propiedad no existe en el JSON")]
        public void ExtractProviderUrl_WithMissingProperty_ReturnsEmpty()
        {
            // Act
            var result = MissingPropertyJson.ExtractData("customer_number");

            // Assert
            Assert.That(result, Is.EqualTo("806570"));
        }

        [Test]
        [TestCase(null)]
        [TestCase("")]
        [TestCase("   ")]
        [Description("Debe manejar correctamente entradas nulas o con espacios")]
        public void ExtractProviderUrl_WithNullOrEmpty_ReturnsEmpty(string? input)
        {
            // Act
            var result = input?.ExtractData("") ?? string.Empty;

            // Assert
            Assert.That(result, Is.Empty);
        }       
        #endregion

        #region Tests para GetJsonValue (Genérico)

        [Test]
        [TestCase("customer_number", "806570")]
        [TestCase("provider_url", "https://retrieval.jumio.ai/test")]
        [Description("Debe extraer cualquier propiedad string solicitada")]
        public void GetJsonValue_WithExistingProperty_ReturnsValue(string property, string expected)
        {
            // Act
            var result = ValidJson.GetJsonValue(property);

            // Assert
            Assert.That(result, Is.EqualTo(expected));
        }

        [Test]
        [Description("Debe retornar vacío si se busca una propiedad que no existe")]
        public void GetJsonValue_WithNonExistingProperty_ReturnsEmpty()
        {
            // Act
            var result = ValidJson.GetJsonValue("non_existent_key");

            // Assert
            Assert.That(result, Is.Empty);
        }

        [Test]
        [Description("Debe retornar vacío si el JSON es inválido")]
        public void GetJsonValue_WithInvalidJson_ReturnsEmpty()
        {
            // Act
            var result = InvalidJson.GetJsonValue("any_property");

            // Assert
            Assert.That(result, Is.Empty);
        }

        #endregion
    }
}
