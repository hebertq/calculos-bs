﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;

namespace IntegrationTests
{
    public class RepositoryTestEntryPoint
    {
        // Este método es el que busca WebApplicationFactory por reflexión
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    // Le damos una configuración vacía, solo para que el Host se cree
                    webBuilder.Configure(app => { });
                });
    }
}
