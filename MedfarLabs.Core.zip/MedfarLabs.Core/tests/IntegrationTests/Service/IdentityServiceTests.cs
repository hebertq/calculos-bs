﻿using Microsoft.Extensions.DependencyInjection;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using SharedFakers.Fakers.Identity;

namespace IntegrationTests.Service
{
    [TestFixture]
    public class IdentityServiceTests : IntegrationTestBase
    {
        private IIdentityService _service;

        [SetUp]
        public void Init() => _service = ServiceProvider.GetRequiredService<IIdentityService>();

        [Test]
        public async Task RegistrarOrganizacion_DebePersistirCorrectamente()
        {
            // ARRANGE
            var request = FakerOrganization.Create.Generate();

            // ACT
            var result = await _service.RegistrarOrganizacionAsync(request);

            // ASSERT
            Assert.Multiple(() =>
            {
                Assert.That(result.IsSuccess, Is.True);
                Assert.That(result.Data, Is.GreaterThan(0));
                Assert.That(result.Message, Does.Contain("exitosamente"));
            });
        }

        [Test]
        public async Task RegistrarPersona_DebePersistirConHashBiometrico()
        {
            // ARRANGE
            var request = FakerPerson.Create.Generate();

            // ACT
            var result = await _service.RegistrarPersonaAsync(request);

            // ASSERT
            Assert.Multiple(() =>
            {
                Assert.That(result.IsSuccess, Is.True);
                Assert.That(result.Data, Is.GreaterThan(0));
            });
        }
    }
}
