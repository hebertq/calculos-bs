﻿using Microsoft.Extensions.DependencyInjection;
using MedfarLabs.Core.Application.Features.Care.Interfaces;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;
using MedfarLabs.Core.Application.Features.Identity.Dtos.Request;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using SharedFakers.Fakers.Care;
using SharedFakers.Fakers.Identity;

namespace IntegrationTests.Service
{
    [TestFixture]
    public class MedicalCareServiceTests : IntegrationTestBase
    {
        private IMedicalCareService _careService;
        private IIdentityService _identityService;
        private IClinicalService _clinicalService;

        [SetUp]
        public void Init()
        {
            _careService = ServiceProvider.GetRequiredService<IMedicalCareService>();
            _identityService = ServiceProvider.GetRequiredService<IIdentityService>();
            _clinicalService = ServiceProvider.GetRequiredService<IClinicalService>();
        }

        [Test]
        public async Task RegistrarConsulta_DebeGuardarDatosSOAP()
        {
            // 1. ARRANGE: Crear el escenario completo para evitar errores de FK
            var orgId = (await _identityService.RegistrarOrganizacionAsync(FakerOrganization.Create.Generate())).Data;
            var personId = (await _identityService.RegistrarPersonaAsync(FakerPerson.Create.Generate())).Data;

            // Registrar Médico
            var doctorId = (await _identityService.RegistrarUsuarioAsync(new UsuarioRequestDTO
            {
                PersonId = personId,
                OrganizationId = orgId
            })).Data;

            // Registrar Paciente y Expediente
            var patientId = (await _clinicalService.RegistrarPacienteAsync(new PatientRequestDTO
            {
                PersonId = personId,
                OrganizationId = orgId,
                InternalCode = "SOAP-TEST"
            })).Data;

            var recordId = (await _clinicalService.RegistrarExpedienteMedicoAsync(new MedicalRecordRequestDTO
            {
                PatientId = patientId,
                RecordNumber = "EXP-SOAP-001"
            })).Data;

            // Generar request con datos SOAP específicos
            var request = FakerConsultation.Create.Generate() with
            {
                MedicalRecordId = recordId,
                DoctorUserId = doctorId
            };

            // 2. ACT
            var result = await _careService.RegistrarConsultaMedicaAsync(request);

            // 3. ASSERT
            Assert.Multiple(() =>
            {
                Assert.That(result.IsSuccess, Is.True, "El servicio falló al registrar");
                Assert.That(result.Data, Is.GreaterThan(0), "No se generó un ID válido");
            });
        }
    }
}
