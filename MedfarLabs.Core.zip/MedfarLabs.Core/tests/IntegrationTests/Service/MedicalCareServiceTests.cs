﻿using Microsoft.Extensions.DependencyInjection;
using MedfarLabs.Core.Application.Features.Care.Interfaces;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;
using MedfarLabs.Core.Application.Features.Identity.Dtos.Request;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using SharedFakers.Fakers.Care;
using SharedFakers.Fakers.Identity;
using MedfarLabs.Core.Application.Features.Common.Interfaces;
using Moq;
using MedfarLabs.Core.Domain.Enums;
using static Org.BouncyCastle.Crypto.Engines.SM2Engine;

namespace IntegrationTests.Service
{
    [TestFixture]
    public class MedicalCareServiceTests : IntegrationTestBase
    {
        private IMedicalCareService _careService;
        private IIdentityService _identityService;
        private IClinicalService _clinicalService;
        private ICatalogService _cat;

        [SetUp]
        public void Init()
        {
            _careService = ServiceProvider.GetRequiredService<IMedicalCareService>();
            _identityService = ServiceProvider.GetRequiredService<IIdentityService>();
            _clinicalService = ServiceProvider.GetRequiredService<IClinicalService>();
            _cat = ServiceProvider.GetRequiredService<ICatalogService>();
        }

        /// <summary>
        /// Helper para crear el escenario base de Identidad y Clínica
        /// </summary>
        private async Task<(long orgId, long doctorId, long patientId, long recordId)> CreateBaseScenario()
        {
            var orgId = (await _identityService.RegistrarOrganizacionAsync(FakerOrganization.Create.Generate())).Data;
            var personId = (await _identityService.RegistrarPersonaAsync(FakerPerson.Create.Generate())).Data;

            var doctorId = (await _identityService.RegistrarUsuarioAsync(new UsuarioRequestDTO
            {
                PersonId = personId,
                OrganizationId = orgId,
                Username = "doc_" + Guid.NewGuid().ToString("N")[..8],
                Password = "SecurePassword123"
            })).Data;

            var patientId = (await _clinicalService.RegistrarPacienteAsync(new PatientRequestDTO
            {
                PersonId = personId,
                OrganizationId = orgId,
                InternalCode = "P-" + Guid.NewGuid().ToString("N")[..5]
            })).Data;

            var recordId = (await _clinicalService.RegistrarExpedienteMedicoAsync(new MedicalRecordRequestDTO
            {
                PatientId = patientId,
                RecordNumber = "REC-" + Guid.NewGuid().ToString("N")[..5]
            })).Data;

            return (orgId, doctorId, patientId, recordId);
        }

        [Test]
        public async Task RegistrarConsulta_DebeGuardarDatosSOAP()
        {
            // 1. ARRANGE: Crear el escenario completo para evitar errores de FK
            var scenario = await CreateBaseScenario();           

            // Generar request con datos SOAP específicos
            var request = FakerConsultation.Create.Generate() with
            {
                MedicalRecordId = scenario.recordId,
                DoctorUserId = scenario.doctorId
            };

            // 2. ACT
            var result = await _careService.RegistrarConsultaMedicaAsync(request);

            // 3. ASSERT
            Assert.Multiple(() =>
            {
                Assert.That(result.IsSuccess, Is.True, "El servicio falló al registrar");
                Assert.That(result.Data, Is.GreaterThan(0), "No se generó un ID válido");
            });
        }

        [Test]
        public async Task EmitirReceta_DebeSerExitosa_PersistiendoEnBaseDeDatos()
        {
            // 1. ARRANGE: Crear dependencias reales para evitar fallos de FK
            var scenario = await CreateBaseScenario();

            // Creamos una consulta previa para vincular la receta (opcional según DB, pero recomendado)
            var consultationRequest = FakerConsultation.Create.Generate() with
            {
                MedicalRecordId = scenario.recordId,
                DoctorUserId = scenario.doctorId
            };
            var consultationId = (await _careService.RegistrarConsultaMedicaAsync(consultationRequest)).Data;

            var request = FakerPrescription.Create.Generate() with
            {
                ConsultationId = consultationId,
                PatientId = scenario.patientId,
                UserId = scenario.doctorId, // Doctor que emite
                OrganizationId = scenario.orgId
            };

            // 2. ACT
            var result = await _careService.EmitirRecetaAsync(request);

            // 3. ASSERT
            Assert.Multiple(() =>
            {
                Assert.That(result.IsSuccess, Is.True, result.Message);
                Assert.That(result.Data, Is.GreaterThan(0), "No se generó el ID de la receta");
            });
        }

        [Test]
        public async Task RegistrarAntecedente_DebeAlmacenarEnBaseDeDatos()
        {
            // 1. ARRANGE
            var dataTypeId = await _cat.GetItemByCodeAsync(CatalogType.AntecedentType, "FAM");
            if (dataTypeId is not null)
            {
                var scenario = await CreateBaseScenario();
                var request = FakerAntecedent.Create.Generate() with
                {
                    PatientId = scenario.patientId,
                    UserId = scenario.doctorId, // Auditoría
                    TypeId = dataTypeId.Id
                };

                // 2. ACT
                var result = await _clinicalService.RegistrarAntecedenteAsync(request);

                // 3. ASSERT
                Assert.Multiple(() =>
                {
                    Assert.That(result.IsSuccess, Is.True, result.Message);
                    Assert.That(result.Data, Is.GreaterThan(0), "No se generó el ID del antecedente");
                });
            }          
        }
    }
}
