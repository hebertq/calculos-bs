﻿using Microsoft.Extensions.DependencyInjection;
using MedfarLabs.Core.Application.Features.Care.Interfaces;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;
using MedfarLabs.Core.Application.Features.Identity.Dtos.Request;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using MedfarLabs.Core.Application.Features.Inventory.Interfaces;
using MedfarLabs.Core.Application.Features.Laboratory.Dtos.Request;
using MedfarLabs.Core.Application.Features.Laboratory.Interfaces;
using SharedFakers.Fakers.Care;
using SharedFakers.Fakers.Identity;
using SharedFakers.Fakers.Inventory;
using SharedFakers.Fakers.Laboratory;

namespace IntegrationTests.Service
{
    [TestFixture]
    public class LaboratoryServiceTests : IntegrationTestBase
    {
        private ILaboratoryService _laboratoryService;
        private IIdentityService _identityService;
        private IInventoryService _inventoryService;
        private IClinicalService _clinicalService;
        private IMedicalCareService _careService;

        [SetUp]
        public void Init()
        {
            // Inyectamos todos los servicios necesarios para el flujo completo
            _laboratoryService = ServiceProvider.GetRequiredService<ILaboratoryService>();
            _identityService = ServiceProvider.GetRequiredService<IIdentityService>();
            _inventoryService = ServiceProvider.GetRequiredService<IInventoryService>();
            _clinicalService = ServiceProvider.GetRequiredService<IClinicalService>();
            _careService = ServiceProvider.GetRequiredService<IMedicalCareService>();
        }

        [Test]
        public async Task RegistrarResultado_DebeAlmacenarDatosTecnicosJson()
        {
            // 1. ARRANGE: Construcción de la jerarquía clínica

            // Organización y Servicio
            var org = await _identityService.RegistrarOrganizacionAsync(FakerOrganization.Create.Generate());
            var service = await _inventoryService.RegistrarServicioAsync(FakerInventory.Create.Generate() with { OrganizationId = org.Data });

            // Paciente y su Expediente
            var person = await _identityService.RegistrarPersonaAsync(FakerPerson.Create.Generate());
            var patient = await _clinicalService.RegistrarPacienteAsync(new PatientRequestDTO { PersonId = person.Data, OrganizationId = org.Data });
            var record = await _clinicalService.RegistrarExpedienteMedicoAsync(new MedicalRecordRequestDTO { PatientId = patient.Data, RecordNumber = "EXP-TEST-LAB" });

            // Médico y Usuario (Necesario para la FK de la consulta)
            var docPers = await _identityService.RegistrarPersonaAsync(FakerPerson.Create.Generate());
            var docUser = await _identityService.RegistrarUsuarioAsync(new UsuarioRequestDTO
            {
                PersonId = docPers.Data,
                OrganizationId = org.Data,
            });

            // Consulta Médica
            var consult = await _careService.RegistrarConsultaMedicaAsync(FakerConsultation.Create.Generate() with
            {
                MedicalRecordId = record.Data,
                DoctorUserId = docUser.Data
            });

            // Orden de Laboratorio (Vínculo final antes del resultado)
            var orderRequest = FakerLabOrder.Create.Generate() with
            {
                ConsultationId = consult.Data,
                PatientId = patient.Data,
                ServiceId = service.Data
            };
            var orderRes = await _laboratoryService.RegistrarOrdenAsync(orderRequest);
            long orderIdReal = orderRes.Data;

            // 2. ACT: Registro del resultado JSON
            var resultRequest = new LabResultRequestDTO
            {
                LabOrderId = orderIdReal,
                TechnicalDataJson = "{\"hemoglobina\": 14.5, \"leucocitos\": 7500}",
                Observations = "Valores dentro del rango normal",
                AuditNotes = "Test de integración"
            };

            var result = await _laboratoryService.RegistrarResultadoAsync(resultRequest);

            // 3. ASSERT
            Assert.Multiple(() =>
            {
                Assert.That(result.IsSuccess, Is.True, $"Error reportado: {result.Message}");
                Assert.That(result.Data, Is.GreaterThan(0), "El ID del resultado debería ser generado por la DB");
            });
        }
    }
}
