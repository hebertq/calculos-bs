﻿using Microsoft.Extensions.DependencyInjection;
using MedfarLabs.Core.Application.Features.Billing.Interfaces;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using MedfarLabs.Core.Application.Features.Inventory.Interfaces;
using SharedFakers.Fakers.Billing;
using SharedFakers.Fakers.Identity;
using SharedFakers.Fakers.Inventory;

namespace IntegrationTests.Service
{
    [TestFixture]
    public class BillingServiceTests : IntegrationTestBase
    {
        private IBillingService _billingService;
        private IIdentityService _identityService;
        private IInventoryService _inventoryService;

        [SetUp]
        public void Init()
        {
            _billingService = ServiceProvider.GetRequiredService<IBillingService>();
            _identityService = ServiceProvider.GetRequiredService<IIdentityService>();
            _inventoryService = ServiceProvider.GetRequiredService<IInventoryService>();
        }

        [Test]
        public async Task GenerarFactura_DebeSerExitosaConItems()
        {
            // 1. ARRANGE: Preparar la infraestructura mínima
            // Registramos la organización
            var org = await _identityService.RegistrarOrganizacionAsync(FakerOrganization.Create.Generate());
            long orgId = org.Data;

            // Registramos al menos un servicio en el inventario para poder facturarlo
            var serviceRequest = FakerInventory.Create.Generate() with { OrganizationId = orgId };
            var serviceResult = await _inventoryService.RegistrarServicioAsync(serviceRequest);
            long serviceId = serviceResult.Data;

            // ID de paciente (lo ideal es registrar uno real, pero usemos el dummy por ahora)
            long dummyPatientId = 1;

            // 2. GENERAR REQUEST: Ahora pasamos los 3 parámetros requeridos
            var request = FakerBilling.Create(orgId, dummyPatientId, serviceId).Generate();

            // 3. ACT
            var result = await _billingService.GenerarFacturaAsync(request);

            // 4. ASSERT
            Assert.Multiple(() =>
            {
                Assert.That(result.IsSuccess, Is.True, $"Error: {result.Message}");
                Assert.That(result.Data, Is.GreaterThan(0), "El ID de la factura debe ser generado");
            });
        }
    }
}
