﻿using Microsoft.Extensions.DependencyInjection;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using MedfarLabs.Core.Application.Features.Inventory.Interfaces;
using SharedFakers.Fakers.Identity;
using SharedFakers.Fakers.Inventory;

namespace IntegrationTests.Service
{
    [TestFixture]
    public class InventoryServiceTests : IntegrationTestBase
    {
        private IInventoryService _inventoryService;
        private IIdentityService _identityService;

        [SetUp]
        public void Init()
        {
            _inventoryService = ServiceProvider.GetRequiredService<IInventoryService>();
            _identityService = ServiceProvider.GetRequiredService<IIdentityService>();
        }

        [Test]
        public async Task RegistrarServicio_DebePersistirCorrectamente()
        {
            // 1. ARRANGE
            var orgResult = await _identityService.RegistrarOrganizacionAsync(FakerOrganization.Create.Generate());

            // CORRECCIÓN: Acceso a propiedad .Create y uso de 'with' para el ID
            var request = FakerInventory.Create.Generate() with
            {
                OrganizationId = orgResult.Data
            };

            // 2. ACT
            var result = await _inventoryService.RegistrarServicioAsync(request);

            // 3. ASSERT
            Assert.Multiple(() =>
            {
                Assert.That(result.IsSuccess, Is.True, result.Message);
                Assert.That(result.Data, Is.GreaterThan(0));
                Assert.That(result.Message, Does.Contain("correctamente").Or.Contains("exitosamente"));
            });
        }

        [Test]
        public async Task ObtenerServicios_DebeRetornarListaPorOrganizacion()
        {
            // 1. ARRANGE
            var orgResult = await _identityService.RegistrarOrganizacionAsync(FakerOrganization.Create.Generate());

            // Usamos el SeedAsync que ya maneja internamente el bucle y el 'with'
            await FakerInventory.SeedAsync(_inventoryService, orgResult.Data, count: 5);

            // 2. ACT
            var result = await _inventoryService.ObtenerServiciosPorOrganizacionAsync(orgResult.Data);

            // 3. ASSERT
            Assert.Multiple(() =>
            {
                Assert.That(result.IsSuccess, Is.True);
                Assert.That(result.Data, Is.Not.Null);
                Assert.That(result.Data!.Count(), Is.EqualTo(5));
            });
        }
    }
}
