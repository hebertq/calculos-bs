﻿using System.Text.Json;
using Amazon.Lambda.APIGatewayEvents;
using Amazon.Lambda.Core;
using Moq;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using IntegrationTests;

namespace MedfarLabs.Core.Tests.Integration.Strategies
{
    [TestFixture]
    public class RegistrarPersonaIntegrationTests : IntegrationTestBase
    {
        [Test]
        public async Task Debe_RetornarError_Cuando_EmailYaExisteEnBaseDeDatos()
        {
            // 1. ARRANGE
            var email = $"test.{Guid.NewGuid()}@salud.com"; // Email único por ejecución de test
            var personData = new
            {
                organization_id = 1,
                primer_nombre = "Juan",
                primer_apellido = "Pérez",
                correo = email,
                fecha_nacimiento = "1990-05-15",
                genero_id = 1,
                pais_nacimiento_id = 502,
                telefono = "12345678"
            };

            // Simulamos el objeto que AWS API Gateway enviaría a la Lambda
            var apiRequestWrapper = new
            {
                httpMethod = "POST",
                path = "/identity/person",
                headers = new Dictionary<string, string>
                {
                    { "X-App-Module", "Identity" },
                    { "X-App-Action", "RegistrarPersona" },
                    { "Content-Type", "application/json" }
                },
                body = JsonSerializer.Serialize(personData)
            };

            var jsonInput = JsonDocument.Parse(JsonSerializer.Serialize(apiRequestWrapper)).RootElement;
            var mockContext = new Mock<ILambdaContext>();
            mockContext.Setup(c => c.AwsRequestId).Returns(Guid.NewGuid().ToString());

            // 2. ACT - Intento 1 (Registro Exitoso)
            var response1 = (APIGatewayProxyResponse)await _handler.FunctionHandler(jsonInput, mockContext.Object);

            var result1 = JsonSerializer.Deserialize<BaseResponse<object>>(response1.Body,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            // ASSERT 1
            Assert.Multiple(() => {
                Assert.That(response1.StatusCode, Is.EqualTo(200), $"Error en primer intento: {response1.Body}");
                Assert.That(result1!.IsSuccess, Is.True);
            });

            // 3. ACT - Intento 2 (Fallo por Duplicado)
            // Re-utilizamos el mismo jsonInput (mismo email)
            var response2 = (APIGatewayProxyResponse)await _handler.FunctionHandler(jsonInput, mockContext.Object);

            var result2 = JsonSerializer.Deserialize<BaseResponse<object>>(response2.Body,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            // 4. ASSERT 2: Verificación de Regla de Negocio
            Assert.Multiple(() => {
                // El handler debe transformar el fallo de lógica en un 400 (BadRequest)
                Assert.That(response2.StatusCode, Is.EqualTo(400), "El status code debería ser 400 por error de validación.");
                Assert.That(result2!.IsSuccess, Is.False);
                Assert.That(result2.Errors, Does.Contain("Este correo ya está registrado (Email)"),
                    "No se encontró el mensaje de error de la regla de negocio.");
            });
        }
    }
}
