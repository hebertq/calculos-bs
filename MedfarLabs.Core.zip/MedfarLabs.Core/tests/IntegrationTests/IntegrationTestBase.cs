﻿using Amazon.SQS.Model;
using Amazon.SQS;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Migrations;
using Moq;
using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;
using MedfarLabs.Core.Domain.Interfaces.Security;
using SharedFakers.Infrastructure;
using SharedFakers.Seeders;
using Testcontainers.PostgreSql;
using MedfarLabs.Core.Application.Common.Dispatcher;
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;

namespace IntegrationTests
{
    public abstract class IntegrationTestBase
    {
        protected readonly PostgreSqlContainer _dbContainer = new PostgreSqlBuilder("postgres:15-alpine").Build();
        protected IActionDispatcher _dispatcher { get; private set; } = null!;
        protected UniversalHandler _handler { get; private set; } = null!;
        protected IServiceProvider ServiceProvider { get; private set; } = null!;

        [OneTimeSetUp]
        public virtual async Task OneTimeSetUp()
        {
            await _dbContainer.StartAsync();
            var connString = _dbContainer.GetConnectionString();

            var myConfiguration = new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string?>
                {
                    {"ConnectionStrings:DefaultConnection", connString},
                    {"Jwt:Key", "Clave32CaracteresExactos_123456"},
                    {"Polly:RetryCount", "3"},
                    // Agregamos estas para evitar nulos en HttpPolicies
                    {"HttpPolicies:RetryCount", "3"},
                    {"HttpPolicies:BaseDelaySeconds", "2"},
                    {"HttpPolicies:TimeoutSeconds", "10"}
                })
                .Build();

            Environment.SetEnvironmentVariable("JOBS_QUEUE_URL", "https://sqs.us-east-1.amazonaws.com/123456789/FakeQueue");
            Environment.SetEnvironmentVariable("EXECUTION_CONTEXT", "Main");
            MigratorHelper.Run(connString);

            var services = new ServiceCollection();
            // 1. MOCK DE SQS (Esto es lo que falta)
            // Usamos Moq para crear una instancia "de mentira" que no intente ir a AWS real
            var sqsMock = new Mock<IAmazonSQS>();

            // Configuramos para que siempre responda OK cuando se envíe un mensaje
            sqsMock.Setup(x => x.SendMessageAsync(It.IsAny<SendMessageRequest>(), It.IsAny<CancellationToken>()))
                   .ReturnsAsync(new SendMessageResponse
                   {
                       HttpStatusCode = System.Net.HttpStatusCode.OK,
                       MessageId = "mock-message-id"
                   });

            // Registramos el mock como Singleton para que QueueOutputAction lo encuentre
            services.AddSingleton<IAmazonSQS>(sqsMock.Object);
            // --- SOLUCIÓN AL ERROR DE ILoggerFactory ---
            services.AddLogging(); // Esto registra ILoggerFactory e ILogger<T>
            // --------------------------------------------

            services.AddInfrastructureServices(connString, "Clave32CaracteresExactos_123456", "SaltTest");
            services.AddInfrastructureServicesHost(myConfiguration);
            services.AddApplicationServices();
            services.AddActionDispatching();
            services.AddEventHandlers();

            services.AddScoped<MasterSeeder>();

            ServiceProvider = services.BuildServiceProvider();
        }

        [SetUp]
        public virtual async Task BeforeEachTest()
        {
            await DbCleaner.TruncateAllTables(ServiceProvider);
            using var scope = ServiceProvider.CreateScope();
            var seeder = scope.ServiceProvider.GetRequiredService<MasterSeeder>();
            await seeder.SeedAsync();

            var logger = ServiceProvider.GetRequiredService<ILogger<UniversalHandler>>();
            _dispatcher = ServiceProvider.GetRequiredService<IActionDispatcher>();
            _handler = new UniversalHandler(_dispatcher, logger);

            var userContext = ServiceProvider.GetRequiredService<IUserContext>();
            var securityCache = ServiceProvider.GetRequiredService<IGlobalSecurityCache>();
            var securityRepo = ServiceProvider.GetRequiredService<ISecurityRepository>();

            // 1. Forzar la carga de la matriz de permisos desde la DB a la RAM
            await securityCache.InitializeAsync(securityRepo);

            // 2. Inyectar la identidad del usuario que el Seeder creó
            // Asegúrate de que estos IDs existan en tu base de datos de test
            userContext.UserId = 1;
            userContext.OrganizationId = 1;
        }

        [OneTimeTearDown]
        public virtual async Task OneTimeTearDown()
        {
            // --- SOLUCIÓN A LA ADVERTENCIA DE DISPOSE ---
            if (ServiceProvider is IDisposable disposableProvider)
            {
                disposableProvider.Dispose();
            }

            if (_dbContainer != null)
            {
                await _dbContainer.StopAsync();
                await _dbContainer.DisposeAsync();
            }
        }
    }
}
