﻿using Bogus;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;
using SharedFakers.Fakers.Care;
using SharedFakers.Fakers.Identity;

namespace SharedFakers.Fakers.Clinical
{
    public static class FakerDirectAdmission
    {
        public static Faker<DirectAdmissionRequestDTO> Create => new Faker<DirectAdmissionRequestDTO>()
            .CustomInstantiator(f => new DirectAdmissionRequestDTO(
                FakerPerson.Create.Generate(),      // Genera Persona aleatoria
                f.Random.Replace("INT-#####"),      // Código de Paciente
                FakerConsultation.Create.Generate(),// Datos SOAP aleatorios
                null                                // Se asigna dinámicamente
            ));

        public static async Task SeedAsync(IClinicalService serv, long doctorId)
        {
            var request = Create.Generate() with { DoctorUserId = doctorId };
            await serv.CreateDirectAdmissionAsync(request);
        }
    }
}
