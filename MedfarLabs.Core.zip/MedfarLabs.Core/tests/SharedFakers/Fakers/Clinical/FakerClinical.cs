﻿using Bogus;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;

namespace SharedFakers.Fakers.Clinical
{
    public static class FakerClinical
    {
        // Faker para vincular Pacientes
        public static Faker<PatientRequestDTO> CreatePatient(long personId, long orgId) =>
            new Faker<PatientRequestDTO>()
                .RuleFor(p => p.PersonId, personId)
                .RuleFor(p => p.OrganizationId, orgId)
                .RuleFor(p => p.InternalCode, f => "EXP-" + f.Random.Replace("####-####"));

        // Faker para Signos Vitales (Rangos Médicos Reales)
        public static Faker<VitalSignsRequestDTO> CreateVitalSigns(long patientId) =>
            new Faker<VitalSignsRequestDTO>()
                .RuleFor(v => v.PatientId, patientId)
                .RuleFor(v => v.Systolic, f => f.Random.Decimal(110, 140))
                .RuleFor(v => v.Diastolic, f => f.Random.Decimal(70, 95))
                .RuleFor(v => v.HeartRate, f => f.Random.Int(60, 100))
                .RuleFor(v => v.Temperature, f => f.Random.Decimal(36.2m, 38.5m))
                .RuleFor(v => v.Weight, f => f.Random.Decimal(50, 110))
                .RuleFor(v => v.Height, f => f.Random.Decimal(150, 195));

        public static async Task SeedVitalSignsAsync(IClinicalService serv, long patientId, int count = 5)
        {
            var faker = CreateVitalSigns(patientId);
            for (int i = 0; i < count; i++)
            {
                await serv.RegistrarSignosVitalesAsync(faker.Generate());
            }
        }
    }
}
