﻿using Bogus;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;

namespace SharedFakers.Fakers.Clinical
{
    public static class FakerClinical
    {
        // Faker para vincular Pacientes
        public static Faker<PatientRequestDTO> Create(long personId, long orgId) =>
            new Faker<PatientRequestDTO>()
                .RuleFor(p => p.PersonId, personId)
                .RuleFor(p => p.OrganizationId, orgId)
                .RuleFor(p => p.InternalCode, f => "PAT-" + f.Random.Replace("####-####"));
    }
}
