﻿using Bogus;
using MedfarLabs.Core.Application.Features.Billing.Dtos.Request;
using MedfarLabs.Core.Application.Features.Billing.Interfaces;

namespace SharedFakers.Fakers.Billing
{
    public static class FakerBilling
    {
        public static Faker<InvoiceRequestDTO> Create(long orgId, long patientId, long serviceId) =>
            new Faker<InvoiceRequestDTO>()
                .CustomInstantiator(f => new InvoiceRequestDTO
                {
                    OrganizationId = orgId,
                    PatientId = patientId,
                    InvoiceNumber = "FAC-" + f.Random.Replace("####"),
                    AuditNotes = "Carga masiva seeder",
                    Items = new List<InvoiceItemRequestDTO>
                    {
                    new InvoiceItemRequestDTO(serviceId, f.Random.Int(1, 2), f.Random.Decimal(50, 200))
                    }
                });

        // Helper para el MasterSeeder
        public static async Task SeedAsync(IBillingService serv, long orgId, long patientId, long serviceId)
        {
            var request = Create(orgId, patientId, serviceId).Generate();
            await serv.GenerarFacturaAsync(request);
        }
    }
}
