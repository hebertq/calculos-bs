﻿using Bogus;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;

namespace SharedFakers.Fakers.Care
{
    public static class FakerPatient
    {
        public static Faker<PatientRequestDTO> Create => new Faker<PatientRequestDTO>()
            .CustomInstantiator(f => new PatientRequestDTO
            {
                // Usamos asignación de propiedades en lugar de argumentos de constructor
                PersonId = 0,
                OrganizationId = 0,
                InternalCode = "EXP-" + f.Random.Replace("####")
            });

        public static async Task SeedAsync(IClinicalService serv, long personId, long orgId) =>
            await serv.RegistrarPacienteAsync(Create.Generate() with
            {
                PersonId = personId,
                OrganizationId = orgId
            });
    }
}
