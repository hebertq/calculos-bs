﻿using Bogus;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;

namespace SharedFakers.Fakers.Care
{
    public static class FakerAntecedent
    {
        public static Faker<AntecedentRequestDTO> Create => new Faker<AntecedentRequestDTO>()
            .CustomInstantiator(f => new AntecedentRequestDTO(
                f.Random.Long(1, 100),          // PatientId
                f.PickRandom(new[] { 22, 23 }), // TypeId (Patológico, Familiar)
                f.Lorem.Sentence()              // Description
            ));

        public static async Task SeedAsync(IClinicalService serv, long patientId, int count = 3)
        {
            var faker = Create;
            for (int i = 0; i < count; i++)
            {
                var request = faker.Generate() with { PatientId = patientId };
                await serv.RegistrarAntecedenteAsync(request);
            }
        }
    }
}
