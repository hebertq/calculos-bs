﻿using Bogus;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;

namespace SharedFakers.Fakers.Care
{
    public static class FakerVitalSigns
    {
        /// <summary>
        /// Genera un objeto base con valores aleatorios dentro de rangos humanos normales.
        /// </summary>
        public static Faker<VitalSignsRequestDTO> Create(long patientId) => new Faker<VitalSignsRequestDTO>()
                .RuleFor(v => v.PatientId, patientId)
                .RuleFor(v => v.Systolic, f => f.Random.Decimal(110, 140))
                .RuleFor(v => v.Diastolic, f => f.Random.Decimal(70, 95))
                .RuleFor(v => v.HeartRate, f => f.Random.Int(60, 100))
                .RuleFor(v => v.Temperature, f => f.Random.Decimal(36.2m, 38.5m))
                .RuleFor(v => v.Weight, f => f.Random.Decimal(50, 110))
                .RuleFor(v => v.Height, f => f.Random.Decimal(150, 195));

        /// <summary>
        /// Puebla la base de datos con un historial de signos vitales para un paciente específico.
        /// Útil para probar gráficas de análisis lineal.
        /// </summary>
        public static async Task SeedAsync(IClinicalService serv, long patientId, int count = 5)
        {
            var faker = Create(patientId);
            for (int i = 0; i < count; i++)
            {
                // El uso de 'with' permite inyectar el ID real manteniendo la aleatoriedad del resto
                var request = faker.Generate() with { PatientId = patientId };
                await serv.RegistrarSignosVitalesAsync(request);
            }
        }
    }
}

