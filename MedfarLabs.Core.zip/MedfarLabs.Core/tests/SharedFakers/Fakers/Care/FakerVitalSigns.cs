﻿using Bogus;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;

namespace SharedFakers.Fakers.Care
{
    public static class FakerVitalSigns
    {
        /// <summary>
        /// Genera un objeto base con valores aleatorios dentro de rangos humanos normales.
        /// </summary>
        public static Faker<VitalSignsRequestDTO> Create => new Faker<VitalSignsRequestDTO>()
        .CustomInstantiator(f => new VitalSignsRequestDTO(
            0, // PatientId (se asigna con 'with' en el test)
            f.Random.Decimal(110, 140), f.Random.Decimal(70, 95),
            f.Random.Int(60, 100), f.Random.Decimal(36, 39),
            f.Random.Decimal(50, 100), f.Random.Decimal(150, 190)
        ));

        /// <summary>
        /// Puebla la base de datos con un historial de signos vitales para un paciente específico.
        /// Útil para probar gráficas de análisis lineal.
        /// </summary>
        public static async Task SeedAsync(IClinicalService serv, long patientId, int count = 5)
        {
            var faker = Create;
            for (int i = 0; i < count; i++)
            {
                // El uso de 'with' permite inyectar el ID real manteniendo la aleatoriedad del resto
                var request = faker.Generate() with { PatientId = patientId };
                await serv.RegistrarSignosVitalesAsync(request);
            }
        }
    }
}

