﻿using Bogus;
using MedfarLabs.Core.Application.Features.Care.Dtos.Request;
using MedfarLabs.Core.Application.Features.Care.Interfaces;

namespace SharedFakers.Fakers.Care
{
    public static class FakerConsultation
    {
        // Estándar: Propiedad Create para generar el objeto base
        public static Faker<ConsultationRequestDTO> Create => new Faker<ConsultationRequestDTO>()
            .CustomInstantiator(f => new ConsultationRequestDTO(
                f.Random.Long(1, 100), // ID Temporal
                1,                     // Medico ID
                f.Lorem.Sentence(),    // Subjetivo
                f.Lorem.Sentence(),    // Objetivo
                f.Lorem.Paragraph(),   // Análisis
                f.Lorem.Sentence()     // Plan
            ));

        // Estándar: SeedAsync para poblar la base de datos
        public static async Task SeedAsync(IMedicalCareService serv, long medicalRecordId, int count = 5)
        {
            var faker = Create;
            for (int i = 0; i < count; i++)
            {
                // Ajustamos el ID del expediente al del paciente real en el test
                var request = faker.Generate() with { MedicalRecordId = medicalRecordId };
                await serv.RegistrarConsultaMedicaAsync(request);
            }
        }
    }
}
