﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bogus;
using MedfarLabs.Core.Application.Features.Care.Dtos.Request;
using MedfarLabs.Core.Application.Features.Care.Interfaces;

namespace SharedFakers.Fakers.Care
{
    public static class FakerPrescription
    {
        public static Faker<PrescriptionRequestDTO> Create => new Faker<PrescriptionRequestDTO>()
            .CustomInstantiator(f => new PrescriptionRequestDTO(
                f.Random.Long(1, 100), // ConsultationId
                f.Random.Long(1, 100), // PatientId
                f.Lorem.Paragraph(),   // Notes
                CreateItems(f, 3)      // Lista de medicamentos
            ));

        private static List<PrescriptionItemRequestDTO> CreateItems(Faker f, int count)
        {
            return Enumerable.Range(1, count).Select(_ => new PrescriptionItemRequestDTO(
                f.Commerce.ProductName(),
                $"{f.Random.Int(10, 500)}mg",
                "Cada 8 horas",
                "7 días",
                f.Lorem.Sentence()
            )).ToList();
        }

        public static async Task SeedAsync(IMedicalCareService serv, long consultationId, long patientId)
        {
            var request = Create.Generate() with
            {
                ConsultationId = consultationId,
                PatientId = patientId
            };
            await serv.EmitirRecetaAsync(request);
        }
    }
}
