﻿using Bogus;
using MedfarLabs.Core.Application.Features.Identity.Dtos.Request;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;

namespace SharedFakers.Fakers.Identity
{
    public static class FakerFacilityRoom
    {
        public static Faker<FacilityRoomRequestDTO> Create => new Faker<FacilityRoomRequestDTO>()
            .CustomInstantiator(f => new FacilityRoomRequestDTO(
                f.Random.Long(1, 100),          // BranchId (se sobreescribe en el test)
                $"Sala {f.Address.SecondaryAddress()}", // Name
                15 // TypeId: Consultorio Estándar
            ));

        public static async Task SeedAsync(IIdentityService serv, long branchId, int count = 2)
        {
            var faker = Create;
            for (int i = 0; i < count; i++)
            {
                var request = faker.Generate() with { BranchId = branchId };
                await serv.RegistrarConsultorioAsync(request);
            }
        }
    }
}
