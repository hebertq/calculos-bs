﻿using Bogus;
using MedfarLabs.Core.Application.Features.Identity.Dtos.Request;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;

namespace SharedFakers.Fakers.Identity
{
    // Se agrega el modificador 'public' para resolver el error de nivel de protección
    public static class FakerOrganization
    {
        public static Faker<OrganizationRequestDTO> Create => new Faker<OrganizationRequestDTO>()
        .CustomInstantiator(f => new OrganizationRequestDTO(
            f.Company.CompanyName() + " Medical Group", // Name
            f.Company.CompanySuffix() + " Suffix",      // TaxId
            "Carga inicial de prueba",                   // AuditNotes
            true
        ));

        public static async Task SeedAsync(IIdentityService serv, int count = 1)
        {
            var faker = Create;
            for (int i = 0; i < count; i++)
            {
                var organization = faker.Generate();
                await serv.RegistrarOrganizacionAsync(organization);
            }
        }
    }
}
