﻿using Bogus;
using MedfarLabs.Core.Application.Features.Identity.Dtos.Request;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using MedfarLabs.Core.Domain.Enums;

namespace SharedFakers.Fakers.Identity
{
    public static class FakerPerson
    {
        public static Faker<PersonRequestDTO> Create => new Faker<PersonRequestDTO>()
        .CustomInstantiator(f => new PersonRequestDTO(
            f.Name.FirstName(), f.Name.FirstName(), f.Name.LastName(), f.Name.LastName(),
            f.Date.Past(60, DateTime.Now.AddYears(-18)), (int)f.PickRandom<Genero>(),
            1, f.Internet.Email(), f.Phone.PhoneNumber("########")
        ));

        public static async Task SeedAsync(IIdentityService serv, int count = 10)
        {
            var faker = Create;
            for (int i = 0; i < count; i++)
            {
                var person = faker.Generate();
                await serv.RegistrarPersonaAsync(person);
            }
        }
    }
}
