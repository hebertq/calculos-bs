﻿using Bogus;
using MedfarLabs.Core.Application.Features.Inventory.Dtos.Request;
using MedfarLabs.Core.Application.Features.Inventory.Interfaces;

namespace SharedFakers.Fakers.Inventory
{
    public static class FakerInventory
    {
        // Propiedad estática: Usa inicialización por llaves { }
        public static Faker<MedicalServiceRequestDTO> Create => new Faker<MedicalServiceRequestDTO>()
            .CustomInstantiator(f => new MedicalServiceRequestDTO
            {
                OrganizationId = 0, // Se inyecta con .with
                CategoryId = f.PickRandom(1, 2, 3), // 1: Consulta, 2: Lab, 3: Proc
                Name = f.PickRandom("Consulta General", "Hemograma Completo", "Rayos X Tórax", "Sutura Menor"),
                BasePrice = f.Random.Decimal(25, 300),
                SkuCode = "SRV-" + f.Commerce.Ean8(),
                AuditNotes = "Carga inicial de inventario"
            });

        public static async Task SeedAsync(IInventoryService serv, long orgId, int count = 5)
        {
            for (int i = 0; i < count; i++)
            {
                // El operador 'with' funciona perfecto con propiedades init
                var request = Create.Generate() with { OrganizationId = orgId };
                await serv.RegistrarServicioAsync(request);
            }
        }
    }
}
