﻿using Bogus;
using MedfarLabs.Core.Domain.Entities.Security;

namespace SharedFakers.Fakers.Security
{
    public static class SecurityFaker
    {
        public static Faker<RoleGroup> GetRoleGroupFaker(long organizationId)
        {
            return new Faker<RoleGroup>()
                .RuleFor(r => r.OrganizationId, _ => organizationId)
                .RuleFor(r => r.Name, f => f.Name.JobTitle())
                .RuleFor(r => r.Description, f => f.Lorem.Sentence())
                .RuleFor(r => r.IsActive, _ => true);
        }
    }
}
