﻿using Bogus;
using MedfarLabs.Core.Application.Features.Laboratory.Dtos.Request;
using MedfarLabs.Core.Application.Features.Laboratory.Interfaces;

namespace SharedFakers.Fakers.Laboratory
{
    public static class FakerLaboratory
    {
        public static Faker<LabResultRequestDTO> Create => new Faker<LabResultRequestDTO>()
            .CustomInstantiator(f => new LabResultRequestDTO
            {
                // Usamos las propiedades definidas en el record
                LabOrderId = 0, // Se sobreescribe en el Seed o con 'with'
                StatusId = f.Random.Int(1, 3), // 1: Pendiente, 2: Procesando, 3: Finalizado
                TechnicalDataJson = "{\"hemoglobina\": 14.5, \"plaquetas\": 250000}",
                Observations = "Resultado generado automáticamente por Faker",
                AuditNotes = f.Internet.Url() // O cualquier nota de auditoría
            });

        public static async Task SeedAsync(ILaboratoryService serv, long orderId, int count = 1)
        {
            var faker = Create;
            for (int i = 0; i < count; i++)
            {
                // El operador 'with' funciona perfecto con records de propiedades init
                var request = faker.Generate() with { LabOrderId = orderId };
                await serv.RegistrarResultadoAsync(request);
            }
        }
    }
}
