﻿using System;
using Bogus;
using MedfarLabs.Core.Application.Features.Laboratory.Dtos.Request;

namespace SharedFakers.Fakers.Laboratory
{
    public static class FakerLabOrder
    {
        public static Faker<LabOrderRequestDTO> Create => new Faker<LabOrderRequestDTO>()
            .CustomInstantiator(f => new LabOrderRequestDTO(
                0, // ConsultationId (se inyecta en el loop)
                0, // PatientId (se inyecta en el loop)
                0, // ServiceId (ID del examen del catálogo)
                1  // StatusId (1: Pendiente)
            ));
    }
}
