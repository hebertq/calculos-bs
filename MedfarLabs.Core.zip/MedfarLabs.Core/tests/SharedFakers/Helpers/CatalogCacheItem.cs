﻿namespace SharedFakers.Helpers
{
    internal record CatalogCacheItem(long Id, int CatalogId, string Code);
}
