﻿using System.Data;
using MedfarLabs.Core.Application.Features.Common.Interfaces;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Common;

namespace SharedFakers.Helpers
{
    public class CatalogSeedHelper
    {
        private readonly ICatalogService _cat;
        private Dictionary<(CatalogType catalog, string code), long> _cache = new();

        public CatalogSeedHelper(ICatalogService cat)
        {
            _cat = cat;
        }

        /// <summary>
        /// Carga todos los detalles de catálogos en memoria para búsquedas rápidas.
        /// </summary>
        public async Task LoadAllAsync()
        {
            var items = await _cat.GetActiveItemsAsync();

            _cache = items.ToDictionary(
                key => ((CatalogType)key.CatalogId, key.Code),
                value => value.Id
            );
        }

        /// <summary>
        /// Obtiene el ID numérico de un detalle basado en su Enum de categoría y su código string.
        /// </summary>
        public long GetId(CatalogType catalog, string code)
        {
            if (_cache.TryGetValue((catalog, code), out var id))
            {
                return id;
            }

            throw new KeyNotFoundException($"No se encontró el código '{code}' en el catálogo '{catalog}'.");
        }

        // Versión para obtener el primer ID disponible de un catálogo (útil para datos aleatorios)
        public long GetFirstId(CatalogType catalog)
        {
            return _cache.Keys
                .Where(k => k.catalog == catalog)
                .Select(k => _cache[k])
                .FirstOrDefault();
        }
    }
}
