﻿using Microsoft.Extensions.DependencyInjection;
using MedfarLabs.Core.Application.Features.Billing.Interfaces;
using MedfarLabs.Core.Application.Features.Care.Interfaces;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;
using MedfarLabs.Core.Application.Features.Identity.Dtos.Request;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using MedfarLabs.Core.Application.Features.Inventory.Dtos.Response;
using MedfarLabs.Core.Application.Features.Inventory.Interfaces;
using MedfarLabs.Core.Application.Features.Laboratory.Interfaces;
using MedfarLabs.Core.Domain.Interfaces.Repositories;
using MedfarLabs.Core.Domain.Enums;
using SharedFakers.Fakers.Billing;
using SharedFakers.Fakers.Care;
using SharedFakers.Fakers.Identity;
using SharedFakers.Fakers.Inventory;
using SharedFakers.Fakers.Laboratory;
using SharedFakers.Helpers;
using MedfarLabs.Core.Application.Features.Common.Interfaces;

namespace SharedFakers.Seeders
{
    public class MasterSeeder
    {
        private readonly IServiceProvider _services;
        private CatalogSeedHelper? _catalog;

        public MasterSeeder(IServiceProvider services)
        {
            _services = services;
        }

        public async Task SeedAsync(int cantidadPacientes = 10)
        {
            // 1. Resolución de Servicios e Infraestructura
            var identityService = _services.GetRequiredService<IIdentityService>();
            var clinicalService = _services.GetRequiredService<IClinicalService>();
            var inventoryService = _services.GetRequiredService<IInventoryService>();
            var careService = _services.GetRequiredService<IMedicalCareService>();
            var labService = _services.GetRequiredService<ILaboratoryService>();
            var billingService = _services.GetRequiredService<IBillingService>();
            var unitOfWork = _services.GetRequiredService<IUnitOfWork>();
            // Inicializar el Helper de Catálogos (IDbConnection debe estar registrado)
            var cat = _services.GetRequiredService<ICatalogService>();
            _catalog = new CatalogSeedHelper(cat);
            await _catalog.LoadAllAsync();

            // 2. NIVEL 0: Organización Maestra
            long orgId = 1;
            var orgCheck = await unitOfWork.Organizations.GetByIdAsync(orgId);
            if (orgCheck == null)
            {
                var medfarDto = new OrganizationRequestDTO(
                    Name: "MedfarLabs",
                    TaxId: "123456789",
                    AuditNotes: "Carga inicial MasterSeeder",
                    IsActive: true
                );
                var res = await identityService.RegistrarOrganizacionAsync(medfarDto);
                orgId = res.Data;
            }

            // 3. NIVEL 1: Usuario Administrador Maestro
            long adminUserId = await EnsureAdminUserExists(identityService, unitOfWork, orgId);

            // 4. NIVEL 2: Inventario
            await FakerInventory.SeedAsync(inventoryService, orgId, count: 5);
            var invRes = await inventoryService.ObtenerServiciosPorOrganizacionAsync(orgId);
            var listaServicios = invRes.Data?.ToList() ?? new List<MedicalServiceResponseDTO>();

            // Obtener IDs de categoría dinámicamente
            long catLabId = _catalog.GetId(CatalogType.ServiceCategory, "LAB");
            long examenId = listaServicios.FirstOrDefault(s => s.CategoryId == (int)catLabId)?.Id ?? 0;
            long servicioFacturableId = listaServicios.LastOrDefault()?.Id ?? 0;

            // --- Bucle de Generación de Datos de Pacientes ---
            for (int i = 0; i < cantidadPacientes; i++)
            {
                // 4. IDENTITY: Persona
                var pf = FakerPerson.Create.Generate();
                var personDto = new PersonRequestDTO(
                    FirstName: pf.FirstName,
                    MiddleName: pf.MiddleName,
                    LastName: pf.LastName,
                    SecondLastName: pf.SecondLastName,
                    BirthDate: pf.BirthDate,
                    GenderId: (int)_catalog.GetId(CatalogType.Gender, i % 2 == 0 ? "M" : "F"),
                    BirthCountryId: (int)_catalog.GetId(CatalogType.Country, "CRI"),
                    Email: $"paciente_{i}_{Guid.NewGuid().ToString().Substring(0, 4)}@medfarlabs.com",
                    MobilePhone: pf.MobilePhone
                );

                var personRes = await identityService.RegistrarPersonaAsync(personDto);
                if (!personRes.IsSuccess) continue;
                long personId = personRes.Data;

                // 5. CLINICAL: Paciente
                var patientRes = await clinicalService.RegistrarPacienteAsync(
                    FakerPatient.Create.Generate() with { PersonId = personId, OrganizationId = orgId }
                );
                long patientId = patientRes.Data;

                // 6. CLINICAL: Expediente Médico
                var medicalRecordRes = await clinicalService.RegistrarExpedienteMedicoAsync(new MedicalRecordRequestDTO
                {
                    PatientId = patientId,
                    RecordNumber = $"EXP-{orgId}-{1000 + i}-{Guid.NewGuid().ToString().Substring(0, 4)}",
                    StatusId = (int)_catalog.GetId(CatalogType.MedicalRecordStatus, "ACT")
                });
                long medicalRecordId = medicalRecordRes.Data;

                // 7. CLINICAL_OBS: Signos Vitales
                await FakerVitalSigns.SeedAsync(clinicalService, patientId, count: 1);

                // 8. CARE: Consulta Médica
                var consultationRes = await careService.RegistrarConsultaMedicaAsync(
                    FakerConsultation.Create.Generate() with { MedicalRecordId = medicalRecordId }
                );
                long consultationId = consultationRes.Data;

                // 9. LABORATORY: Orden y Resultados
                if (examenId > 0)
                {
                    var labOrderRes = await labService.RegistrarOrdenAsync(
                        FakerLabOrder.Create.Generate() with
                        {
                            ConsultationId = consultationId,
                            PatientId = patientId,
                            ServiceId = examenId,
                            StatusId = (int)_catalog.GetId(CatalogType.LabOrderStatus, "LAB_REQ")
                        }
                    );

                    if (labOrderRes.IsSuccess)
                        await FakerLaboratory.SeedAsync(labService, labOrderRes.Data, count: 1);
                }

                // 11. BILLING: Facturación
                if (servicioFacturableId > 0)
                    await FakerBilling.SeedAsync(billingService, orgId, patientId, servicioFacturableId);
            }

            await unitOfWork.SaveChangesAsync();
        }

        private async Task<long> EnsureAdminUserExists(IIdentityService identityService, IUnitOfWork uow, long orgId)
        {
            const string adminUsername = "admin.medfar";

            // Verificar existencia para idempotencia
            var existingUser = await uow.Users.GetByUsernameAsync(adminUsername);
            if (existingUser != null) return existingUser.Id;

            var personRes = await identityService.RegistrarPersonaAsync(new PersonRequestDTO(
                FirstName: "Admin",
                MiddleName: null,
                LastName: "MedfarLabs",
                SecondLastName: null,
                BirthDate: new DateTime(1985, 1, 1),
                GenderId: (int)_catalog!.GetId(CatalogType.Gender, "M"),
                BirthCountryId: (int)_catalog.GetId(CatalogType.Country, "CRI"),
                Email: "admin@medfarlabs.com",
                MobilePhone: "55555555"
            ));

            var userRes = await identityService.RegistrarUsuarioAsync(new UsuarioRequestDTO
            {
                PersonId = personRes.Data,
                OrganizationId = orgId,
                Username = adminUsername,
                Password = "Medfar2026*"
            });

            // Asignación al SuperGroup (ID 1 definido en SQL)
            await uow.Security.AssignUserToGroupAsync(userRes.Data, 1);
            await uow.SaveChangesAsync();

            return userRes.Data;
        }
    }
}
