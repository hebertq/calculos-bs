﻿using Microsoft.Extensions.DependencyInjection;
using MedfarLabs.Core.Application.Features.Billing.Interfaces;
using MedfarLabs.Core.Application.Features.Care.Interfaces;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;
using MedfarLabs.Core.Application.Features.Identity.Dtos.Request;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using MedfarLabs.Core.Application.Features.Inventory.Dtos.Response;
using MedfarLabs.Core.Application.Features.Inventory.Interfaces;
using MedfarLabs.Core.Application.Features.Laboratory.Interfaces;
using MedfarLabs.Core.Domain.Interfaces.Repositories;
using SharedFakers.Fakers.Billing;
using SharedFakers.Fakers.Care;
using SharedFakers.Fakers.Identity;
using SharedFakers.Fakers.Inventory;
using SharedFakers.Fakers.Laboratory;

namespace SharedFakers.Seeders
{
    public class MasterSeeder
    {
        private readonly IServiceProvider _services;

        public MasterSeeder(IServiceProvider services)
        {
            _services = services;
        }

        public async Task SeedAsync(int cantidadPacientes = 10)
        {
            // 1. Resolución de Servicios
            var identityService = _services.GetRequiredService<IIdentityService>();
            var clinicalService = _services.GetRequiredService<IClinicalService>();
            var inventoryService = _services.GetRequiredService<IInventoryService>();
            var careService = _services.GetRequiredService<IMedicalCareService>();
            var labService = _services.GetRequiredService<ILaboratoryService>();
            var billingService = _services.GetRequiredService<IBillingService>();
            var unitOfWork = _services.GetRequiredService<IUnitOfWork>(); // Necesario para la tabla de seguridad

            // 2. NIVEL 0: MedfarLabs (Organización Maestra)
            // Usamos un bloque try/catch o validamos existencia para evitar el error de duplicado (PK 1)
            long orgId = 1;
            var orgCheck = await unitOfWork.Organizations.GetByIdAsync(orgId);
            if (orgCheck == null)
            {
                // 1. Crear la entidad Organization
                // Fix for CS7036: Ensure all required parameters are provided when creating an instance of OrganizationRequestDTO
                // CORRECCIÓN: Usar el constructor posicional del Record
                var medfarDto = new OrganizationRequestDTO(
                    Name: "MedfarLabs",
                    TaxId: "123456789",
                    AuditNotes: "Carga inicial MasterSeeder",
                    IsActive: true
                );

                await identityService.RegistrarOrganizacionAsync(medfarDto);
            }

            // 3. NIVEL 1: Usuario Administrador Maestro (admin.medfar)
            // Este usuario es el que usarás en tus Tests de Integración
            long adminUserId = await EnsureAdminUserExists(identityService, unitOfWork, orgId);

            // 4. NIVEL 2: Inventario (Catálogo base para la organización)
            await FakerInventory.SeedAsync(inventoryService, orgId, count: 5);
            var invRes = await inventoryService.ObtenerServiciosPorOrganizacionAsync(orgId);
            var listaServicios = invRes.Data?.ToList() ?? new List<MedicalServiceResponseDTO>();

            long examenId = listaServicios.FirstOrDefault(s => s.CategoryId == 2)?.Id ?? 0;
            long servicioFacturableId = listaServicios.LastOrDefault()?.Id ?? 0;

            // --- Bucle de Generación de Datos de Pacientes ---
            // --- Bucle de Generación de Datos de Pacientes ---
            for (int i = 0; i < cantidadPacientes; i++)
            {
                // 4. IDENTITY: Persona
                // Usamos el Faker para generar datos aleatorios pero los pasamos al constructor del Record
                var pf = FakerPerson.Create.Generate();
                var personDto = new PersonRequestDTO(
                    FirstName: pf.FirstName,
                    MiddleName: pf.MiddleName,
                    LastName: pf.LastName,
                    SecondLastName: pf.SecondLastName,
                    BirthDate: pf.BirthDate,
                    GenderId: pf.GenderId,
                    BirthCountryId: pf.BirthCountryId,
                    Email: $"paciente_{i}_{orgId}@medfarlabs.com", // Email único para evitar errores 23505
                    MobilePhone: pf.MobilePhone
                );

                var personRes = await identityService.RegistrarPersonaAsync(personDto);
                var errores = personRes.Errors is null ? "" : string.Join(", ", personRes.Errors);
                if (!personRes.IsSuccess) throw new Exception($"Fallo Seed Persona {i}: {errores}");
                long personId = personRes.Data;

                // 5. CLINICAL: Paciente (Vinculado a la Persona y MedfarLabs)
                var patientRes = await clinicalService.RegistrarPacienteAsync(
                    FakerPatient.Create.Generate() with { PersonId = personId, OrganizationId = orgId }
                );
                if (!patientRes.IsSuccess) throw new Exception($"Fallo Seed Paciente {i}");
                long patientId = patientRes.Data;

                // 6. CLINICAL: Expediente Médico (PASO CLAVE para la Historia Clínica)
                var medicalRecordRes = await clinicalService.RegistrarExpedienteMedicoAsync(new MedicalRecordRequestDTO
                {
                    PatientId = patientId,
                    RecordNumber = $"EXP-{orgId}-{2000 + i}",
                    StatusId = 1
                });
                if (!medicalRecordRes.IsSuccess) throw new Exception($"Fallo Seed Expediente {i}: {medicalRecordRes.Message}");
                long medicalRecordId = medicalRecordRes.Data;

                // 7. CLINICAL_OBS: Signos Vitales
                await FakerVitalSigns.SeedAsync(clinicalService, patientId, count: 1);

                // 8. CARE: Consulta Médica (Vinculada al Expediente recién creado)
                var consultationRes = await careService.RegistrarConsultaMedicaAsync(
                    FakerConsultation.Create.Generate() with { MedicalRecordId = medicalRecordId }
                );
                if (!consultationRes.IsSuccess) throw new Exception($"Fallo Seed Consulta {i}: {consultationRes.Message}");
                long consultationId = consultationRes.Data;

                // 9. LABORATORY: Orden de Laboratorio (Si existe un servicio de examen)
                if (examenId > 0)
                {
                    var labOrderRes = await labService.RegistrarOrdenAsync(
                        FakerLabOrder.Create.Generate() with
                        {
                            ConsultationId = consultationId,
                            PatientId = patientId,
                            ServiceId = examenId
                        }
                    );

                    if (labOrderRes.IsSuccess)
                    {
                        // 10. LABORATORY: Seed de resultados para esa orden
                        await FakerLaboratory.SeedAsync(labService, labOrderRes.Data, count: 1);
                    }
                }

                // 11. BILLING: Facturación
                if (servicioFacturableId > 0)
                {
                    await FakerBilling.SeedAsync(billingService, orgId, patientId, servicioFacturableId);
                }
            }

            // FINALMENTE: Guardamos todos los cambios de la transacción del seeder
            await unitOfWork.SaveChangesAsync();
        }

        private async Task<long> EnsureAdminUserExists(IIdentityService identityService, IUnitOfWork uow, long orgId)
        {
            // 1. Verificar si el usuario ya existe para evitar colisiones
            const string adminUsername = "admin.medfar";
            // Asumimos un método en el repo o servicio para buscar por username
            // 1. CREAR PERSONA (Usando tu DTO)
            var person = new PersonRequestDTO(
                FirstName: "Admin",
                MiddleName: null,
                LastName: "MedfarLabs",
                SecondLastName: null,
                BirthDate: new DateTime(1985, 1, 1),
                GenderId: 1,
                BirthCountryId: 502,
                Email: "admin@medfarlabs.com",
                MobilePhone: "55555555"
            );
            // Si no existe, creamos la Persona y el Usuario
            var personRes = await identityService.RegistrarPersonaAsync(person);

            var userRes = await identityService.RegistrarUsuarioAsync(new UsuarioRequestDTO
            {
                PersonId = personRes.Data,
                OrganizationId = orgId,
                Username = adminUsername,
                Password = "Medfar2026*" // Password estándar para tests
            });

            long userId = userRes.Data;

            // 2. VINCULACIÓN DE SEGURIDAD (Paso Crítico)
            // Asignamos al usuario al Grupo de Roles 1 (SuperGroup MedfarLabs)
            // Como esto es una tabla de cruce manual, solemos usar el UnitOfWork
            await uow.Security.AssignUserToGroupAsync(userId, 1);
            await uow.SaveChangesAsync();

            return userId;
        }
    }
}
