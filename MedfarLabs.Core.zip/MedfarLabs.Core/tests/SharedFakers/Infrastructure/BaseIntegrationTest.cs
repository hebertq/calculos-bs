﻿using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using SharedFakers.Seeders;
using Xunit;

namespace SharedFakers.Infrastructure
{
    public abstract class BaseIntegrationTest<TEntryPoint> : IAsyncLifetime
        where TEntryPoint : class
    {
        protected readonly IServiceProvider ServiceProvider;
        protected readonly MasterSeeder Seeder;
        private readonly WebApplicationFactory<TEntryPoint> _factory;

        protected BaseIntegrationTest(WebApplicationFactory<TEntryPoint> factory)
        {
            _factory = factory;
            var scope = factory.Services.CreateScope();
            ServiceProvider = scope.ServiceProvider;

            // El Seeder se resuelve desde el Shared
            Seeder = ServiceProvider.GetRequiredService<MasterSeeder>();
        }

        public virtual async Task InitializeAsync()
        {
            // 1. Limpiamos la base de datos antes de cada test
            await DbCleaner.TruncateAllTables(ServiceProvider);

            // 2. Poblamos con los Fakers autónomos
            await Seeder.SeedAsync();
        }

        public virtual Task DisposeAsync() => Task.CompletedTask;
    }
}
