﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using SharedFakers.Seeders;

namespace SharedFakers.Infrastructure
{  
    public class SharedWebApplicationFactory<TEntryPoint> : WebApplicationFactory<TEntryPoint>
        where TEntryPoint : class
    {
        private readonly Action<IServiceCollection> _customRegistrations;

        public SharedWebApplicationFactory(Action<IServiceCollection> customRegistrations)
        {
            _customRegistrations = customRegistrations;
        }

        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            // Forzamos el entorno de Testing
            builder.UseEnvironment("Testing");

            builder.ConfigureTestServices(services =>
            {
                // 1. Ejecutamos los registros (Repositorios, DB, Encriptación) 
                // que vienen desde el IntegrationTestBase del microservicio
                _customRegistrations(services);

                // 2. Registramos el MasterSeeder para que esté disponible en los tests
                services.TryAddScoped<MasterSeeder>();

                // 3. Registramos los Fakers explícitamente si fuera necesario, 
                // aunque usualmente el MasterSeeder los gestiona.
            });
        }

        // SOBRESCRITURA CRUCIAL: Evita que el servidor intente buscar un certificado 
        // o levantar puertos reales que podrían fallar en entornos de CI/CD o Docker.
        protected override IHost CreateHost(IHostBuilder builder)
        {
            // Importante: No borres el base.CreateHost(builder)
            // porque es el que realmente construye el contenedor
            builder.UseContentRoot(Directory.GetCurrentDirectory());
            return base.CreateHost(builder);
        }
    }
}
