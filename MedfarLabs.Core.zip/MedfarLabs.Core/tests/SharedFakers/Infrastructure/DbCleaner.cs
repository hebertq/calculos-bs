﻿using System.Data;
using Dapper;
using Microsoft.Extensions.DependencyInjection;

namespace SharedFakers.Infrastructure
{
    public static class DbCleaner
    {
        public static async Task TruncateAllTables(IServiceProvider sp)
        {
            var db = sp.GetRequiredService<IDbConnection>();

            // Este script busca todas las tablas del esquema público y las limpia
            const string sql = @"
            DO $$ DECLARE
                r RECORD;
            BEGIN
                FOR r IN (SELECT tablename FROM pg_tables WHERE schemaname = 'public') LOOP
                    EXECUTE 'TRUNCATE TABLE ' || quote_ident(r.tablename) || ' CASCADE';
                END LOOP;
            END $$;";

            await db.ExecuteAsync(sql);
        }
    }
}
