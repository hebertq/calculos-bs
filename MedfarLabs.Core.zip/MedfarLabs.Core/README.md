# Salud.SaaS.Core

![Rest API](assets/restapi.png) ![Lambda](assets/lambda.png) ![dotnet](assets/uses-dotnet6-blue.png)

Describe your amazing project