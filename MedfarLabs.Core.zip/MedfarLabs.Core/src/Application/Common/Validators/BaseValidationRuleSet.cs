﻿using MedfarLabs.Core.Domain.Common.Exceptions;
using MedfarLabs.Core.Domain.Common.Responses.Generic;

namespace MedfarLabs.Core.Application.Common.Validators
{
    public abstract class BaseValidationRuleSet<T> where T : class
    {
        private readonly List<(Func<T, bool> Rule, string PropertyName, string Message)> _rules = new();
        // Centralizamos los errores aquí
        protected readonly List<string> ErrorList = new();
        protected T? BusinessObject;

        public void SetBusinessObject(T obj) => BusinessObject = obj;

        protected void AddRule(Func<T, bool> rule, string propertyName, string message)
        {
            _rules.Add((rule, propertyName, message));
        }

        // Este será el único punto de entrada desde la Strategy
        public abstract Task ExecuteValidationAsync();

        /// <summary>
        /// Ejecuta las reglas estructurales acumuladas en _rules
        /// </summary>
        protected void ValidateStructuralRules()
        {
            if (BusinessObject == null) return;

            foreach (var (rule, propertyName, message) in _rules)
            {
                if (!rule(BusinessObject))
                {
                    ErrorList.Add($"{message} ({propertyName})");
                }
            }
        }

        /// <summary>
        /// Agrega un error manualmente (útil para validaciones de DB)
        /// </summary>
        protected void AddError(string message, string propertyName = "")
        {
            ErrorList.Add(string.IsNullOrEmpty(propertyName) ? message : $"{message} ({propertyName})");
        }

        /// <summary>
        /// Evalúa si hay errores y lanza la excepción unificada
        /// </summary>
        protected void ThrowIfInvalid()
        {
            if (ErrorList.Count != 0)
            {
                var response = BaseResponse<T>.Failure("Errores de validación", ErrorList);
                throw new BusinessValidationException<T>(response);
            }
        }

        protected void ValidateRequired(Func<T, object?> selector, string prop, string name)
            => AddRule(obj => Validations.IsRequired(selector(obj)), prop, $"El campo {name} es requerido");
    }
}
