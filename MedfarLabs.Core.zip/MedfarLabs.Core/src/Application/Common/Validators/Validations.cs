﻿namespace MedfarLabs.Core.Application.Common.Validators
{
    using System.Text.RegularExpressions;

    public static class Validations
    {
        // 1. Requerido (String, Objetos, Value Types)
        public static bool IsRequired(object? value)
        {
            if (value == null) return false;
            if (value is string str) return !string.IsNullOrWhiteSpace(str);
            if (value is DateTime dt) return dt != default;
            if (value is int i) return i != default;
            return true;
        }

        // 2. Formato de Email
        public static bool IsValidEmail(string? email)
        {
            if (string.IsNullOrWhiteSpace(email)) return true; // Se valida con Required si es obligatorio
            return Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.IgnoreCase);
        }

        // 3. Rango Numérico
        public static bool IsInRange(int value, int min, int max) => value >= min && value <= max;

        // 4. Longitud de Cadena
        public static bool HasLength(string? str, int min, int max)
        {
            if (str == null) return false;
            return str.Length >= min && str.Length <= max;
        }

        // 5. Solo Números (Útil para DNI o Teléfonos sin formato)
        public static bool IsNumeric(string? str) => !string.IsNullOrEmpty(str) && str.All(char.IsDigit);

        // 6. Fecha no puede ser futura (Útil para fechas de nacimiento)
        public static bool IsNotFutureDate(DateTime date) => date.Date <= DateTime.UtcNow.Date;
    }
}
