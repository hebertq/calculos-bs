﻿using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Interfaces.Repositories;

namespace MedfarLabs.Core.Application.Common.Services
{
    public abstract class BaseService
    {
        protected readonly IUnitOfWork _unitOfWork;
        protected readonly IApplicationDispatcher _dispatcher; // Nuevo dispatcher de salida

        protected BaseService(IUnitOfWork unitOfWork, IApplicationDispatcher dispatcher)
        {
            _unitOfWork = unitOfWork;
            _dispatcher = dispatcher;
        }

        /// <summary>
        /// Ejecuta una acción en transacción y, si es exitosa, 
        /// despacha los eventos resultantes después del Commit.
        /// </summary>
        protected async Task<BaseResponse<T>> ExecuteInTransactionAsync<T>(
            Func<Task<BaseResponse<T>>> action,
            object? eventToPublish = null) // Parámetro opcional para el evento
        {
            try
            {
                await _unitOfWork.BeginTransactionAsync();

                var result = await action();

                if (result.IsSuccess)
                {
                    await _unitOfWork.CommitAsync();

                    // IMPORTANTE: El evento se despacha DESPUÉS del commit exitoso
                    if (eventToPublish != null)
                    {
                        // No esperamos (await) si queremos que sea puramente asíncrono, 
                        // o lo esperamos si la sincronización administrativa es crítica.
                        await _dispatcher.PublishAsync(eventToPublish);
                    }
                }
                else
                {
                    await _unitOfWork.RollbackAsync();
                }

                return result;
            }
            catch (Exception ex)
            {
                await _unitOfWork.RollbackAsync();
                return BaseResponse<T>.Failure($"Fallo en la transacción: {ex.Message}");
            }
        }
    }
}
