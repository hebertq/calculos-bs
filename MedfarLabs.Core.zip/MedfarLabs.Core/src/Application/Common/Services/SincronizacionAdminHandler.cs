﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Domain.Interfaces.Repositories;

namespace MedfarLabs.Core.Application.Common.Services
{
    public class SincronizacionAdminHandler //: IEventHandler<PagoRegistradoEvent>
    {
        //private readonly IUnitOfWork _unitOfWork;

        //public SincronizacionAdminHandler(IUnitOfWork unitOfWork) => _unitOfWork = unitOfWork;

        //public async Task HandleAsync(PagoRegistradoEvent @event)
        //{
        //    // Aquí va la lógica de "execute_admin_sync" que antes era un trigger
        //    await _unitOfWork.Admin.SincronizarMovimiento(@event.PagoId);
        //}
    }
}
