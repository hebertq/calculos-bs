﻿using Microsoft.Extensions.DependencyInjection;
using MedfarLabs.Core.Application.Common.Interfaces;

namespace MedfarLabs.Core.Application.Common.Services
{
    public class ApplicationDispatcher : IApplicationDispatcher
    {
        private readonly IServiceProvider _serviceProvider;

        public ApplicationDispatcher(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public async Task PublishAsync<TEvent>(TEvent @event) where TEvent : class
        {
            // Buscamos todos los Handlers que quieran escuchar este evento específico
            var handlers = _serviceProvider.GetServices<IEventHandler<TEvent>>();

            foreach (var handler in handlers)
            {
                // Ejecución segura: si un handler falla, no detiene a los demás
                try
                {
                    await handler.HandleAsync(@event);
                }
                catch { /* Logging opcional */ }
            }
        }
    }
}
