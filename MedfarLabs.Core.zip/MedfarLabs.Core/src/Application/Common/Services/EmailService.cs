﻿using MedfarLabs.Core.Application.Common.Interfaces;

namespace MedfarLabs.Core.Application.Common.Services
{
    public class EmailService : IEmailService
    {
        public Task SendEmailAsync(string to, string subject, string body)
        {
            // No hace nada, solo cumple el contrato para que el test no explote
            return Task.CompletedTask;
        }
    }
}
