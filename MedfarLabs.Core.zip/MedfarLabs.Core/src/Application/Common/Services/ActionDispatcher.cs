﻿using System.Text.Json;
using Microsoft.Extensions.Logging;
using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Features.Security.Dtos;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Security;

namespace MedfarLabs.Core.Application.Common.Services
{
    public class ActionDispatcher : IActionDispatcher
    {
        // Cambiamos la llave del diccionario de 'string' a 'int'
        private readonly Dictionary<int, IDomain> _strategies;
        private readonly IUserContext _userContext;
        private readonly ILogger<ActionDispatcher> _logger;

        public ActionDispatcher(IEnumerable<IDomain> strategies, IUserContext userContext, ILogger<ActionDispatcher> logger)
        {
            _userContext = userContext;
            _logger = logger;

            // O(1) Access: Usamos el ModuleId (entero del Enum)
            _strategies = strategies.ToDictionary(
                s => s.ModuleId, // Aquí ya no existe DomainName, usamos ModuleId
                s => s
            );
        }

        // Ahora recibimos los Enums directamente
        public async Task<BaseResponse<object>> DispatchAsync(AppModule module, AppAction action, JsonElement data, string? traceId)
        {
            // 1. SEGURIDAD: Validación asíncrona usando el ID de la acción
            if (!await _userContext.HasPermissionAsync((int)action))
            {
                return BaseResponse<object>.Failure(
                    $"No tienes autorización para ejecutar la acción: {action}",
                    new List<string> { "Security.AccessDenied" }
                );
            }

            // 2. LOCALIZAR ESTRATEGIA: Buscamos por el entero del módulo
            if (!_strategies.TryGetValue((int)module, out var strategy))
            {
                return BaseResponse<object>.Failure($"El módulo '{module}' no está registrado.");
            }

            // 3. DELEGAR: Pasamos el entero de la acción a la estrategia
            // Esto resuelve el error de "ExecuteAsync does not contain a definition..."
            return await strategy.ExecuteAsync((int)action, data, traceId);
        }

        // FLUJO B: Entrada desde SQS (Worker / Recursivo)
        public async Task DispatchSecondaryAsync(BackgroundJobMessage job)
        {
            // 1. LOCALIZAR ESTRATEGIA
            if (!_strategies.TryGetValue((int)job.Module, out var strategy))
            {
                _logger.LogError("Worker falló: Módulo {Module} no encontrado para la acción {Action}", job.Module, job.ActionId);
                return;
            }

            // 2. EJECUCIÓN PARCIAL (Solo OutputActions secundarios)
            // Usamos el método que creamos para el flujo recursivo
            await strategy.DispatchOnlyAsync(job);
        }
    }
}
