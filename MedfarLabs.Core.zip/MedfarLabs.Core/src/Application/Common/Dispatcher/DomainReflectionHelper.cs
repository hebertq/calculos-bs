﻿using System.Collections.Concurrent;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using MedfarLabs.Core.Domain.Extensions;

namespace MedfarLabs.Core.Application.Common.Dispatcher
{
    public static class DomainReflectionHelper
    {
        private static readonly ConcurrentDictionary<Type, Func<string, object?>> _deserializerCache = new();
        private static readonly ConcurrentDictionary<string, Func<object, object, Task<object?>>> _handlerCache = new();

        // Nuevos cachés para las Reglas de Negocio
        private static readonly ConcurrentDictionary<Type, Action<object, object>> _ruleSetterCache = new();
        private static readonly ConcurrentDictionary<Type, Func<object, Task>> _ruleExecutorCache = new();

        public static object? DeserializeDto(Type dtoType, JsonElement data)
        {
            var deserializer = _deserializerCache.GetOrAdd(dtoType, type =>
            {
                var method = typeof(JsonSerializerExtensions)
                    .GetMethod(nameof(JsonSerializerExtensions.DeserializeGeneric), BindingFlags.Public | BindingFlags.Static)!
                    .MakeGenericMethod(type);

                var inputParam = Expression.Parameter(typeof(string), "json");
                var call = Expression.Call(method, inputParam);
                return Expression.Lambda<Func<string, object?>>(call, inputParam).Compile();
            });

            return deserializer(data.GetRawText());
        }

        /// <summary>
        /// MÉTODO CORREGIDO: Ejecuta las reglas de validación usando delegados compilados.
        /// </summary>
        public static async Task ExecuteValidationRulesAsync(Type ruleType, object dto, IServiceProvider sp)
        {
            using var scope = sp.CreateScope();
            var ruleInstance = scope.ServiceProvider.GetService(ruleType);
            if (ruleInstance == null) return;

            // 1. Compilar y ejecutar SetBusinessObject(dto)
            var setter = _ruleSetterCache.GetOrAdd(ruleType, type =>
            {
                var method = type.GetMethod("SetBusinessObject") ?? throw new Exception("Método SetBusinessObject no encontrado.");
                var instanceParam = Expression.Parameter(typeof(object), "i");
                var dtoParam = Expression.Parameter(typeof(object), "d");

                var castInstance = Expression.Convert(instanceParam, type);
                var castDto = Expression.Convert(dtoParam, method.GetParameters()[0].ParameterType);

                var call = Expression.Call(castInstance, method, castDto);
                return Expression.Lambda<Action<object, object>>(call, instanceParam, dtoParam).Compile();
            });

            setter(ruleInstance, dto);

            // 2. Compilar y ejecutar ExecuteValidationAsync()
            var executor = _ruleExecutorCache.GetOrAdd(ruleType, type =>
            {
                var method = type.GetMethod("ExecuteValidationAsync") ?? throw new Exception("Método ExecuteValidationAsync no encontrado.");
                var instanceParam = Expression.Parameter(typeof(object), "i");
                var castInstance = Expression.Convert(instanceParam, type);

                var call = Expression.Call(castInstance, method);
                return Expression.Lambda<Func<object, Task>>(call, instanceParam).Compile();
            });

            try
            {
                await executor(ruleInstance);
            }
            catch (TargetInvocationException ex)
            {
                throw ex.InnerException ?? ex;
            }
        }

        public static async Task<object?> InvokeHandlerAsync(IServiceProvider sp, Type serviceType, string methodName, object dto)
        {
            var service = sp.GetRequiredService(serviceType);
            var key = $"{serviceType.FullName}.{methodName}";

            var handler = _handlerCache.GetOrAdd(key, _ =>
            {
                var method = serviceType.GetMethod(methodName) ?? throw new Exception($"Método {methodName} no encontrado.");
                var serviceParam = Expression.Parameter(typeof(object), "s");
                var dtoParam = Expression.Parameter(typeof(object), "d");

                var castService = Expression.Convert(serviceParam, serviceType);
                var castDto = Expression.Convert(dtoParam, method.GetParameters()[0].ParameterType);

                var call = Expression.Call(castService, method, castDto);

                // Compilamos la lambda que maneja el Task
                var lambda = Expression.Lambda<Func<object, object, Task>>(call, serviceParam, dtoParam).Compile();

                return async (svc, d) =>
                {
                    var task = lambda(svc, d);
                    await task;
                    return task.GetType().GetProperty("Result")?.GetValue(task);
                };
            });

            return await handler(service, dto);
        }
    }
}
