﻿using Microsoft.Extensions.Logging;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Application.Common.Dispatcher
{
    public static class DomainResponseMapper
    {
        public static BaseResponse<object> ToBaseResponse(object? result)
        {
            if (result == null) return BaseResponse<object>.Failure("Resultado nulo del servicio.");

            var type = result.GetType();
            var isSuccess = (bool)(type.GetProperty("IsSuccess")?.GetValue(result) ?? false);
            var message = (string)(type.GetProperty("Message")?.GetValue(result) ?? string.Empty);
            var data = type.GetProperty("Data")?.GetValue(result);
            var errors = (type.GetProperty("Errors")?.GetValue(result) as IEnumerable<string>)?.ToList() ?? new();

            return isSuccess ? BaseResponse<object>.Success(data!, message) : BaseResponse<object>.Failure(message, errors);
        }

        public static BaseResponse<object> MapException(Exception ex, AppModule module, ILogger logger, int actionId)
        {
            if (ex.GetType().Name.StartsWith("BusinessValidationException"))
            {
                logger.LogWarning("Validación denegada: {Module}.{Action}: {Msg}", module, actionId, ex.Message);
                dynamic dynamicEx = ex;
                return ToBaseResponse(dynamicEx.Response);
            }

            logger.LogError(ex, "Error crítico en {Module}.{Action}: {Msg}", module, actionId, ex.Message);
            return BaseResponse<object>.Failure($"Error crítico en el dominio {module}: {ex.Message}");
        }
    }
}
