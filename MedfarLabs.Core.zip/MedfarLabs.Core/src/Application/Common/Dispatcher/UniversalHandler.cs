﻿using Amazon.Lambda.Core;
using Amazon.Lambda.APIGatewayEvents;
using Amazon.Lambda.SQSEvents;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Application.Features.Security.Dtos;

namespace MedfarLabs.Core.Application.Common.Dispatcher
{
    public class UniversalHandler
    {
        private readonly IActionDispatcher _dispatcher;
        private readonly ILogger<UniversalHandler> _logger;

        public UniversalHandler(IActionDispatcher dispatcher, ILogger<UniversalHandler> logger)
        {
            _dispatcher = dispatcher;
            _logger = logger;
        }

        public async Task<object> FunctionHandler(JsonElement input, ILambdaContext context)
        {
            // Generamos o capturamos el TraceId de la petición de AWS
            string traceId = context.AwsRequestId;
            // 1. ¿Es una petición de API Gateway? (Buscamos la propiedad 'httpMethod')
            if (input.TryGetProperty("httpMethod", out _))
            {
                Environment.SetEnvironmentVariable("EXECUTION_CONTEXT", "Main");
                var apiRequest = JsonSerializer.Deserialize<APIGatewayProxyRequest>(input.GetRawText(),
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                // Inyectamos el TraceId en los logs de esta ejecución
                using (_logger.BeginScope(new Dictionary<string, object> { ["TraceId"] = traceId }))
                {
                    return await ProcessApiRequest(apiRequest!, traceId);
                }
            }

            // 2. ¿Es un evento de SQS? (Buscamos la propiedad 'Records')
            if (input.TryGetProperty("Records", out _))
            {
                Environment.SetEnvironmentVariable("EXECUTION_CONTEXT", "Worker");
                var sqsEvent = JsonSerializer.Deserialize<SQSEvent>(input.GetRawText(),
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                await ProcessSqsEvent(sqsEvent!);
                return new { statusCode = 200, message = "SQS Batch Processed" };
            }

            _logger.LogCritical("Evento no identificado: {Raw}", input.GetRawText());
            throw new Exception("Source unknown");
        }

        private async Task<APIGatewayProxyResponse> ProcessApiRequest(APIGatewayProxyRequest request, string traceId)
        {
            // Extraemos metadatos de los headers (puestos por el CloudFront o API Gateway)
            var module = Enum.Parse<AppModule>(request.Headers["X-App-Module"]);
            var action = Enum.Parse<AppAction>(request.Headers["X-App-Action"]);

            using var doc = JsonDocument.Parse(request.Body);
            var response = await _dispatcher.DispatchAsync(module, action, doc.RootElement, traceId);

            return new APIGatewayProxyResponse
            {
                StatusCode = response.IsSuccess ? 200 : 400,
                Body = JsonSerializer.Serialize(response),
                Headers = new Dictionary<string, string> { { "Content-Type", "application/json" } }
            };
        }

        private async Task ProcessSqsEvent(SQSEvent sqsEvent)
        {
            foreach (var record in sqsEvent.Records)
            {
                try
                {
                    var job = JsonSerializer.Deserialize<BackgroundJobMessage>(record.Body);
                    if (job == null) continue;

                    // Abrimos un scope de log con el TraceId original que venía en el mensaje
                    using (_logger.BeginScope(new Dictionary<string, object> { ["TraceId"] = job.TraceId! }))
                    {
                        await _dispatcher.DispatchSecondaryAsync(job);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error procesando el mensaje SQS {MessageId}. TraceId: {TraceId}",
                        record.MessageId, record.Body);

                    // Si lanzas la excepción aquí, SQS reintentará TODO el lote.
                    // Para sistemas críticos, es mejor usar 'BatchItemFailures'.
                    throw;
                }
            }
        }
    }
}
