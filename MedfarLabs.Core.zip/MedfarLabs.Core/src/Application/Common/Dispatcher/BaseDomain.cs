﻿using System.Reflection;
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Interfaces.Security;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;
using MedfarLabs.Core.Application.Features.Security.Dtos;
using MedfarLabs.Core.Application.Common.Dispatcher;

public abstract class BaseDomain : IDomain
{
    public abstract AppModule Module { get; }
    public int ModuleId => (int)Module;
    protected readonly ILogger Logger;
    protected readonly IServiceProvider ServiceProvider;

    private readonly Dictionary<int, Type> _dtoRegistry;
    private readonly Dictionary<int, (Type ServiceType, string MethodName)> _handlerRegistry = new();
    private readonly Dictionary<Type, Type> _ruleRegistry;
    private readonly IEnumerable<IOutputAction> _outputActions;

    protected BaseDomain(Assembly domainAssembly, IServiceProvider serviceProvider)
    {
        ServiceProvider = serviceProvider;
        Logger = serviceProvider.GetRequiredService<ILoggerFactory>().CreateLogger(GetType().FullName ?? nameof(BaseDomain));
        _outputActions = ServiceProvider.GetServices<IOutputAction>();

        // Registros automáticos (se mantienen aquí por ser parte de la inicialización del estado)
        _dtoRegistry = domainAssembly.GetTypes()
            .Where(t => t.GetCustomAttribute<ActionMappingAttribute>()?.Module == this.Module)
            .ToDictionary(t => (int)t.GetCustomAttribute<ActionMappingAttribute>()!.Action, t => t);

        _ruleRegistry = domainAssembly.GetTypes()
            .Where(t => t.BaseType?.IsGenericType == true && t.BaseType.GetGenericTypeDefinition().Name.Contains("BaseValidationRuleSet"))
            .ToDictionary(t => t.BaseType!.GetGenericArguments()[0], t => t);
    }

    protected void RegisterActionHandler<TService>(AppAction action, string methodName)
        => _handlerRegistry[(int)action] = (typeof(TService), methodName);

    public async Task<BaseResponse<object>> ExecuteAsync(int actionId, JsonElement data, string? traceId)
    {
        var timer = System.Diagnostics.Stopwatch.StartNew();
        var userContext = ServiceProvider.GetRequiredService<IUserContext>();
        var response = BaseResponse<object>.Failure("Uninitialized response.");
        object? dto = null;

        try
        {
            if (!_dtoRegistry.TryGetValue(actionId, out var dtoType))
                return BaseResponse<object>.Failure($"Acción {actionId} no soportada.");

            dto = DomainReflectionHelper.DeserializeDto(dtoType, data) ?? throw new Exception("Error deserialización");

            // Inyección de Identidad
            if (dto is IHasOrganization orgDto) orgDto.OrganizationId = userContext.OrganizationId;
            if (dto is IHasUser userDto) userDto.UserId = userContext.UserId;

            // Reglas y Servicio
            if (_ruleRegistry.TryGetValue(dtoType, out var ruleType))
                await DomainReflectionHelper.ExecuteValidationRulesAsync(ruleType, dto, ServiceProvider);

            if (!_handlerRegistry.TryGetValue(actionId, out var mapping))
                response = BaseResponse<object>.Success(dto, "Validado.");
            else
                response = DomainResponseMapper.ToBaseResponse(await DomainReflectionHelper.InvokeHandlerAsync(ServiceProvider, mapping.ServiceType, mapping.MethodName, dto));
        }
        catch (Exception ex) { response = DomainResponseMapper.MapException(ex, Module, Logger, actionId); }
        finally
        {
            await DispatchOutputActions(new OutputContextDto(Module, actionId, dto, data.GetRawText(), response, userContext, timer.Elapsed, traceId));
        }
        return response;
    }

    public async Task DispatchOnlyAsync(BackgroundJobMessage job)
    {
        var userContext = ServiceProvider.GetRequiredService<IUserContext>();
        userContext.UserId = job.UserId;
        userContext.OrganizationId = job.OrganizationId;

        var context = new OutputContextDto(job.Module, job.ActionId, null, job.RawInput,
            job.IsSuccess ? BaseResponse<object>.Success(null) : BaseResponse<object>.Failure("Fallo previo"),
            userContext, TimeSpan.Zero,job.TraceId, job.ParentTelemetryId, job.ParentAuditId)
        { Depth = job.Depth };

        await DispatchOutputActions(context);
    }

    private async Task DispatchOutputActions(OutputContextDto context)
    {
        foreach (var action in _outputActions)
        {
            try { if (action.ShouldExecute(context)) await action.ExecuteAsync(context); }
            catch (Exception ex) { Logger.LogCritical(ex, "Fallo en OutputAction: {Name}", action.GetType().Name); }
        }
    }
}

