﻿using System.Text.Json;
using MedfarLabs.Core.Application.Features.Security.Dtos;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Application.Common.Interfaces
{
    public interface IActionDispatcher
    {
        Task<BaseResponse<object>> DispatchAsync(AppModule module, AppAction action, JsonElement data,string? traceId);
        Task DispatchSecondaryAsync(BackgroundJobMessage job);
    }
}
