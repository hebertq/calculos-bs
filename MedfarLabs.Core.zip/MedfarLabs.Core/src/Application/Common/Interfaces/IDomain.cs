﻿using System.Text.Json;
using MedfarLabs.Core.Application.Features.Security.Dtos;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Application.Common.Interfaces
{
    public interface IDomain
    {
        /// <summary>
        /// El módulo (dominio) al que pertenece esta estrategia.
        /// </summary>
        AppModule Module { get; }

        /// <summary>
        /// El ID numérico del módulo para búsquedas rápidas.
        /// </summary>
        int ModuleId { get; }

        /// <summary>
        /// Punto de entrada único para ejecutar cualquier acción dentro de este dominio.
        /// </summary>
        /// <param name="actionId">ID de la acción (AppAction) convertido a entero.</param>
        /// <param name="data">Cuerpo de la petición en formato JsonElement.</param>
        /// <returns>Respuesta unificada BaseResponse con objeto genérico.</returns>
        Task<BaseResponse<object>> ExecuteAsync(int actionId, JsonElement data, string? traceId);
        Task DispatchOnlyAsync(BackgroundJobMessage job);
    }
}
