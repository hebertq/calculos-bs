﻿using MedfarLabs.Core.Application.Features.Security.Dtos;

namespace MedfarLabs.Core.Application.Common.Interfaces
{
    public interface IOutputAction
    {
        // Define si esta acción debe ejecutarse (ej: solo en errores, o solo en ciertas acciones)
        bool ShouldExecute(OutputContextDto context);

        // La lógica a ejecutar
        Task ExecuteAsync(OutputContextDto context);
    }
}
