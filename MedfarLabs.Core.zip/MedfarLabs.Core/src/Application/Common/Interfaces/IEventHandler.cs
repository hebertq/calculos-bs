﻿namespace MedfarLabs.Core.Application.Common.Interfaces
{
    public interface IEventHandler<TEvent>
    {
        Task HandleAsync(TEvent @event);
    }
}
