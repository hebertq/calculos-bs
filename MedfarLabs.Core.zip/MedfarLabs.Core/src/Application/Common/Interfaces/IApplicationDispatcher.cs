﻿namespace MedfarLabs.Core.Application.Common.Interfaces
{
    public interface IApplicationDispatcher
    {
        // Método genérico para publicar cualquier evento
        Task PublishAsync<TEvent>(TEvent @event) where TEvent : class;
    }
}
