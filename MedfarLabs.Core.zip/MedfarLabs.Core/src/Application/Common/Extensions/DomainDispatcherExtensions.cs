﻿using System.Reflection;
using Microsoft.Extensions.DependencyInjection;
using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Common.Services;

namespace MedfarLabs.Core.Application.Common.Extensions
{
    public static class DomainDispatcherExtensions
    {
        public static IServiceCollection AddDomainDispatchers(this IServiceCollection services, params Assembly[] assembliesToScan)
        {
            // 1. Registrar el Dispatcher Central como Singleton (es hilo-seguro)
            services.AddSingleton<IActionDispatcher, ActionDispatcher>();

            // 2. Escanear ensamblados para encontrar todas las estrategias
            var strategyType = typeof(IDomain);

            foreach (var assembly in assembliesToScan)
            {
                var implementations = assembly.GetTypes()
                    .Where(t => strategyType.IsAssignableFrom(t) && !t.IsInterface && !t.IsAbstract);

                foreach (var implementation in implementations)
                {
                    // Registramos cada estrategia como Singleton
                    services.AddSingleton(strategyType, implementation);
                }
            }

            return services;
        }
    }
}
