﻿using System.Reflection;
using FluentValidation;
using LAFISE.CrossCutting.Behaviors;
using MediatR;
using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Common.Services;
using MedfarLabs.Core.Application.Common.Validators;
using MedfarLabs.Core.Application.Features.Billing.Interfaces;
using MedfarLabs.Core.Application.Features.Billing.Services;
using MedfarLabs.Core.Application.Features.Care.Interfaces;
using MedfarLabs.Core.Application.Features.Care.Services;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;
using MedfarLabs.Core.Application.Features.Clinical.Services;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using MedfarLabs.Core.Application.Features.Identity.Services;
using MedfarLabs.Core.Application.Features.Inventory.Interfaces;
using MedfarLabs.Core.Application.Features.Inventory.Services;
using MedfarLabs.Core.Application.Features.Laboratory.Interfaces;
using MedfarLabs.Core.Application.Features.Laboratory.Services;
using MedfarLabs.Core.Application.Features.Security.Events;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class ConfigureServices
    {
        /// <summary>
        /// Adds all the dependency injection of the services used in the Application Layer
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            services.AddAutoMapper(Assembly.GetExecutingAssembly());
            services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
            services.AddMediatR(cfg => cfg.RegisterServicesFromAssemblies(Assembly.GetExecutingAssembly()));
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(UnhandledExceptionBehavior<,>));
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(PerformanceBehavior<,>));

            services.AddTransient<IIdentityService, IdentityService>();
            services.AddTransient<IClinicalService, ClinicalService>();
            services.AddTransient<IInventoryService, InventoryService>();
            services.AddTransient<IMedicalCareService, MedicalCareService>();
            services.AddTransient<IBillingService, BillingService>();
            services.AddTransient<ILaboratoryService, LaboratoryService>();

            return services;
        }
        public static IServiceCollection AddActionDispatching(this IServiceCollection services)
        {
            var assembly = typeof(IActionDispatcher).Assembly;
            // 1. Registrar el Dispatcher Central como Singleton
            services.AddSingleton<IActionDispatcher, ActionDispatcher>();

            // 2. ESCANEO AUTOMÁTICO DE ESTRATEGIAS
            // Busca todas las clases que implementen IDomainStrategy
            services.Scan(scan => scan
                .FromAssemblies(assembly)
                .AddClasses(classes => classes.AssignableTo<IDomain>())
                    .AsImplementedInterfaces()
                    .WithSingletonLifetime());

            // 3. ESCANEO AUTOMÁTICO DE REGLAS DE VALIDACIÓN
            // Esto es vital para que BaseDomainStrategy las encuentre por reflexión
            services.Scan(scan => scan
                .FromAssemblies(assembly)
                .AddClasses(classes => classes.AssignableTo(typeof(BaseValidationRuleSet<>)))
                    .AsSelf()
                    .WithScopedLifetime());

            return services;
        }

        public static IServiceCollection AddEventHandlers(this IServiceCollection services)
        {
            var assembly = typeof(IApplicationDispatcher).Assembly;
            // 1. Registrar el Dispatcher de Salida
            services.AddScoped<IApplicationDispatcher, ApplicationDispatcher>();
            services.AddScoped<IEmailService, EmailService>();
            
            // 2. Escaneo Automático de Handlers
            // Registra cualquier clase que implemente IEventHandler<T>
            services.Scan(scan => scan
                .FromAssemblies(assembly)
                .AddClasses(classes => classes.AssignableTo(typeof(IEventHandler<>)))
                    .AsImplementedInterfaces()
                    .WithScopedLifetime());
           
            // Registro de acciones Globales
            services.AddScoped<IOutputAction, AuditOutputAction>();
            services.AddScoped<IOutputAction, TelemetryOutputAction>();
            services.AddScoped<IOutputAction, QueueOutputAction>();

            // Registro de acciones Específicas

            return services;
        }
    }
}
