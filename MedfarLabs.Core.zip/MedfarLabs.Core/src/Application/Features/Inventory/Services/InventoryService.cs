﻿using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Common.Services;
using MedfarLabs.Core.Application.Features.Inventory.Dtos.Request;
using MedfarLabs.Core.Application.Features.Inventory.Dtos.Response;
using MedfarLabs.Core.Application.Features.Inventory.Interfaces;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Entities.Inventory;
using MedfarLabs.Core.Domain.Interfaces.Repositories;

namespace MedfarLabs.Core.Application.Features.Inventory.Services
{
    public class InventoryService : BaseService, IInventoryService
    {
        public InventoryService(IUnitOfWork uow, IApplicationDispatcher dispatcher) : base(uow, dispatcher) { }

        public async Task<BaseResponse<long>> RegistrarServicioAsync(MedicalServiceRequestDTO request)
        {
            var entity = new MedicalService
            {
                OrganizationId = request.OrganizationId,
                CategoryId = request.CategoryId,
                Name = request.Name,
                BasePrice = request.BasePrice,
                SkuCode = request.SkuCode,
                AuditNotes = request.AuditNotes
            };

            var id = await _unitOfWork.Services.AddAsync(entity);
            return BaseResponse<long>.Success(id, "Servicio médico registrado exitosamente en el catálogo");
        }

        public async Task<BaseResponse<IEnumerable<MedicalServiceResponseDTO>>> ObtenerServiciosPorOrganizacionAsync(long organizationId)
        {
            var servicios = await _unitOfWork.Services.GetByOrganizationAsync(organizationId);

            var dtos = servicios.Select(s => new MedicalServiceResponseDTO
            {
                Id = s.Id,
                CategoryId = s.CategoryId,
                Name = s.Name,
                BasePrice = s.BasePrice,
                SkuCode = s.SkuCode,
                CreatedAt = s.CreatedAt
            });

            return BaseResponse<IEnumerable<MedicalServiceResponseDTO>>.Success(dtos);
        }

        public async Task<BaseResponse<bool>> ActualizarPrecioBaseAsync(long servicioId, decimal nuevoPrecio, string notas)
        {
            var servicio = await _unitOfWork.Services.GetByIdAsync(servicioId);
            if (servicio == null) return BaseResponse<bool>.Failure("El servicio no existe");

            servicio.BasePrice = nuevoPrecio;
            servicio.AuditNotes = notas;

            var actualizado = await _unitOfWork.Services.UpdateAsync(servicio);
            return BaseResponse<bool>.Success(actualizado, "Precio actualizado correctamente");
        }
    }
}
