﻿using MedfarLabs.Core.Application.Features.Inventory.Dtos.Request;
using MedfarLabs.Core.Application.Features.Inventory.Dtos.Response;
using MedfarLabs.Core.Domain.Common.Responses.Generic;

namespace MedfarLabs.Core.Application.Features.Inventory.Interfaces
{
    public interface IInventoryService
    {
        Task<BaseResponse<long>> RegistrarServicioAsync(MedicalServiceRequestDTO request);
        Task<BaseResponse<IEnumerable<MedicalServiceResponseDTO>>> ObtenerServiciosPorOrganizacionAsync(long organizationId);
        Task<BaseResponse<bool>> ActualizarPrecioBaseAsync(long servicioId, decimal nuevoPrecio, string notas);
    }
}
