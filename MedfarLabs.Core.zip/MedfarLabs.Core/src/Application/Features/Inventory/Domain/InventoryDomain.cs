﻿using MedfarLabs.Core.Application.Features.Inventory.Interfaces;
using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Application.Features.Inventory.Dispatcher
{
    public class InventoryDomain : BaseDomain
    {
        public InventoryDomain(IServiceProvider sp)
            : base(typeof(InventoryDomain).Assembly, sp)
        {
            // Mapeo de acciones a IInventoryService
            RegisterActionHandler<IInventoryService>(AppAction.RegistrarServicio, nameof(IInventoryService.RegistrarServicioAsync));
            //RegisterActionHandler<IInventoryService>("ActualizarStock", nameof(IInventoryService.ActualizarStockAsync));
            //RegisterActionHandler<IInventoryService>("RegistrarCategoria", nameof(IInventoryService.RegistrarCategoriaAsync));
        }
        public override AppModule Module => AppModule.Inventory;
    }
}
