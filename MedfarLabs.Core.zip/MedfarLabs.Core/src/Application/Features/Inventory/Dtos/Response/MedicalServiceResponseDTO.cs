﻿using System.Text.Json.Serialization;

namespace MedfarLabs.Core.Application.Features.Inventory.Dtos.Response
{
    public record MedicalServiceResponseDTO
    {
        [JsonPropertyName("id")]
        public long Id { get; init; }

        [JsonPropertyName("categoria_id")]
        public int CategoryId { get; init; }

        [JsonPropertyName("nombre_servicio")]
        public string? Name { get; init; }

        [JsonPropertyName("precio_base")]
        public decimal BasePrice { get; init; }

        [JsonPropertyName("codigo_sku")]
        public string? SkuCode { get; init; }

        [JsonPropertyName("esta_activo")]
        public bool IsActive { get; init; }

        [JsonPropertyName("fecha_registro")]
        public DateTime CreatedAt { get; init; }
    }
}
