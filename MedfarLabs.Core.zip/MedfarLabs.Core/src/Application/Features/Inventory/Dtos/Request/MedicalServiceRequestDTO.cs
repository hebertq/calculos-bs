﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Inventory.Dtos.Request
{
    [ActionMapping(AppModule.Inventory, AppAction.RegistrarServicio)]
    public record MedicalServiceRequestDTO : IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }

        [JsonPropertyName("categoria_id")]
        public int CategoryId { get; init; } // 1: Consulta, 2: Lab, 3: Procedimiento

        [JsonPropertyName("nombre_servicio")]
        public string? Name { get; init; }

        [JsonPropertyName("precio_base")]
        public decimal BasePrice { get; init; }

        [JsonPropertyName("codigo_sku")]
        public string? SkuCode { get; init; }

        [JsonPropertyName("notas_auditoria")]
        public string? AuditNotes { get; init; }
    }

    //public class RegistrarServicioMedicoRules : BaseValidationRuleSet<MedicalServiceRequestDTO>
    //{
    //    public RegistrarServicioMedicoRules(MedicalServiceRequestDTO dto)
    //    {
    //        SetBusinessObject(dto);

    //        // Campos Requeridos con Nombres Amigables
    //        ValidateRequired(p => p.OrganizationId, nameof(dto.OrganizationId), "Identificador de la Organización");
    //        ValidateRequired(p => p.CategoryId, nameof(dto.CategoryId), "Categoría del Servicio (Consulta/Laboratorio)");
    //        ValidateRequired(p => p.Name, nameof(dto.Name), "Nombre del Servicio o Examen");
    //        ValidateRequired(p => p.BasePrice, nameof(dto.BasePrice), "Precio Base de Venta");

    //        // Reglas de Negocio Específicas
    //        AddRule(p => p.BasePrice >= 0, nameof(dto.BasePrice), "El precio del servicio no puede ser un valor negativo");

    //        AddRule(p => !string.IsNullOrWhiteSpace(p.Name) && p.Name.Length >= 3,
    //            nameof(dto.Name), "El nombre del servicio debe ser descriptivo (mínimo 3 caracteres)");

    //        if (dto.CategoryId == 2) // Ejemplo: Si es Laboratorio
    //        {
    //            ValidateRequired(p => p.SkuCode, nameof(dto.SkuCode), "Código técnico/SKU (Requerido para exámenes de laboratorio)");
    //        }
    //    }
    //}
}
