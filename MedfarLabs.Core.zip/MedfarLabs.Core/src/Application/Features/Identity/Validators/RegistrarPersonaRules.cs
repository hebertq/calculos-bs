﻿using MedfarLabs.Core.Application.Common.Validators;
using MedfarLabs.Core.Application.Features.Identity.Dtos.Request;
using MedfarLabs.Core.Domain.Interfaces.Repositories;

namespace MedfarLabs.Core.Application.Features.Identity.Validators
{
    public class RegistrarPersonaRules : BaseValidationRuleSet<PersonRequestDTO>
    {
        private readonly IUnitOfWork _unitOfWork;

        public RegistrarPersonaRules(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;

            // 1. Definimos las reglas estructurales en el constructor
            ValidateRequired(p => p.FirstName, nameof(BusinessObject.FirstName), "Primer Nombre");
            ValidateRequired(p => p.Email, nameof(BusinessObject.Email), "Correo");
        }

        public override async Task ExecuteValidationAsync()
        {
            // 2. Ejecutamos validaciones síncronas (Estructurales)
            ValidateStructuralRules();

            // 3. Si no hay errores básicos, vamos a la DB (Opcional, podrías querer todos los errores siempre)
            if (ErrorList.Count == 0 && BusinessObject != null)
            {
                var existe = await _unitOfWork.Persons.ExistsByEmailAsync(BusinessObject.Email);
                if (existe)
                {
                    AddError("Este correo ya está registrado", nameof(BusinessObject.Email));
                }
            }

            // 4. Lanzamos la excepción con la lista completa de lo que falló
            ThrowIfInvalid();
        }
    }
}
