﻿using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Application.Features.Identity.Domain
{
    public class IdentityDomain : BaseDomain
    {
        public IdentityDomain(IServiceProvider sp)
            : base(typeof(IdentityDomain).Assembly, sp)
        {
            RegisterActionHandler<IIdentityService>(AppAction.RegistrarOrganizacion, nameof(IIdentityService.RegistrarOrganizacionAsync));
            RegisterActionHandler<IIdentityService>(AppAction.RegistrarPersona, nameof(IIdentityService.RegistrarPersonaAsync));
            RegisterActionHandler<IIdentityService>(AppAction.RegistrarUsuario, nameof(IIdentityService.RegistrarUsuarioAsync));
        }
        public override AppModule Module => AppModule.Identity;
    }
}
