﻿using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Const;

namespace MedfarLabs.Core.Application.Features.Identity.Domain
{
    public class IdentityDomain : BaseDomain
    {
        public IdentityDomain(IServiceProvider sp)
            : base(typeof(IdentityDomain).Assembly, sp)
        {
            RegisterActionHandler<IIdentityService>(AppAction.Identity.RegistrarOrganizacion, nameof(IIdentityService.RegistrarOrganizacionAsync));
            RegisterActionHandler<IIdentityService>(AppAction.Identity.RegistrarPersona, nameof(IIdentityService.RegistrarPersonaAsync));
            RegisterActionHandler<IIdentityService>(AppAction.Identity.RegistrarUsuario, nameof(IIdentityService.RegistrarUsuarioAsync));
            RegisterActionHandler<IIdentityService>(AppAction.Identity.RegistrarSucursal, nameof(IIdentityService.RegistrarSucursalAsync));
            //RegisterActionHandler<IIdentityService>(AppAction.Identity.RegistrarConsultorio, nameof(IIdentityService.RegistrarConsultorioAsync));
        }
        public override AppModule Module => AppModule.Identity;
    }
}
