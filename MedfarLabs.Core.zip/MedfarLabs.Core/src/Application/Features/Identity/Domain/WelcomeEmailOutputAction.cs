﻿using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Features.Identity.Dtos.Request;
using MedfarLabs.Core.Application.Features.Security.Dtos;
using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Application.Features.Identity.Domain
{
    public class WelcomeEmailOutputAction : IOutputAction
    {
        private readonly IEmailService _emailService;

        public WelcomeEmailOutputAction(IEmailService emailService)
        {
            _emailService = emailService;
        }

        public bool ShouldExecute(OutputContextDto context)
        {
            // 1. Filtramos: Solo si es el registro de persona y fue exitoso
            return context.ActionId == (int)AppAction.RegistrarPersona
                   && context.Response.IsSuccess;
        }

        public async Task ExecuteAsync(OutputContextDto context)
        {
            // 2. Casteamos el DTO para obtener los datos necesarios
            // El context.Dto ya viene blindado e inyectado desde el BaseDomain
            if (context.Dto is PersonRequestDTO person)
            {
                var subject = "¡Bienvenido a MedfarLabs!";
                var body = $"Hola {person.FirstName}, gracias por registrarte.";

                await _emailService.SendEmailAsync(person.Email, subject, body);
            }
        }
    }
}
