﻿using System.Text;
using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Common.Services;
using MedfarLabs.Core.Application.Features.Identity.Dtos.Request;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Entities.Identity;
using MedfarLabs.Core.Domain.Interfaces.Repositories;
using MedfarLabs.Core.Domain.Interfaces.Security;

namespace MedfarLabs.Core.Application.Features.Identity.Services
{
    public class IdentityService : BaseService, IIdentityService
    {
        private readonly IHashService _hashService;

        public IdentityService(IUnitOfWork uow, IApplicationDispatcher dispatcher, IHashService hashService)
        : base(uow, dispatcher) 
        {
            _hashService = hashService;
        }

        public async Task<BaseResponse<long>> RegistrarPersonaAsync(PersonRequestDTO request)
        {
            var person = new Person
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                BirthDate = request.BirthDate,
                GenderId = request.GenderId,
                BirthCountryId = request.BirthCountryId,
                PersonUuid = Guid.NewGuid(),
                BiometricHash = GenerarBiometricHash(request),
                Email = _hashService.GenerateHash(request.Email),
            };

            var id = await _unitOfWork.Persons.AddAsync(person);
            return BaseResponse<long>.Success(id, "Persona registrada exitosamente");
        }

        private byte[] GenerarBiometricHash(PersonRequestDTO request)
        {
            // 1. Normalización y manejo de nulos/vacíos
            // Usamos ToUpperInvariant para que 'Juan' y 'JUAN' generen el mismo hash
            var firstName = (request.FirstName ?? "").Trim().ToUpperInvariant();
            var middleName = (request.MiddleName ?? "").Trim().ToUpperInvariant();
            var lastName = (request.LastName ?? "").Trim().ToUpperInvariant();
            var secondLastName = (request.SecondLastName ?? "").Trim().ToUpperInvariant();

            // 2. Formateo de fecha (ISO 8601: YYYY-MM-DD) para consistencia
            var birthDate = request.BirthDate.ToString("yyyyMMdd");

            // 3. Construcción de la cadena base con delimitadores
            // Estructura: PaisId#Nombre1|Nombre2|Apellido1|Apellido2|Fecha
            var rawBiometricData = $"{request.BirthCountryId}#{firstName}{middleName}{lastName}{secondLastName}#{birthDate}";

            return _hashService.GenerateHash(rawBiometricData);
        }
        public async Task<BaseResponse<long>> RegistrarOrganizacionAsync(OrganizationRequestDTO request)
        {
            var org = new Organization
            {
                Name = request.Name,
                OrganizationUuid = Guid.NewGuid(),
                IsActive = true,
                AuditNotes = request.AuditNotes
            };

            var id = await _unitOfWork.Organizations.AddAsync(org);
            return BaseResponse<long>.Success(id, "Organización creada exitosamente");
        }

        public async Task<BaseResponse<long>> RegistrarUsuarioAsync(UsuarioRequestDTO request)
        {
            // 1. Mapeo a la entidad de dominio (User)
            // Nota: En un entorno real aquí aplicarías hashing a la contraseña
            var user = new User
            {
                PersonId = request.PersonId,
                OrganizationId = request.OrganizationId,
                Username = request.Username,
                PasswordHash = Encoding.UTF8.GetBytes(request.Password),
                IsActive = request.IsActive,
                AuditNotes = "Usuario creado vía proceso de registro/seeder"
            };

            // 2. Guardar a través del Repositorio de Usuarios
            var userId = await _unitOfWork.Users.AddAsync(user);

            return BaseResponse<long>.Success(userId, "Usuario registrado exitosamente.");
        }        
    }
}
