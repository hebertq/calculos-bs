﻿namespace MedfarLabs.Core.Application.Features.Identity.Dtos.Response
{
    public record PersonResponseDTO(long Id, Guid PersonUuid, string FullName, DateTime BirthDate, string Email);
}
