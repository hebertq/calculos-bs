﻿namespace MedfarLabs.Core.Application.Features.Identity.Dtos.Response
{
    public record BranchResponseDTO(
        long Id,
        string Name,
        string? Address,
        bool IsActive
    );
}
