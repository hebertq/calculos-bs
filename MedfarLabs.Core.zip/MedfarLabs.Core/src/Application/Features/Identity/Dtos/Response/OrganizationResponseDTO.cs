﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedfarLabs.Core.Application.Features.Identity.Dtos.Response
{
    class OrganizationResponseDTO
    {
    }
}
