﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Identity.Dtos.Request
{
    public record FacilityRoomRequestDTO(
    long BranchId,
    string Name,
    int TypeId
) : IHasOrganization, IHasUser
    {
        [JsonIgnore]
        public long OrganizationId { get; set; } // Inyectado automáticamente

        [JsonIgnore]
        public long UserId { get; set; }
    }
}
