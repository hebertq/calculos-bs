﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Identity.Dtos.Request
{
    public record UsuarioRequestDTO : IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }
        [JsonPropertyName("persona_id")]
        public long PersonId { get; init; }

        [JsonPropertyName("nombre_usuario")]
        public string Username { get; init; } = string.Empty;

        [JsonPropertyName("clave_acceso")]
        public string Password { get; init; } = string.Empty;

        [JsonPropertyName("esta_activo")]
        public bool IsActive { get; init; } = true;
    }   
}
