﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Identity.Dtos.Request
{
    [ActionMapping(AppModule.Identity, AppAction.RegistrarOrganizacion)]
    public record OrganizationRequestDTO(
        [property: JsonPropertyName("nombre_organizacion")] string Name,
        [property: JsonPropertyName("numero_fiscal")] string TaxId,
        [property: JsonPropertyName("notas_auditoria")] string? AuditNotes,
        [property: JsonPropertyName("notas_auditoria")] bool IsActive
    ) : IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }
    }

    public record OrganizationResponseDTO(long Id, Guid OrganizationUuid, string Name, bool IsActive, DateTime CreatedAt);

    //public class RegistrarOrganizacionRules : BaseValidationRuleSet<OrganizationRequestDTO>
    //{
    //    public RegistrarOrganizacionRules(OrganizationRequestDTO dto)
    //    {
    //        SetBusinessObject(dto);
    //        ValidateRequired(p => p.Name, nameof(dto.Name), "Nombre de la Organización");
    //        ValidateRequired(p => p.TaxId, nameof(dto.TaxId), "Número de Identificación Fiscal");
    //    }
    //}
}

