﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Identity.Dtos.Request
{
    // Application/Features/Identity/Dtos/Request/BranchRequestDTO.cs
    public record BranchRequestDTO(
        string Name,      //
        string? Address,   //
        bool IsActive = true
    ) : IHasOrganization, IHasUser
    {
        [JsonIgnore]
        public long OrganizationId { get; set; } // Inyectado automáticamente

        [JsonIgnore]
        public long UserId { get; set; }
    }
}
