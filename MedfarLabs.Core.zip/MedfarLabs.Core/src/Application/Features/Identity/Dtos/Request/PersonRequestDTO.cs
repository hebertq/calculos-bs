﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Identity.Dtos.Request
{
    [ActionMapping(AppModule.Identity, AppAction.RegistrarPersona)]
    public record PersonRequestDTO(
        [property: JsonPropertyName("primer_nombre")] string FirstName,
        [property: JsonPropertyName("segundo_nombre")] string? MiddleName,
        [property: JsonPropertyName("primer_apellido")] string LastName,
        [property: JsonPropertyName("segundo_apellido")] string? SecondLastName,
        [property: JsonPropertyName("fecha_nacimiento")] DateTime BirthDate,
        [property: JsonPropertyName("genero_id")] int GenderId,
        [property: JsonPropertyName("pais_nacimiento_id")] int BirthCountryId,
        [property: JsonPropertyName("correo")] string Email,
        [property: JsonPropertyName("telefono")] string MobilePhone
    ): IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }
    }
}
