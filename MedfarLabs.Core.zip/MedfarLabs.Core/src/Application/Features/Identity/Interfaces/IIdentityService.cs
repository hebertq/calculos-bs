﻿using MedfarLabs.Core.Application.Features.Identity.Dtos.Request;
using MedfarLabs.Core.Domain.Common.Responses.Generic;

namespace MedfarLabs.Core.Application.Features.Identity.Interfaces
{
    public interface IIdentityService
    {
        Task<BaseResponse<long>> RegistrarOrganizacionAsync(OrganizationRequestDTO request);
        Task<BaseResponse<long>> RegistrarPersonaAsync(PersonRequestDTO request);
        Task<BaseResponse<long>> RegistrarUsuarioAsync(UsuarioRequestDTO request);
    }
}
