﻿using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Common.Services;
using MedfarLabs.Core.Application.Features.Billing.Dtos.Request;
using MedfarLabs.Core.Application.Features.Billing.Interfaces;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Entities.Billing;
using MedfarLabs.Core.Domain.Interfaces.Repositories;

namespace MedfarLabs.Core.Application.Features.Billing.Services
{
    public class BillingService : BaseService, IBillingService
    {
        public BillingService(IUnitOfWork uow,IApplicationDispatcher dispatcher)
        : base(uow, dispatcher) { }

        public async Task<BaseResponse<long>> RegistrarPagoAsync(PaymentRequestDTO request)
        {
            // 1. Lógica de negocio: ¿La factura existe y está pendiente?
            var invoice = await _unitOfWork.Payments.GetByInvoiceIdAsync(request.InvoiceId,request.OrganizationId);
            if (invoice == null) return BaseResponse<long>.Failure("Factura no encontrada.");

            // 2. Guardar pago en DB (Dapper)
            var paymentId = await _unitOfWork.Payments.AddAsync(new Payment
            {
                InvoiceId = request.InvoiceId,
                Amount = request.AmountPaid
            });

            // 3. EVENTO: Notificar al Dispatcher para procesos secundarios (Sincro Admin)
            await _dispatcher.PublishAsync(new PaymentEvent { PaymentId = paymentId });

            return BaseResponse<long>.Success(paymentId, "Pago registrado exitosamente.");
        }

        // Define a new class to wrap the long value for the dispatcher
        public class PaymentEvent
        {
            public long PaymentId { get; set; }
        }
        public async Task<BaseResponse<long>> GenerarFacturaAsync(InvoiceRequestDTO request)
        {
            return await ExecuteInTransactionAsync(async () =>
            {
                // El validador ya aseguró que Items != null, usamos '!' para el compilador
                var items = request.Items!;

                // 2. Cálculos financieros
                var subtotal = items.Sum(i => i.Quantity * i.UnitPrice);
                var total = subtotal; // Aquí podrías aplicar lógica de impuestos

                // 3. Persistir Cabecera
                var invoice = new Invoice
                {
                    OrganizationId = request.OrganizationId,
                    PatientId = request.PatientId,
                    InvoiceNumber = request.InvoiceNumber ?? string.Empty,
                    StatusId = 1, // 1: Emitida/Pendiente
                    Subtotal = subtotal,
                    TotalAmount = total,
                    AuditNotes = request.AuditNotes
                };

                var invoiceId = await _unitOfWork.Invoices.AddAsync(invoice);

                // 4. Persistir Detalles
                foreach (var item in items)
                {
                    await _unitOfWork.InvoiceItems.AddAsync(new InvoiceItem
                    {
                        InvoiceId = invoiceId,
                        ServiceId = item.ServiceId,
                        Quantity = item.Quantity,
                        UnitPrice = item.UnitPrice,
                        LineTotal = item.Quantity * item.UnitPrice
                    });
                }

                return BaseResponse<long>.Success(invoiceId, $"Factura {request.InvoiceNumber} procesada.");
            });
        }
    }
}
