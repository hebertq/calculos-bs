﻿using MedfarLabs.Core.Application.Features.Billing.Interfaces;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Const;
namespace MedfarLabs.Core.Application.Features.Billing.Domain
{
    public class BillingDomain : BaseDomain
    {
        public BillingDomain(IServiceProvider sp)
            : base(typeof(BillingDomain).Assembly, sp)
        {
            // Mapeo de acciones a IBillingService
            RegisterActionHandler<IBillingService>(AppAction.Billling.GenerarFactura, nameof(IBillingService.GenerarFacturaAsync));
            RegisterActionHandler<IBillingService>(AppAction.Billling.RegistrarPago, nameof(IBillingService.RegistrarPagoAsync));
            //RegisterActionHandler<IBillingService>("AnularFactura", nameof(IBillingService.AnularFacturaAsync));
        }
        public override AppModule Module => AppModule.Billing;
    }
}
