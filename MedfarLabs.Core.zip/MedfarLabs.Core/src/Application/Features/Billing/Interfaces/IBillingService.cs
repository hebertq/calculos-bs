﻿using MedfarLabs.Core.Application.Features.Billing.Dtos.Request;
using MedfarLabs.Core.Domain.Common.Responses.Generic;

namespace MedfarLabs.Core.Application.Features.Billing.Interfaces
{
    public interface IBillingService
    {
        // Genera el documento de cobro basado en la consulta o laboratorio
        Task<BaseResponse<long>> GenerarFacturaAsync(InvoiceRequestDTO request);

        // Registra el ingreso de dinero (Efectivo, Tarjeta, Seguro)
        Task<BaseResponse<long>> RegistrarPagoAsync(PaymentRequestDTO request);
    }
}
