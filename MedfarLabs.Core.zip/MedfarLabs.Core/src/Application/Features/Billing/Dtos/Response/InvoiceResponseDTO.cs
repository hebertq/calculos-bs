﻿using System.Text.Json.Serialization;

namespace MedfarLabs.Core.Application.Features.Billing.Dtos.Response
{
    public record InvoiceResponseDTO
    {
        [JsonPropertyName("id")]
        public long Id { get; init; }

        [JsonPropertyName("numero_factura")]
        public string? InvoiceNumber { get; init; }

        [JsonPropertyName("paciente_nombre_completo")]
        public string? PatientFullName { get; init; }

        [JsonPropertyName("subtotal")]
        public decimal Subtotal { get; init; }

        [JsonPropertyName("total_impuestos")]
        public decimal TaxAmount { get; init; }

        [JsonPropertyName("total_final")]
        public decimal TotalAmount { get; init; }

        [JsonPropertyName("estado_pago")]
        public string? PaymentStatus { get; init; } // Ej: "Pagada", "Pendiente"

        [JsonPropertyName("items_facturados")]
        public List<InvoiceItemResponseDTO>? Items { get; init; }

        [JsonPropertyName("fecha_emision")]
        public DateTime CreatedAt { get; init; }
    }

    public record InvoiceItemResponseDTO(
        [property: JsonPropertyName("servicio_nombre")] string ServiceName,
        [property: JsonPropertyName("cantidad")] decimal Quantity,
        [property: JsonPropertyName("precio_unitario")] decimal UnitPrice,
        [property: JsonPropertyName("total_linea")] decimal LineTotal
    );
}
