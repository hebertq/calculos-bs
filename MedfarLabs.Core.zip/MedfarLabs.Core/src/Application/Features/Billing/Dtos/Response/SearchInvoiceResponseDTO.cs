﻿using System.Text.Json.Serialization;

namespace MedfarLabs.Core.Application.Features.Billing.Dtos.Response
{
    public record SearchInvoiceResponseDTO
    {
        [JsonPropertyName("factura_id")]
        public long Id { get; init; }

        [JsonPropertyName("numero_factura")]
        public string? InvoiceNumber { get; init; }

        [JsonPropertyName("paciente_nombre")]
        public string? PatientName { get; init; }

        [JsonPropertyName("total_facturado")]
        public decimal TotalAmount { get; init; }

        [JsonPropertyName("estado_nombre")]
        public string? StatusName { get; init; }

        [JsonPropertyName("fecha_emision")]
        public DateTime CreatedAt { get; init; }
    }
}
