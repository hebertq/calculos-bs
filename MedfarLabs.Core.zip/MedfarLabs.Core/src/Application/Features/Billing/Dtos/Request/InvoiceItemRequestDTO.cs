﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Billing.Dtos.Request
{
    public record InvoiceItemRequestDTO(
        [property: JsonPropertyName("servicio_id")] long ServiceId,
        [property: JsonPropertyName("cantidad")] decimal Quantity,
        [property: JsonPropertyName("precio_unitario")] decimal UnitPrice
    ) : IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }
    }
}
