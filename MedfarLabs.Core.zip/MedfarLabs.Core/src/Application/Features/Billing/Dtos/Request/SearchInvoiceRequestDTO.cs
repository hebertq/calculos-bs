﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Billing.Dtos.Request
{
    [ActionMapping(AppModule.Billing, AppAction.SearchInvoice)]
    public record SearchInvoiceRequestDTO : IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }

        [JsonPropertyName("paciente_id")]
        public long? PatientId { get; init; } // Opcional: buscar facturas de un paciente específico

        [JsonPropertyName("fecha_desde")]
        public DateTime? StartDate { get; init; } // Opcional: rango de inicio

        [JsonPropertyName("fecha_hasta")]
        public DateTime? EndDate { get; init; } // Opcional: rango de fin

        [JsonPropertyName("estado_pago_id")]
        public int? StatusId { get; init; } // Opcional: 1-Pendiente, 2-Pagada, etc.

        [JsonPropertyName("numero_factura")]
        public string? InvoiceNumber { get; init; } // Opcional: búsqueda exacta
    }

    //public class SearchInvoiceRules : BaseValidationRuleSet<SearchInvoiceRequestDTO>
    //{
    //    public SearchInvoiceRules(SearchInvoiceRequestDTO dto)
    //    {
    //        SetBusinessObject(dto);

    //        // La Organización es requerida para filtrar datos en modo SaaS
    //        ValidateRequired(p => p.OrganizationId, nameof(dto.OrganizationId), "Identificador de la Organización");

    //        // Validación de Rango de Fechas
    //        if (dto.StartDate.HasValue && dto.EndDate.HasValue)
    //        {
    //            AddRule(p => p.StartDate <= p.EndDate,
    //                nameof(dto.StartDate), "La fecha de inicio no puede ser posterior a la fecha de fin");

    //            AddRule(p => (dto.EndDate.Value - dto.StartDate.Value).TotalDays <= 365,
    //                nameof(dto.EndDate), "El rango de búsqueda no puede ser mayor a un año para mantener el rendimiento");
    //        }
    //    }
    //}
}
