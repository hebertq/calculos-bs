﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Billing.Dtos.Request
{
    [ActionMapping(AppModule.Billing, AppAction.GenerarFactura)]
    public record InvoiceRequestDTO : IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }

        [JsonPropertyName("paciente_id")]
        public long PatientId { get; init; } // ID del paciente a facturar

        [JsonPropertyName("numero_factura")]
        public string? InvoiceNumber { get; init; } // Número correlativo legal

        [JsonPropertyName("detalles_items")]
        public List<InvoiceItemRequestDTO>? Items { get; init; } // Lista de servicios aplicados

        [JsonPropertyName("notas_auditoria")]
        public string? AuditNotes { get; init; } // Motivo o referencia de la factura
    }

    //public class GenerarFacturaRules : BaseValidationRuleSet<InvoiceRequestDTO>
    //{
    //    public GenerarFacturaRules(InvoiceRequestDTO dto)
    //    {
    //        SetBusinessObject(dto);

    //        // Validaciones de Identidad
    //        ValidateRequired(p => p.OrganizationId, nameof(dto.OrganizationId), "Identificador de la Organización");
    //        ValidateRequired(p => p.PatientId, nameof(dto.PatientId), "Identificador del Paciente");
    //        ValidateRequired(p => p.InvoiceNumber, nameof(dto.InvoiceNumber), "Número de Factura");

    //        // Reglas de Estructura de Cobro
    //        AddRule(p => p.Items != null && p.Items.Count > 0,
    //            nameof(dto.Items), "La factura debe contener al menos un servicio o examen para procesarse");

    //        // Validación interna de ítems
    //        if (dto.Items != null)
    //        {
    //            foreach (var item in dto.Items)
    //            {
    //                AddRule(p => item.Quantity > 0, "Cantidad", $"La cantidad para el servicio {item.ServiceId} debe ser mayor a cero");
    //                AddRule(p => item.UnitPrice >= 0, "Precio Unitario", $"El precio para el servicio {item.ServiceId} no puede ser negativo");
    //            }
    //        }
    //    }
    //}
}
