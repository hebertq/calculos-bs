﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Billing.Dtos.Request
{
    [ActionMapping(AppModule.Billing, AppAction.RegistrarPago)]
    public record PaymentRequestDTO : IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }

        public long InvoiceId { get; init; }
        public int PaymentMethodId { get; init; } // 1: Cash, 2: Card, 3: Insurance
        public decimal AmountPaid { get; init; }
        public string TransactionReference { get; init; } = string.Empty;
    }
}
