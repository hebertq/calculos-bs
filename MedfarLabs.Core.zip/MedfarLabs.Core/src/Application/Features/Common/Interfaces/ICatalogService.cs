﻿using MedfarLabs.Core.Domain.Entities.Common;
using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Application.Features.Common.Interfaces
{
    public interface ICatalogService
    {
        Task<IEnumerable<CatalogDetail>> GetCatalogAsync(CatalogType catalog);
        Task<CatalogDetail?> GetItemByCodeAsync(CatalogType catalog, string code);
        Task<T?> GetMetadataAsync<T>(CatalogType catalog, string code) where T : class;
        Task<IEnumerable<CatalogDetail>> GetActiveItemsAsync();
        void ClearCache(CatalogType catalog); // Para cuando necesites forzar la actualización
    }
}
