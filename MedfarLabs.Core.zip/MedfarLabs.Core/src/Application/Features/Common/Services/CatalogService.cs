﻿using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Common.Services;
using MedfarLabs.Core.Application.Features.Common.Interfaces;
using MedfarLabs.Core.Domain.Entities.Common;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories;
using Microsoft.Extensions.Caching.Memory;

namespace MedfarLabs.Core.Application.Features.Common.Services
{
    public class CatalogService : BaseService,ICatalogService
    {
        private readonly IMemoryCache _cache;
        private const string CacheKeyPrefix = "Catalog_";
        private readonly TimeSpan _defaultCacheDuration = TimeSpan.FromHours(1);

        public CatalogService(IUnitOfWork uow, IApplicationDispatcher dispatcher, IMemoryCache cache) : base(uow, dispatcher) 
        {
            _cache = cache;
        }

        public async Task<IEnumerable<CatalogDetail>> GetCatalogAsync(CatalogType catalog)
        {
            string cacheKey = $"{CacheKeyPrefix}{(int)catalog}";

            if (!_cache.TryGetValue(cacheKey, out IEnumerable<CatalogDetail>? items))
            {
                // Cache Miss: Ir a la base de datos
                items = await _unitOfWork.Catalogs.GetByCatalogAsync(catalog);

                // Configuración de expiración
                var cacheOptions = new MemoryCacheEntryOptions()
                    .SetSlidingExpiration(TimeSpan.FromMinutes(20)) // Se mantiene vivo si se usa
                    .SetAbsoluteExpiration(_defaultCacheDuration); // Muere sí o sí a la hora

                _cache.Set(cacheKey, items, cacheOptions);
            }

            return items ?? Enumerable.Empty<CatalogDetail>();
        }

        public async Task<CatalogDetail?> GetItemByCodeAsync(CatalogType catalog, string code)
        {
            // Buscamos en el catálogo ya cacheado para evitar llamadas extras
            var items = await GetCatalogAsync(catalog);
            return items.FirstOrDefault(i => i.Code.Equals(code, StringComparison.OrdinalIgnoreCase));
        }

        public async Task<T?> GetMetadataAsync<T>(CatalogType catalog, string code) where T : class
        {
            // Usamos el repositorio para la deserialización inteligente del JSONB
            return await _unitOfWork.Catalogs.GetMetadataAsync<T>(catalog, code);
        }

        public void ClearCache(CatalogType catalog)
        {
            _cache.Remove($"{CacheKeyPrefix}{(int)catalog}");
        }

        public async Task<IEnumerable<CatalogDetail>> GetActiveItemsAsync()
        {
            const string cacheKey = $"{CacheKeyPrefix}ActiveItems";
            if (!_cache.TryGetValue(cacheKey, out IEnumerable<CatalogDetail>? items))
            {
                items = await _unitOfWork.Catalogs.GetActiveItemsAsync();
                var cacheOptions = new MemoryCacheEntryOptions()
                    .SetSlidingExpiration(TimeSpan.FromMinutes(20))
                    .SetAbsoluteExpiration(_defaultCacheDuration);

                _cache.Set(cacheKey, items, cacheOptions);
            }
            return items ?? Enumerable.Empty<CatalogDetail>();
        }
    }
}
