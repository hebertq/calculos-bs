﻿using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Domain.Common.Responses.Generic;

namespace MedfarLabs.Core.Application.Features.Clinical.Interfaces
{
    public interface IClinicalService
    {
        Task<BaseResponse<long>> RegistrarPacienteAsync(PatientRequestDTO request);
        Task<BaseResponse<long>> RegistrarSignosVitalesAsync(VitalSignsRequestDTO request);
        Task<BaseResponse<long>> RegistrarExpedienteMedicoAsync(MedicalRecordRequestDTO request);
    }
}
