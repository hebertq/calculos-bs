﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Clinical.Dtos.Request
{
    public record AntecedentRequestDTO(
    long PatientId,
    long TypeId,
    string Description
) : IHasOrganization, IHasUser
    {
        [JsonIgnore]
        public long OrganizationId { get; set; } // Inyectado automáticamente

        [JsonIgnore]
        public long UserId { get; set; }
    }
}
