﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Clinical.Dtos.Request
{
    public record MedicalRecordRequestDTO : IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }

        [JsonPropertyName("patient_id")]
        public long PatientId { get; init; }

        [JsonPropertyName("record_number")]
        public string RecordNumber { get; init; } = string.Empty;

        [JsonPropertyName("status_id")]
        public int StatusId { get; init; } // 1: Activo, 2: Pasivo, etc.
    }
}
