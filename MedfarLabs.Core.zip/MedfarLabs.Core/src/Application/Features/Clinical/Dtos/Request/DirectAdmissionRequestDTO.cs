﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Application.Features.Care.Dtos.Request;
using MedfarLabs.Core.Application.Features.Identity.Dtos.Request;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Clinical.Dtos.Request
{
    public record DirectAdmissionRequestDTO(
    PersonRequestDTO Person,
    string InternalCode,
    ConsultationRequestDTO Consultation,
    long? DoctorUserId
) : IHasOrganization, IHasUser
    {
        [JsonIgnore]
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }
    }
}
