﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Clinical.Dtos.Request
{
    [ActionMapping(AppModule.Clinical, AppAction.RegistrarSignos)]
    public record VitalSignsRequestDTO(
        [property: JsonPropertyName("paciente_id")] long PatientId,
        [property: JsonPropertyName("presion_sistolica")] decimal Systolic,
        [property: JsonPropertyName("presion_diastolica")] decimal Diastolic,
        [property: JsonPropertyName("frecuencia_cardiaca")] int HeartRate,
        [property: JsonPropertyName("temperatura")] decimal Temperature,
        [property: JsonPropertyName("peso_kg")] decimal Weight,
        [property: JsonPropertyName("estatura_cm")] decimal Height
    ) : IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }
    }

    //public class RegistrarSignosVitalesRules : BaseValidationRuleSet<VitalSignsRequestDTO>
    //{
    //    public RegistrarSignosVitalesRules(VitalSignsRequestDTO dto)
    //    {
    //        SetBusinessObject(dto);
    //        ValidateRequired(p => p.PatientId, nameof(dto.PatientId), "ID del Paciente");
    //        AddRule(p => p.Temperature > 30 && p.Temperature < 45, nameof(dto.Temperature), "La temperatura está fuera de rango humano normal");
    //        AddRule(p => p.Weight > 0, nameof(dto.Weight), "El peso debe ser mayor a cero");
    //    }
    //}
}
