﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Clinical.Dtos.Request
{
    [ActionMapping(AppModule.Clinical, AppAction.GenerarFactura)]
    public record PatientRequestDTO : IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }
        [JsonPropertyName("persona_id")]
        public long PersonId { get; init; }

        [JsonPropertyName("codigo_interno")]
        public string InternalCode { get; init; } = string.Empty;

        // Puedes agregar una propiedad opcional para auditoría si lo deseas
        [JsonPropertyName("notas_auditoria")]
        public string? AuditNotes { get; init; }
    }

    //public class RegistrarPacienteRules : BaseValidationRuleSet<PatientRequestDTO>
    //{
    //    public RegistrarPacienteRules(PatientRequestDTO dto)
    //    {
    //        SetBusinessObject(dto);
    //        ValidateRequired(p => p.PersonId, nameof(dto.PersonId), "Identificador de Persona");
    //        ValidateRequired(p => p.OrganizationId, nameof(dto.OrganizationId), "Identificador de Organización");
    //        ValidateRequired(p => p.InternalCode, nameof(dto.InternalCode), "Código Interno de Clínica");
    //    }
    //}
}
