﻿namespace MedfarLabs.Core.Application.Features.Clinical.Dtos.Response
{
    public record PatientResponseDTO(long Id, string InternalCode, string FullName);
}
