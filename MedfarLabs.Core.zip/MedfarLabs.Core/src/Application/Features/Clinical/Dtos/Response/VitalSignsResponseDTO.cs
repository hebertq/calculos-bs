﻿namespace MedfarLabs.Core.Application.Features.Clinical.Dtos.Response
{
    public record VitalSignsResponseDTO(long Id, decimal Temperature, decimal BMI, DateTime CreatedAt);
}
