﻿using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Common.Services;
using MedfarLabs.Core.Application.Features.Care.Dtos.Request;
using MedfarLabs.Core.Application.Features.Care.Interfaces;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;
using MedfarLabs.Core.Application.Features.Identity.Interfaces;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Entities.Clinical;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories;

namespace MedfarLabs.Core.Application.Features.Clinical.Services
{
    public class ClinicalService : BaseService, IClinicalService
    {
        private readonly IIdentityService _identityService;
        private readonly IMedicalCareService _medicalCareService;
        public ClinicalService(IUnitOfWork uow, IApplicationDispatcher dispatcher, IIdentityService identityService, IMedicalCareService medicalCareService) : base(uow, dispatcher)
        {
            _identityService = identityService;
            _medicalCareService = medicalCareService;
        }
        public async Task<BaseResponse<long>> CreateDirectAdmissionAsync(DirectAdmissionRequestDTO request)
        {
            await _unitOfWork.BeginTransactionAsync();
            try
            {
                // 1. Crear Persona (Módulo Identity)
                var personId = await _identityService.RegistrarPersonaAsync(request.Person);

                // 2. Crear Paciente vinculado (Módulo Clinical)

                var patientId = await RegistrarPacienteAsync(new PatientRequestDTO{
                    PersonId = personId.Data,
                    OrganizationId = request.OrganizationId,
                    UserId = request.UserId
                });               

                // 3. Crear Expediente Médico (Módulo Clinical)
                var recordId = await RegistrarExpedienteMedicoAsync(new MedicalRecordRequestDTO
                {
                    PatientId = patientId.Data,
                });
                                  
                // 4. Crear Consulta (Módulo Care)
                var consultationId = await _medicalCareService.RegistrarConsultaMedicaAsync(
                                                new ConsultationRequestDTO(recordId.Data, request.DoctorUserId ?? request.UserId, 
                                                                           request.Consultation.Subjective, request.Consultation.Objective, 
                                                                           request.Consultation.Analysis, request.Consultation.Plan));

                await _unitOfWork.BeginTransactionAsync();

                return BaseResponse<long>.Success(consultationId.Data, "Direct admission and consultation processed successfully.");
            }
            catch (Exception ex)
            {
                await _unitOfWork.BeginTransactionAsync();
                return BaseResponse<long>.Failure($"Chained registration failed: {ex.Message}");
            }
        }
        public async Task<BaseResponse<long>> RegistrarPacienteAsync(PatientRequestDTO request)
        {
            var patient = new Patient
            {
                PersonId = request.PersonId,
                OrganizationId = request.OrganizationId,
                InternalCode = $"PAT-{Guid.NewGuid().ToString("N")[..8].ToUpper()}-{request.PersonId}",
                IsActive = true
            };

            var id = await _unitOfWork.Patients.AddAsync(patient);
            return BaseResponse<long>.Success(id, "Paciente vinculado correctamente");
        }

        public async Task<BaseResponse<long>> RegistrarSignosVitalesAsync(VitalSignsRequestDTO request)
        {
            var vs = new VitalSigns
            {
                PatientId = request.PatientId,
                Temperature = request.Temperature,
                WeightKg = request.Weight,
                SystolicPressure = request.Systolic,
                DiastolicPressure = request.Diastolic,
                HeartRate = request.HeartRate
            };

            var id = await _unitOfWork.VitalSigns.AddAsync(vs);
            return BaseResponse<long>.Success(id, "Signos vitales guardados");
        }

        public async Task<BaseResponse<long>> RegistrarExpedienteMedicoAsync(MedicalRecordRequestDTO request)
        {
            var catData = await _unitOfWork.Catalogs.GetByCodeAsync(CatalogType.MedicalRecordStatus,"ACT");

            if (catData is null) {
                return BaseResponse<long>.Failure("No se encontró el estado 'ACT' para el expediente médico.");
            }
            // 1. Mapeo DTO -> Entidad
            var entity = new MedicalRecord
            {
                PatientId = request.PatientId,
                RecordNumber = $"REC-{Guid.NewGuid().ToString("N")[..8].ToUpper()}-{request.PatientId}",
                StatusId = catData.Id,
                AuditNotes = "Expediente generado por el sistema"
            };

            // 2. Persistencia vía UnitOfWork
            // Asegúrate de que 'MedicalRecords' esté definido en tu IUnitOfWork
            var id = await _unitOfWork.MedicalRecords.AddAsync(entity);

            return BaseResponse<long>.Success(id, "Expediente médico creado exitosamente.");
        }

        public async Task<BaseResponse<long>> RegistrarAntecedenteAsync(AntecedentRequestDTO request)
        {
            var entity = new PatientAntecedent
            {
                PatientId = request.PatientId,
                TypeId = request.TypeId,
                Description = request.Description,
                IsActive = true,
                CreatedByUserId = request.UserId // Inyectado por IHasUser
            };

            var id = await _unitOfWork.Antecedents.AddAsync(entity);
            return BaseResponse<long>.Success(id, "Antecedente clínico registrado.");
        }

        public async Task<BaseResponse<long>> RegistrarConsultaAsync(AntecedentRequestDTO request)
        {
            var entity = new PatientAntecedent
            {
                PatientId = request.PatientId,
                TypeId = request.TypeId,
                Description = request.Description,
                IsActive = true,
                CreatedByUserId = request.UserId // Inyectado por IHasUser
            };

            var id = await _unitOfWork.Antecedents.AddAsync(entity);
            return BaseResponse<long>.Success(id, "Antecedente clínico registrado.");
        }
    }
}
