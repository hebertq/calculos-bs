﻿using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Common.Services;
using MedfarLabs.Core.Application.Features.Clinical.Dtos.Request;
using MedfarLabs.Core.Application.Features.Clinical.Interfaces;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Entities.Clinical;
using MedfarLabs.Core.Domain.Interfaces.Repositories;

namespace MedfarLabs.Core.Application.Features.Clinical.Services
{
    public class ClinicalService : BaseService, IClinicalService
    {
        public ClinicalService(IUnitOfWork uow, IApplicationDispatcher dispatcher) : base(uow, dispatcher) { }

        public async Task<BaseResponse<long>> RegistrarPacienteAsync(PatientRequestDTO request)
        {
            var patient = new Patient
            {
                PersonId = request.PersonId,
                OrganizationId = request.OrganizationId,
                InternalCode = request.InternalCode,
                IsActive = true
            };

            var id = await _unitOfWork.Patients.AddAsync(patient);
            return BaseResponse<long>.Success(id, "Paciente vinculado correctamente");
        }

        public async Task<BaseResponse<long>> RegistrarSignosVitalesAsync(VitalSignsRequestDTO request)
        {
            var vs = new VitalSigns
            {
                PatientId = request.PatientId,
                Temperature = request.Temperature,
                WeightKg = request.Weight,
                SystolicPressure = request.Systolic,
                DiastolicPressure = request.Diastolic,
                HeartRate = request.HeartRate
            };

            var id = await _unitOfWork.VitalSigns.AddAsync(vs);
            return BaseResponse<long>.Success(id, "Signos vitales guardados");
        }

        public async Task<BaseResponse<long>> RegistrarExpedienteMedicoAsync(MedicalRecordRequestDTO request)
        {
            // 1. Mapeo DTO -> Entidad
            var entity = new MedicalRecord
            {
                PatientId = request.PatientId,
                RecordNumber = request.RecordNumber,
                StatusId = request.StatusId,
                AuditNotes = "Expediente generado por el sistema"
            };

            // 2. Persistencia vía UnitOfWork
            // Asegúrate de que 'MedicalRecords' esté definido en tu IUnitOfWork
            var id = await _unitOfWork.MedicalRecords.AddAsync(entity);

            return BaseResponse<long>.Success(id, "Expediente médico creado exitosamente.");
        }
    }
}
