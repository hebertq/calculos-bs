﻿using MedfarLabs.Core.Application.Features.Clinical.Interfaces;
using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Application.Features.Clinical.Domain
{
    // Ejemplo: Estrategia Clínica
    public class ClinicalDomain : BaseDomain
    {
        public ClinicalDomain(IServiceProvider sp) : base(typeof(ClinicalDomain).Assembly, sp)
        {
            // Registro de Mapeos: Acción -> Servicio -> Método
            RegisterActionHandler<IClinicalService>(AppAction.RegistrarPaciente, nameof(IClinicalService.RegistrarPacienteAsync));
            RegisterActionHandler<IClinicalService>(AppAction.RegistrarExpediente, nameof(IClinicalService.RegistrarExpedienteMedicoAsync));
            RegisterActionHandler<IClinicalService>(AppAction.RegistrarSignos, nameof(IClinicalService.RegistrarSignosVitalesAsync));
        }
        public override AppModule Module => AppModule.Clinical;
    }  
}
