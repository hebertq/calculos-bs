﻿using MedfarLabs.Core.Application.Features.Clinical.Interfaces;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Const;

namespace MedfarLabs.Core.Application.Features.Clinical.Domain
{
    // Ejemplo: Estrategia Clínica
    public class ClinicalDomain : BaseDomain
    {
        public ClinicalDomain(IServiceProvider sp) : base(typeof(ClinicalDomain).Assembly, sp)
        {
            // Registro de Mapeos: Acción -> Servicio -> Método
            RegisterActionHandler<IClinicalService>(AppAction.Clinical.RegistrarPaciente, nameof(IClinicalService.RegistrarPacienteAsync));
            RegisterActionHandler<IClinicalService>(AppAction.Clinical.RegistrarExpediente, nameof(IClinicalService.RegistrarExpedienteMedicoAsync));
            RegisterActionHandler<IClinicalService>(AppAction.Clinical.RegistrarSignosVitales, nameof(IClinicalService.RegistrarSignosVitalesAsync));
            RegisterActionHandler<IClinicalService>(AppAction.Clinical.RegistrarAntecedente, nameof(IClinicalService.RegistrarAntecedenteAsync));
            RegisterActionHandler<IClinicalService>(AppAction.Clinical.RegistrarConsultaDirecta, nameof(IClinicalService.CreateDirectAdmissionAsync));           
            //RegisterActionHandler<IClinicalService>(AppAction.Clinical.RegistrarAlergia, nameof(IClinicalService.RegistrarAlergiaAsync));
        }
        public override AppModule Module => AppModule.Clinical;
    }  
}
