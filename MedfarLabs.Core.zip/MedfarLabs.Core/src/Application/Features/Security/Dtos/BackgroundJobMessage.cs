﻿using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Application.Features.Security.Dtos
{
    public record BackgroundJobMessage(
        AppModule Module,
        int ActionId,
        long UserId,
        long OrganizationId,
        string RawInput,
        bool IsSuccess,
        long? ParentTelemetryId, // La herencia de telemetría
        long? ParentAuditId,      // La herencia de auditoría
        int Depth,              // Nivel de recursividad actual
        string? TraceId // ID único para agrupar toda la "cascada" de eventos
    );
}
