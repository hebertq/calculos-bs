﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Application.Features.Security.Dtos
{
    [ActionMapping(AppModule.Security, AppAction.CrearGrupoDeRoles)]
    public class RoleGroupRequestDto
    {
        // El ID de la organización es vital para el aislamiento Multi-tenant
        public long OrganizationId { get; set; }

        public string Name { get; set; } = string.Empty;

        public string? Description { get; set; }

        public bool IsActive { get; set; } = true;

        /// <summary>
        /// Lista de IDs de los Roles Globales (mst_role) que se 
        /// agruparán en esta organización.
        /// </summary>
        public List<int> RoleIds { get; set; } = new();
    }
}
