﻿using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Security;

namespace MedfarLabs.Core.Application.Features.Security.Dtos
{
    public class OutputContextDto
    {
        // 1. Identificación de la Acción
        public AppModule Module { get; }
        public int ActionId { get; }

        // 2. Datos de Negocio
        public object? Dto { get; }
        public string RawInput { get; }
        public BaseResponse<object> Response { get; }

        // 3. Contexto de Identidad y Tiempo
        public IUserContext UserContext { get; }
        public TimeSpan Duration { get; set; }

        // 4. RASTREO JERÁRQUICO (Recursividad)

        /// <summary>
        /// ID de Telemetría que viene del proceso padre (ej. desde el mensaje SQS).
        /// </summary>
        public long? ParentTelemetryId { get; init; }

        /// <summary>
        /// ID de Auditoría que viene del proceso padre.
        /// </summary>
        public long? ParentAuditId { get; init; }

        /// <summary>
        /// ID generado por la acción de telemetría en el proceso ACTUAL.
        /// Se llena dinámicamente para que las acciones hijas lo usen como Parent.
        /// </summary>
        public long? CurrentTelemetryId { get; set; }

        /// <summary>
        /// ID generado por la acción de auditoría en el proceso ACTUAL.
        /// </summary>
        public long? CurrentAuditId { get; set; }

        /// <summary>
        /// Nivel de recursividad actual. 0 es el inicio (Main).
        /// </summary>
        public int Depth { get; set; } = 0;

        public string? TraceId { get; set; }

        public OutputContextDto(
            AppModule module,
            int actionId,
            object? dto,
            string rawInput,
            BaseResponse<object> response,
            IUserContext userContext,
            TimeSpan duration,
            string? traceId = null,
            long? parentTelemetryId = null,
            long? parentAuditId = null,
            int depth = 0)
        {
            Module = module;
            ActionId = actionId;
            Dto = dto;
            RawInput = rawInput;
            Response = response;
            UserContext = userContext;
            Duration = duration;
            ParentTelemetryId = parentTelemetryId;
            ParentAuditId = parentAuditId;
            Depth = depth;
            TraceId = traceId;
        }
    }
}
