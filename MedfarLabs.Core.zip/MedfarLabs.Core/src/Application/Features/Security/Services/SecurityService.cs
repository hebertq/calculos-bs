﻿using MedfarLabs.Core.Application.Features.Security.Dtos;
using MedfarLabs.Core.Application.Features.Security.Interfaces;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Entities.Security;
using MedfarLabs.Core.Domain.Interfaces.Repositories;

namespace MedfarLabs.Core.Application.Features.Security.Services
{
    public class SecurityService : ISecurityService
    {
        private readonly IUnitOfWork _unitOfWork;

        public SecurityService(IUnitOfWork unitOfWork) => _unitOfWork = unitOfWork;

        public async Task<BaseResponse<long>> CreateRoleGroupWithRolesAsync(RoleGroupRequestDto request)
        {
            // 1. Crear el grupo para la organización
            var group = new RoleGroup
            {
                OrganizationId = request.OrganizationId,
                Name = request.Name,
                Description = request.Description,
                IsActive = true
            };

            var groupId = await _unitOfWork.RoleGroups.AddAsync(group);

            // 2. Asignar los roles globales seleccionados al grupo
            if (request.RoleIds != null && request.RoleIds.Any())
            {
                await _unitOfWork.Security.AssignRolesToGroupAsync(groupId, request.RoleIds);
            }

            return BaseResponse<long>.Success(groupId, "Grupo de roles configurado correctamente.");
        }
    }
}
