﻿using System.Text.Json;
using Amazon.SQS;
using Amazon.SQS.Model;
using Microsoft.Extensions.Logging;
using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Features.Security.Dtos;

namespace MedfarLabs.Core.Application.Features.Security.Events
{
    public class QueueOutputAction : IOutputAction
    {
        private readonly IAmazonSQS _sqsClient;
        private readonly ILogger<QueueOutputAction> _logger;
        private readonly string _queueUrl;
        private const int MAX_RECURSION_DEPTH = 3;
        public QueueOutputAction(IAmazonSQS sqsClient, ILogger<QueueOutputAction> logger)
        {
            _sqsClient = sqsClient;
            _logger = logger;
            // La URL de la cola se obtiene de las variables de entorno de la Lambda
            _queueUrl = Environment.GetEnvironmentVariable("JOBS_QUEUE_URL") ?? "";
        }

        /// <summary>
        /// Esta acción solo se ejecuta en el contexto 'Main' (API).
        /// Evitamos que el Worker se encole a sí mismo en un bucle infinito.
        /// </summary>
        public bool ShouldExecute(OutputContextDto context)
        {
            return Environment.GetEnvironmentVariable("EXECUTION_CONTEXT") == "Main";
        }

        public async Task ExecuteAsync(OutputContextDto context)
        {
            try
            {
                // VALIDACIÓN DE SEGURIDAD
                if (context.Depth >= MAX_RECURSION_DEPTH)
                {
                    _logger.LogCritical("LÍMITE DE RECURSIVIDAD ALCANZADO: Se abortó el encolado de la acción {ActionId} para evitar bucle infinito.", context.ActionId);
                    return; // Detenemos la cadena aquí
                }

                var message = new BackgroundJobMessage(
                    context.Module,
                    context.ActionId,
                    context.UserContext.UserId,
                    context.UserContext.OrganizationId,
                    context.RawInput,
                    context.Response.IsSuccess,
                    context.CurrentTelemetryId, // Tomamos el ID recién generado por TelemetryOutputAction
                    context.CurrentAuditId,      // Tomamos el ID recién generado por AuditOutputAction
                    context.Depth + 1,
                    context.TraceId
                );

                var request = new SendMessageRequest
                {
                    QueueUrl = _queueUrl,
                    MessageBody = JsonSerializer.Serialize(message),
                    // Opcional: MessageGroupId si usas colas FIFO para mantener orden por organización
                    MessageAttributes = new Dictionary<string, MessageAttributeValue>
                {
                    { "Module", new MessageAttributeValue { DataType = "String", StringValue = context.Module.ToString() } }
                }
                };

                await _sqsClient.SendMessageAsync(request);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "ERROR DE INFRAESTRUCTURA: No se pudo encolar el trabajo para Action {ActionId}", context.ActionId);
            }
        }
    }
}
