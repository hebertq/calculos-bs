﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Features.Security.Dtos;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Security.Events
{
    public class AuditOutputAction : IOutputAction
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<AuditOutputAction> _logger;
        private readonly string _executionContext;

        public AuditOutputAction(IServiceProvider serviceProvider, ILogger<AuditOutputAction> logger)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
            // Identificamos si estamos en la Lambda Principal o en el Worker
            _executionContext = Environment.GetEnvironmentVariable("EXECUTION_CONTEXT") ?? "Main";
        }

        /// <summary>
        /// La auditoría se ejecuta siempre que tengamos un usuario identificado.
        /// </summary>
        public bool ShouldExecute(OutputContextDto context) => context.UserContext.UserId > 0;

        public async Task ExecuteAsync(OutputContextDto context)
        {
            try
            {
                // Creamos un scope para resolver el repositorio de seguridad de forma segura
                using var scope = _serviceProvider.CreateScope();
                var securityRepo = scope.ServiceProvider.GetRequiredService<ISecurityRepository>();

                // 1. Recuperamos el ParentId si existe (viene de un proceso previo)
                var parentId = context.ParentAuditId;

                // 2. Registramos la auditoría y capturamos el ID generado
                // Usamos el RawInput capturado por el BaseDomain originalmente
                var currentAuditId = await securityRepo.RegisterAuditAsync(
                    context.UserContext.OrganizationId,
                    context.UserContext.UserId,
                    (int)context.Module,
                    context.ActionId,
                    context.RawInput,
                    context.Response.IsSuccess,
                    _executionContext,
                    parentId
                );

                // 3. PROPAGACIÓN DE RECURSIVIDAD:
                // Almacenamos el ID en el contexto. Si esta Lambda dispara una tarea a SQS,
                // la acción QueueOutputAction leerá este CurrentAuditId y lo enviará como Parent.
                context.CurrentAuditId = currentAuditId;

                _logger.LogDebug("Audit registrado: ID {Id} (Parent: {ParentId})", currentAuditId, parentId ?? 0);
            }
            catch (Exception ex)
            {
                // La auditoría es crítica pero no debe bloquear la respuesta al usuario.
                // Registramos un error crítico en los logs técnicos para intervención manual.
                _logger.LogCritical(ex, "FALLO DE AUDITORÍA: No se pudo registrar la acción {ActionId} para el usuario {UserId}",
                    context.ActionId, context.UserContext.UserId);
            }
        }
    }
}
