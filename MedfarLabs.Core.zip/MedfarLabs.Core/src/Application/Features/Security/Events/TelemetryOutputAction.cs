﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Features.Security.Dtos;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Security.Events
{
    public class TelemetryOutputAction : IOutputAction
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<TelemetryOutputAction> _logger;
        private readonly string _executionContext;

        public TelemetryOutputAction(IServiceProvider serviceProvider, ILogger<TelemetryOutputAction> logger)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
            // Identificamos si estamos en la Lambda Principal o en el Worker
            _executionContext = Environment.GetEnvironmentVariable("EXECUTION_CONTEXT") ?? "Main";
        }

        public bool ShouldExecute(OutputContextDto context) => true;

        public async Task ExecuteAsync(OutputContextDto context)
        {
            try
            {
                using var scope = _serviceProvider.CreateScope();
                var securityRepo = scope.ServiceProvider.GetRequiredService<ISecurityRepository>();

                // 1. Intentamos obtener el ParentId desde el contexto (si viene de SQS)
                // Si es la acción principal, este valor será null.
                var parentId = context.ParentTelemetryId;

                // 2. Extraemos información de error si existe
                var exceptionType = !context.Response.IsSuccess
                    ? context.Response.Message
                    : null;

                // 3. Registramos y OBTENEMOS el ID generado por Postgres
                var currentId = await securityRepo.RegisterTelemetryAsync(
                    context.UserContext.OrganizationId,
                    context.UserContext.UserId,
                    (int)context.Module,
                    context.ActionId,
                    context.Duration.TotalMilliseconds,
                    context.Response.IsSuccess,
                    exceptionType,
                    _executionContext,
                    parentId
                );

                // 4. PASO CRÍTICO PARA LA RECURSIVIDAD:
                // Seteamos el ID actual en el contexto para que las siguientes acciones 
                // (como QueueOutputAction) lo hereden como su ParentId.
                context.CurrentTelemetryId = currentId;

                // Log de consola para debugging rápido en CloudWatch
                if (context.Duration.TotalMilliseconds > 500)
                {
                    _logger.LogWarning("[TELEMETRÍA LENTA] {Module}.{Action} tomó {ms}ms (ID: {Id}, Parent: {Parent})",
                        context.Module, context.ActionId, context.Duration.TotalMilliseconds, currentId, parentId ?? 0);
                }
            }
            catch (Exception ex)
            {
                // Fallo silencioso: La telemetría nunca debe romper la respuesta al usuario
                _logger.LogCritical(ex, "Error fatal al persistir telemetría para la acción {ActionId}", context.ActionId);
            }
        }
    }
}
