﻿using MedfarLabs.Core.Application.Features.Security.Dtos;
using MedfarLabs.Core.Domain.Common.Responses.Generic;

namespace MedfarLabs.Core.Application.Features.Security.Interfaces
{
    public interface ISecurityService
    {
        Task<BaseResponse<long>> CreateRoleGroupWithRolesAsync(RoleGroupRequestDto request);
    }
}
