﻿using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Common.Services;
using MedfarLabs.Core.Application.Features.Laboratory.Dtos.Request;
using MedfarLabs.Core.Application.Features.Laboratory.Dtos.Response;
using MedfarLabs.Core.Application.Features.Laboratory.Interfaces;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Entities.Laboratory;
using MedfarLabs.Core.Domain.Entities.Public;
using MedfarLabs.Core.Domain.Interfaces.Repositories;

namespace MedfarLabs.Core.Application.Features.Laboratory.Services
{
    public class LaboratoryService : BaseService, ILaboratoryService
    {
        public LaboratoryService(IUnitOfWork uow, IApplicationDispatcher dispatcher) : base(uow, dispatcher) { }

        public async Task<BaseResponse<long>> RegistrarResultadoAsync(LabResultRequestDTO request)
        {
            // El DTO ya viene validado por el Dispatcher mediante RegistrarResultadoLaboratorioRules
            var entity = new LabResult
            {
                LabOrderId = request.LabOrderId,
                TechnicalDataJson = new JsonValue(request.TechnicalDataJson),
                //AttachmentUrl = request.AttachmentUrl,
                AuditNotes = "Resultado técnico cargado por personal de laboratorio"
            };

            var id = await _unitOfWork.LabResults.AddAsync(entity);
            return BaseResponse<long>.Success(id, "Resultado de laboratorio registrado exitosamente.");
        }

        public async Task<BaseResponse<LabResultResponseDTO>> ObtenerResultadoPorOrdenAsync(long orderId)
        {
            // Usamos el repositorio especializado inyectado en el UnitOfWork
            var resultado = await _unitOfWork.LabResults.GetByIdAsync(orderId);

            if (resultado == null)
                return BaseResponse<LabResultResponseDTO>.Failure("No se encontró un resultado para la orden proporcionada.");

            var response = new LabResultResponseDTO(
                resultado.Id,
                (int)resultado.LabOrderId, // En un escenario real, aquí se mapearía el tipo de examen desde la orden
                resultado.CreatedAt
            );

            return BaseResponse<LabResultResponseDTO>.Success(response);
        }

        public async Task<BaseResponse<long>> RegistrarOrdenAsync(LabOrderRequestDTO request)
        {
            var entity = new LabOrder
            {
                ConsultationId = request.ConsultationId,
                PatientId = request.PatientId,
                ServiceId = request.ServiceId,
                StatusId = request.StatusId,
                AuditNotes = request.AuditNotes
            };

            var id = await _unitOfWork.LabOrders.AddAsync(entity);
            return BaseResponse<long>.Success(id, "Orden de laboratorio generada correctamente.");
        }

        public async Task<BaseResponse<IEnumerable<LabOrderResponseDTO>>> ObtenerOrdenesPorPacienteAsync(long patientId)
        {
            var ordenes = await _unitOfWork.LabOrders.GetByPatientIdAsync(patientId);

            var dtos = ordenes.Select(o => new LabOrderResponseDTO(
                o.Id, o.ConsultationId, o.PatientId, o.ServiceId, o.StatusId, o.CreatedAt
            ));

            return BaseResponse<IEnumerable<LabOrderResponseDTO>>.Success(dtos);
        }
    }
}
