﻿using MedfarLabs.Core.Application.Features.Laboratory.Dtos.Request;
using MedfarLabs.Core.Application.Features.Laboratory.Dtos.Response;
using MedfarLabs.Core.Domain.Common.Responses.Generic;

namespace MedfarLabs.Core.Application.Features.Laboratory.Interfaces
{
    public interface ILaboratoryService
    {
        /// <summary>
        /// Registra los resultados técnicos de un examen procesado.
        /// </summary>
        Task<BaseResponse<long>> RegistrarResultadoAsync(LabResultRequestDTO request);

        /// <summary>
        /// Recupera el resultado técnico asociado a una orden específica.
        /// </summary>
        Task<BaseResponse<LabResultResponseDTO>> ObtenerResultadoPorOrdenAsync(long orderId);

        // Gestión de Órdenes
        /// <summary>
        /// Regoistrar una orden de laboratorio
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<BaseResponse<long>> RegistrarOrdenAsync(LabOrderRequestDTO request);

        /// <summary>
        /// Obtener las ordenes del laboratorio
        /// </summary>
        /// <param name="patientId"></param>
        /// <returns></returns>
        Task<BaseResponse<IEnumerable<LabOrderResponseDTO>>> ObtenerOrdenesPorPacienteAsync(long patientId);

    }
}
