﻿namespace MedfarLabs.Core.Application.Features.Laboratory.Dtos.Response
{
    /// <summary>
    /// DTO para devolver la información de una orden procesada.
    /// </summary>
    public record LabOrderResponseDTO(
        long Id,
        long? ConsultationId,
        long PatientId,
        long ServiceId,
        int StatusId,
        DateTime CreatedAt
    );
}
