﻿namespace MedfarLabs.Core.Application.Features.Laboratory.Dtos.Response
{
    public record LabResultResponseDTO(long Id, int TestTypeId, DateTime CreatedAt);
}
