﻿using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;
using System.Text.Json.Serialization;

namespace MedfarLabs.Core.Application.Features.Laboratory.Dtos.Request
{
    /// <summary>
    /// DTO para la creación de una nueva orden de laboratorio.
    /// </summary>
    public record LabOrderRequestDTO(
        long? ConsultationId,
        long PatientId,
        long ServiceId,
        int StatusId,
        string? AuditNotes = null
    ) : IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }
    }
}
