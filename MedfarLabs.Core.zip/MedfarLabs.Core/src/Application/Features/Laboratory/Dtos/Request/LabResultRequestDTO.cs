﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Laboratory.Dtos.Request
{
    [ActionMapping(AppModule.Laboratory, AppAction.RegistrarResultado)]
    public record LabResultRequestDTO : IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }
        [JsonPropertyName("orden_laboratorio_id")]
        public long LabOrderId { get; init; }

        [JsonPropertyName("estado_id")]
        public int StatusId { get; init; } = 1; // 1: Finalizado / Reportado

        [JsonPropertyName("datos_tecnicos_json")]
        public string TechnicalDataJson { get; init; } = string.Empty;

        [JsonPropertyName("observaciones")]
        public string? Observations { get; init; }

        [JsonPropertyName("notas_auditoria")]
        public string? AuditNotes { get; init; }
    }
    //public class RegistrarResultadoLaboratorioRules : BaseValidationRuleSet<LabResultRequestDTO>
    //{
    //    public RegistrarResultadoLaboratorioRules(LabResultRequestDTO dto)
    //    {
    //        SetBusinessObject(dto);
    //        ValidateRequired(p => p.LabOrderId, nameof(dto.LabOrderId), "ID de la Orden de Laboratorio");
    //        ValidateRequired(p => p.TechnicalDataJson, nameof(dto.TechnicalDataJson), "Datos Técnicos del Examen");
    //    }
    //}
}
