﻿using MedfarLabs.Core.Application.Features.Laboratory.Interfaces;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Const;

namespace MedfarLabs.Core.Application.Features.Laboratory.Domain
{
    public class LaboratoryDomain : BaseDomain
    {
        public LaboratoryDomain(IServiceProvider sp) : base(typeof(LaboratoryDomain).Assembly, sp)
        {
            RegisterActionHandler<ILaboratoryService>(AppAction.Laboratory.RegistrarOrden, nameof(ILaboratoryService.RegistrarOrdenAsync));
            RegisterActionHandler<ILaboratoryService>(AppAction.Laboratory.RegistrarResultado, nameof(ILaboratoryService.RegistrarResultadoAsync));
        }
        public override AppModule Module => AppModule.Laboratory;
    }
}
