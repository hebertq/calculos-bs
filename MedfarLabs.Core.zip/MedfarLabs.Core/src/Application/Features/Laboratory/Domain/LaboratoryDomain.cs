﻿using MedfarLabs.Core.Application.Features.Laboratory.Interfaces;
using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Application.Features.Laboratory.Domain
{
    public class LaboratoryDomain : BaseDomain
    {
        public LaboratoryDomain(IServiceProvider sp) : base(typeof(LaboratoryDomain).Assembly, sp)
        {
            RegisterActionHandler<ILaboratoryService>(AppAction.RegistrarOrden, nameof(ILaboratoryService.RegistrarOrdenAsync));
            RegisterActionHandler<ILaboratoryService>(AppAction.RegistrarResultado, nameof(ILaboratoryService.RegistrarResultadoAsync));
        }
        public override AppModule Module => AppModule.Laboratory;
    }
}
