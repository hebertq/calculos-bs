﻿using MedfarLabs.Core.Application.Features.Care.Interfaces;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Const;
namespace MedfarLabs.Core.Application.Features.Care.Domain
{
    public class MedicalCareDomain : BaseDomain
    {
        public MedicalCareDomain(IServiceProvider sp)
            : base(typeof(MedicalCareDomain).Assembly, sp)
        {
            // Mapeo de acciones a IMedicalCareService
            RegisterActionHandler<IMedicalCareService>(AppAction.Care.RegistrarConsulta, nameof(IMedicalCareService.RegistrarConsultaMedicaAsync));
            RegisterActionHandler<IMedicalCareService>(AppAction.Care.GestionarCita, nameof(IMedicalCareService.AgendarCitaAsync));
            RegisterActionHandler<IMedicalCareService>(AppAction.Care.CargarResultados, nameof(IMedicalCareService.CargarResultadoLaboratorioAsync));
            RegisterActionHandler<IMedicalCareService>(AppAction.Care.EmitirReceta, nameof(IMedicalCareService.EmitirRecetaAsync));
        }

        public override AppModule Module => AppModule.Care;
    }
}
