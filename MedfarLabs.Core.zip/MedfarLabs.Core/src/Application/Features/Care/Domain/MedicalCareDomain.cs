﻿using MedfarLabs.Core.Application.Features.Care.Interfaces;
using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Application.Features.Care.Domain
{
    public class MedicalCareDomain : BaseDomain
    {
        public MedicalCareDomain(IServiceProvider sp)
            : base(typeof(MedicalCareDomain).Assembly, sp)
        {
            // Mapeo de acciones a IMedicalCareService
            RegisterActionHandler<IMedicalCareService>(AppAction.RegistrarConsulta, nameof(IMedicalCareService.RegistrarConsultaMedicaAsync));
            //RegisterActionHandler<IMedicalCareService>("ActualizarDiagnostico", nameof(IMedicalCareService.ActualizarDiagnosticoAsync));
        }

        public override AppModule Module => AppModule.Care;
    }
}
