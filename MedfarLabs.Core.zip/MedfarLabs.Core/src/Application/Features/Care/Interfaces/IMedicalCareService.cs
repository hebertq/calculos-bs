﻿using MedfarLabs.Core.Application.Features.Care.Dtos.Request;
using MedfarLabs.Core.Application.Features.Laboratory.Dtos.Request;
using MedfarLabs.Core.Domain.Common.Responses.Generic;

namespace MedfarLabs.Core.Application.Features.Care.Interfaces
{
    public interface IMedicalCareService
    {
        Task<BaseResponse<long>> RegistrarConsultaMedicaAsync(ConsultationRequestDTO request);
        Task<BaseResponse<long>> CargarResultadoLaboratorioAsync(LabResultRequestDTO request);
    }
}
