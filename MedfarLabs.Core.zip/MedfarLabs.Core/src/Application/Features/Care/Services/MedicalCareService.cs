﻿using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Common.Services;
using MedfarLabs.Core.Application.Features.Care.Dtos.Request;
using MedfarLabs.Core.Application.Features.Care.Interfaces;
using MedfarLabs.Core.Application.Features.Laboratory.Dtos.Request;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Entities.Care;
using MedfarLabs.Core.Domain.Entities.Laboratory;
using MedfarLabs.Core.Domain.Entities.Public;
using MedfarLabs.Core.Domain.Interfaces.Repositories;

namespace MedfarLabs.Core.Application.Features.Care.Services
{
    public class MedicalCareService : BaseService, IMedicalCareService
    {
        public MedicalCareService(IUnitOfWork uow, IApplicationDispatcher dispatcher) : base(uow, dispatcher) {}
        public async Task<BaseResponse<long>> RegistrarConsultaMedicaAsync(ConsultationRequestDTO request)
        {
            // Orquestación atómica: Se registra la consulta y se podría disparar una orden de lab si fuera necesario
            return await ExecuteInTransactionAsync(async () =>
            {
                var consultation = new Consultation
                {
                    MedicalRecordId = request.MedicalRecordId,
                    DoctorUserId = request.DoctorUserId,
                    SubjectiveData = request.Subjective,
                    ObjectiveData = request.Objective,
                    AnalysisData = request.Analysis,
                    PlanData = request.Plan
                };

                var id = await _unitOfWork.Consultations.AddAsync(consultation);
                return BaseResponse<long>.Success(id, "Consulta médica registrada correctamente en el expediente");
            });
        }

        public async Task<BaseResponse<long>> CargarResultadoLaboratorioAsync(LabResultRequestDTO request)
        {
            var result = new LabResult
            {
                LabOrderId = request.LabOrderId,
                TechnicalDataJson = new JsonValue(request.TechnicalDataJson),
                //AttachmentUrl = request.AttachmentUrl,
                AuditNotes = "Resultado cargado vía servicio de laboratorio"
            };

            var id = await _unitOfWork.LabResults.AddAsync(result);
            return BaseResponse<long>.Success(id, "Resultado de laboratorio procesado exitosamente");
        }

        public async Task<BaseResponse<long>> AgendarCitaAsync(AppointmentRequestDTO request)
        {
            var entity = new Appointment
            {
                OrganizationId = request.OrganizationId,
                BranchId = request.BranchId,
                PatientId = request.PatientId,
                DoctorUserId = request.DoctorUserId,
                FacilityRoomId = request.FacilityRoomId,
                ScheduledDate = request.ScheduledDate,
                StartTime = request.StartTime,
                EndTime = request.EndTime,
                StatusId = request.StatusId,
                ReasonNotes = request.ReasonNotes,
                CreatedByUserId = request.UserId
            };

            var id = await _unitOfWork.Appointments.AddAsync(entity);
            return BaseResponse<long>.Success(id, "Cita agendada correctamente.");
        }

        public async Task<BaseResponse<long>> EmitirRecetaAsync(PrescriptionRequestDTO request)
        {
            await _unitOfWork.BeginTransactionAsync();

            try
            {
                // 1. Crear Cabecera
                var prescription = new Prescription
                {
                    ConsultationId = request.ConsultationId,
                    PatientId = request.PatientId,
                    DoctorUserId = request.UserId, // Inyectado por IHasUser
                    Notes = request.Notes
                };

                // Insertar cabecera dentro de la transacción
                var prescriptionId = await _unitOfWork.Prescriptions.AddAsync(prescription);

                // 2. Crear Detalles (Medicamentos)
                foreach (var itemDto in request.Items)
                {
                    var item = new PrescriptionItem
                    {
                        PrescriptionId = prescriptionId,
                        MedicationName = itemDto.MedicationName,
                        Dosage = itemDto.Dosage,
                        Frequency = itemDto.Frequency,
                        Duration = itemDto.Duration,
                        Instructions = itemDto.Instructions
                    };

                    // Pasar la transacción actual del UnitOfWork
                    await _unitOfWork.Prescriptions.AddItemAsync(item);
                }

                await _unitOfWork.CommitAsync();
                return BaseResponse<long>.Success(prescriptionId, "Receta emitida y guardada exitosamente.");
            }
            catch (Exception ex)
            {
                await _unitOfWork.RollbackAsync();
                // Loggear error aquí
                return BaseResponse<long>.Failure($"Error al emitir la receta: {ex.Message}");
            }
        }        
    }
}
