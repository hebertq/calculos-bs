﻿using MedfarLabs.Core.Application.Common.Interfaces;
using MedfarLabs.Core.Application.Common.Services;
using MedfarLabs.Core.Application.Features.Care.Dtos.Request;
using MedfarLabs.Core.Application.Features.Care.Interfaces;
using MedfarLabs.Core.Application.Features.Laboratory.Dtos.Request;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Entities.Care;
using MedfarLabs.Core.Domain.Entities.Laboratory;
using MedfarLabs.Core.Domain.Entities.Public;
using MedfarLabs.Core.Domain.Interfaces.Repositories;

namespace MedfarLabs.Core.Application.Features.Care.Services
{
    public class MedicalCareService : BaseService, IMedicalCareService
    {
        public MedicalCareService(IUnitOfWork uow, IApplicationDispatcher dispatcher) : base(uow, dispatcher) { }

        public async Task<BaseResponse<long>> RegistrarConsultaMedicaAsync(ConsultationRequestDTO request)
        {
            // Orquestación atómica: Se registra la consulta y se podría disparar una orden de lab si fuera necesario
            return await ExecuteInTransactionAsync(async () =>
            {
                var consultation = new Consultation
                {
                    MedicalRecordId = request.MedicalRecordId,
                    DoctorUserId = request.DoctorUserId,
                    SubjectiveData = request.Subjective,
                    ObjectiveData = request.Objective,
                    AnalysisData = request.Analysis,
                    PlanData = request.Plan
                };

                var id = await _unitOfWork.Consultations.AddAsync(consultation);
                return BaseResponse<long>.Success(id, "Consulta médica registrada correctamente en el expediente");
            });
        }

        public async Task<BaseResponse<long>> CargarResultadoLaboratorioAsync(LabResultRequestDTO request)
        {
            var result = new LabResult
            {
                LabOrderId = request.LabOrderId,
                TechnicalDataJson = new JsonValue(request.TechnicalDataJson),
                //AttachmentUrl = request.AttachmentUrl,
                AuditNotes = "Resultado cargado vía servicio de laboratorio"
            };

            var id = await _unitOfWork.LabResults.AddAsync(result);
            return BaseResponse<long>.Success(id, "Resultado de laboratorio procesado exitosamente");
        }
    }
}
