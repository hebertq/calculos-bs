﻿namespace MedfarLabs.Core.Application.Features.Care.Dtos.Response
{
    public record AppointmentResponseDTO(
        long Id,
        string PatientName,
        string DoctorName,
        string BranchName,
        DateTime ScheduledDate,
        TimeSpan StartTime,
        int StatusId
    );
}
