﻿namespace MedfarLabs.Core.Application.Features.Care.Dtos.Response
{
    public record ConsultationResponseDTO(long Id, DateTime CreatedAt, string AnalysisSummary);
}
