﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Care.Dtos.Request
{
    /// <summary>
    /// DTO para la emisión de una receta médica con sus ítems detallados.
    /// </summary>
    public record PrescriptionRequestDTO(
        long? ConsultationId,   // Vinculación opcional a una consulta
        long PatientId,         // ID del paciente
        string? Notes,          // Observaciones generales de la receta
        List<PrescriptionItemRequestDTO> Items, // Lista de medicamentos
        string? AuditNotes = null
    ) : IHasOrganization, IHasUser
    {
        [JsonIgnore]
        public long OrganizationId { get; set; } // Inyectado automáticamente por la infraestructura

        [JsonIgnore]
        public long UserId { get; set; }         // Representa al DoctorUserId
    }

    /// <summary>
    /// Detalle individual de cada medicamento en la receta.
    /// </summary>
    public record PrescriptionItemRequestDTO(
        string MedicationName,  // Nombre del fármaco
        string? Dosage,          // Dosis (ej: 500mg)
        string? Frequency,       // Frecuencia (ej: cada 8 horas)
        string? Duration,        // Duración (ej: 7 días)
        string? Instructions     // Indicaciones adicionales
    );
}
