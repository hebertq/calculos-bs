﻿using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Care.Dtos.Request
{
    public record AppointmentRequestDTO(
    long BranchId,
    long PatientId,
    long DoctorUserId,
    long? FacilityRoomId,
    DateTime ScheduledDate,
    TimeSpan StartTime,
    TimeSpan EndTime,
    int StatusId,
    string? ReasonNotes
) : IHasOrganization, IHasUser
    {
        public long OrganizationId { get; set; }
        public long UserId { get; set; }
    }
}
