﻿using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Application.Features.Care.Dtos.Request
{
    [ActionMapping(AppModule.Care, AppAction.RegistrarConsulta)]
    public record ConsultationRequestDTO(
        [property: JsonPropertyName("expediente_id")] long MedicalRecordId,
        [property: JsonPropertyName("medico_id")] long DoctorUserId,
        [property: JsonPropertyName("datos_subjetivos")] string Subjective,
        [property: JsonPropertyName("datos_objetivos")] string Objective,
        [property: JsonPropertyName("analisis_medico")] string Analysis,
        [property: JsonPropertyName("plan_tratamiento")] string Plan
    ) : IHasOrganization, IHasUser // <--- Implementación de interfaces de blindaje
    {
        // Estas propiedades deben ser mutables para que la BaseDomainStrategy 
        // pueda inyectar los valores reales del Token después de deserializar.
        [JsonIgnore] // No las esperamos en el JSON de entrada
        public long OrganizationId { get; set; }

        [JsonIgnore]
        public long UserId { get; set; }
    }
    //public class RegistrarConsultaRules : BaseValidationRuleSet<ConsultationRequestDTO>
    //{
    //    public RegistrarConsultaRules(ConsultationRequestDTO dto)
    //    {
    //        SetBusinessObject(dto);
    //        ValidateRequired(p => p.MedicalRecordId, nameof(dto.MedicalRecordId), "Número de Expediente");
    //        ValidateRequired(p => p.Subjective, nameof(dto.Subjective), "Datos Subjetivos (Motivo)");
    //        ValidateRequired(p => p.Analysis, nameof(dto.Analysis), "Análisis Médico");
    //    }
    //}
}
