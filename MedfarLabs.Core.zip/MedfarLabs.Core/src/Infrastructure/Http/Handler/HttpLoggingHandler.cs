﻿using Microsoft.Extensions.Logging;

namespace MedfarLabs.Core.Infrastructure.Http.Handler
{
    public class HttpLoggingHandler : DelegatingHandler
    {
        private readonly ILogger<HttpLoggingHandler> _logger;

        public HttpLoggingHandler(ILogger<HttpLoggingHandler> logger)
        {
            _logger = logger;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            // 1. Gestión del Trace ID
            var traceId = Guid.NewGuid().ToString().Substring(0, 8);
            request.Headers.Add("X-Trace-ID", traceId);

            var method = request.Method.Method;
            var uri = request.RequestUri?.ToString();

            try
            {
                var response = await base.SendAsync(request, cancellationToken);

                if (!response.IsSuccessStatusCode)
                {
                    // 2. Extraer Body de la Petición (lo que nosotros enviamos)
                    var requestBody = "Sin contenido o no legible";
                    if (request.Content != null)
                    {
                        requestBody = await request.Content.ReadAsStringAsync(cancellationToken);
                    }

                    // 3. Extraer Body de la Respuesta (lo que el servidor externo devolvió)
                    var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);

                    _logger.LogWarning("[Trace:{Id}] Error en {Method} {Uri}\n" +
                                       "-> Request Sent: {ReqBody}\n" +
                                       "<- Response Status: {Status}\n" +
                                       "<- Response Received: {ResBody}",
                                       traceId, method, uri, requestBody, response.StatusCode, responseBody);
                }

                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "[Trace:{Id}] Excepción en {Method} {Uri}. Mensaje: {Msg}",
                    traceId, method, uri, ex.Message);
                throw;
            }
        }
    }
}
