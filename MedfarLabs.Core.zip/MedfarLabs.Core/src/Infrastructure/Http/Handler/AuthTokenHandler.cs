﻿using System.Net.Http.Headers;
using MedfarLabs.Core.Domain.Interfaces.Http;
using Microsoft.Extensions.Configuration;
using System.Text;
using System.Net;

namespace MedfarLabs.Core.Infrastructure.Http.Handler
{
    //{
    //  "ExternalServices": {
    //    "PacienteApi": {
    //      "AuthType": "Bearer",
    //      "TokenUrl": "...",
    //      "BaseUrl": "..."
    //    },
    //    "PublicHealthApi": {
    //"AuthType": "None", // API Libre
    //      "BaseUrl": "https://api.datosabiertos.gob/v1"
    //    }
    //  }
    //}
    public class AuthTokenHandler : DelegatingHandler
    {
        private readonly ITokenService _tokenService;
        private readonly IConfiguration _config;

        // Ahora el constructor es limpio, ideal para inyección de dependencias
        public AuthTokenHandler(ITokenService tokenService, IConfiguration config)
        {
            _tokenService = tokenService;
            _config = config;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            // 1. Intentamos obtener el nombre del servicio desde las opciones de la request
            if (request.Options.TryGetValue(new HttpRequestOptionsKey<string>("ServiceName"), out var serviceName))
            {
                var authType = _config[$"ExternalServices:{serviceName}:AuthType"];

                // Si authType es nulo o "None", saltamos la lógica de autenticación
                if (!string.IsNullOrEmpty(authType) && !authType.Equals("None", StringComparison.OrdinalIgnoreCase))
                {
                    switch (authType)
                    {
                        case "Bearer":
                            var token = await _tokenService.GetTokenAsync(serviceName);
                            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                            break;

                        case "Basic":
                            var user = _config[$"ExternalServices:{serviceName}:Username"];
                            var pass = _config[$"ExternalServices:{serviceName}:Password"];
                            var authString = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{user}:{pass}"));
                            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", authString);
                            break;

                        case "ApiKey":
                            var header = _config[$"ExternalServices:{serviceName}:HeaderName"];
                            var val = _config[$"ExternalServices:{serviceName}:Value"];
                            if (!string.IsNullOrEmpty(header))
                                request.Headers.Add(header, val);
                            break;
                    }
                }
                else
                {
                    // Si no hay serviceName o authType es "None", la petición sigue su curso original (API Libre)
                    return await base.SendAsync(request, cancellationToken);
                }

            }

            // 2. Ejecutar la petición
            var response = await base.SendAsync(request, cancellationToken);

            // 3. Lógica de reintento automático si el Token Bearer expiró (401)
            if (response.StatusCode == HttpStatusCode.Unauthorized &&
                request.Options.TryGetValue(new HttpRequestOptionsKey<string>("ServiceName"), out var sName))
            {
                var authType = _config[$"ExternalServices:{sName}:AuthType"];
                if (authType == "Bearer")
                {
                    // Forzamos la obtención de un nuevo token
                    var newToken = await _tokenService.GetNewTokenAsync(sName);
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", newToken);

                    // Reintentamos la petición (Nota: en implementaciones reales podrías necesitar clonar la request)
                    return await base.SendAsync(request, cancellationToken);
                }
            }

            return response;
        }
    }
}
