﻿using Polly;
using Polly.Timeout;
using Polly.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace MedfarLabs.Core.Infrastructure.Http.Policies
{
    public static class HttpPolicies
    {
        //"HttpPolicies": {
        //  "RetryCount": 3,
        //  "BaseDelaySeconds": 2, 
        //  "TimeoutSeconds": 15
        //}
        public static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy(IConfiguration config, ILogger logger)
        {
            var retryCount = config.GetValue<int>("HttpPolicies:RetryCount", 3);
            var baseDelay = config.GetValue<int>("HttpPolicies:BaseDelaySeconds", 2);

            return HttpPolicyExtensions
                .HandleTransientHttpError()
                .Or<TimeoutRejectedException>()
                .WaitAndRetryAsync(
                    retryCount,
                    retryAttempt => TimeSpan.FromSeconds(Math.Pow(baseDelay, retryAttempt)),
                    onRetry: (outcome, timespan, retryAttempt, context) =>
                    {
                        // Extraemos la URL de la petición desde el contexto de Polly
                        var uri = outcome.Result?.RequestMessage?.RequestUri?.ToString() ?? "URL desconocida";

                        logger.LogWarning("Reintento {Attempt}/{Max} para {Uri}. Espera: {Seconds}s. Motivo: {Reason}",
                            retryAttempt, retryCount, uri, timespan.TotalSeconds,
                            outcome.Exception?.Message ?? outcome.Result?.StatusCode.ToString());
                    });
        }

        public static IAsyncPolicy<HttpResponseMessage> GetTimeoutPolicy(IConfiguration config, ILogger logger)
        {
            var seconds = config.GetValue<int>("HttpPolicies:TimeoutSeconds", 10);

            return Policy.TimeoutAsync<HttpResponseMessage>(
                seconds,
                TimeoutStrategy.Optimistic,
                onTimeoutAsync: (context, timespan, task) =>
                {
                    logger.LogError("TIMEOUT: La petición a {Operation} excedió los {Seconds}s.",
                        context.OperationKey, timespan.TotalSeconds);
                    return Task.CompletedTask;
                });
        }
    }
}
