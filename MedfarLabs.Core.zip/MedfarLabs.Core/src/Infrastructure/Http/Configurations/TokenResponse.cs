﻿using System;
using System.Text.Json.Serialization;

namespace MedfarLabs.Core.Infrastructure.Http.Configurations
{
    internal class TokenResponse
    {
        [JsonPropertyName("access_token")]
        public string AccessToken { get; set; } = string.Empty;

        [JsonPropertyName("expires_in")]
        public int ExpiresIn { get; set; } // Segundos que dura el token

        [JsonPropertyName("token_type")]
        public string TokenType { get; set; } = string.Empty;
    }
}
