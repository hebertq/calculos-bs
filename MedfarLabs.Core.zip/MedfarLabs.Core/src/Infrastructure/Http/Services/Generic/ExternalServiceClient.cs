﻿using System.Net.Http.Json;
using Microsoft.Extensions.Logging;
using Polly.Timeout;
using MedfarLabs.Core.Domain.Common.Responses.Generic;
using MedfarLabs.Core.Domain.Interfaces.Http;

namespace MedfarLabs.Core.Infrastructure.Http.Services.Generic
{
    public class ExternalServiceClient : IExternalServiceClient
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<ExternalServiceClient> _logger;

        public ExternalServiceClient(HttpClient httpClient, ILogger<ExternalServiceClient> logger)
        {
            _httpClient = httpClient;
            _logger = logger;
        }

        public async Task<BaseResponse<TResponse>> GetAsync<TResponse>(string endpoint)
        {
            try
            {
                var response = await _httpClient.GetAsync(endpoint);
                return await HandleResponseAsync<TResponse>(response);
            }
            catch (Exception ex)
            {
                return HandleException<TResponse>(ex, "GET", endpoint);
            }
        }

        public async Task<BaseResponse<TResponse>> PostAsync<TRequest, TResponse>(
        string endpoint,
        TRequest data,
        string? serviceName = null)
        {
            var request = new HttpRequestMessage(HttpMethod.Post, endpoint)
            {
                Content = JsonContent.Create(data)
            };

            // Pasamos el nombre del servicio en las propiedades de la petición
            // para que el AuthTokenHandler lo lea y decida el Token.
            if (!string.IsNullOrEmpty(serviceName))
            {
                request.Options.Set(new HttpRequestOptionsKey<string>("ServiceName"), serviceName);
            }

            var response = await _httpClient.SendAsync(request);
            return await HandleResponseAsync<TResponse>(response);
        }
        public async Task<BaseResponse<bool>> TriggerCloudProcessAsync(string processName, object payload)
        {
            try
            {
                _logger.LogInformation("Disparando proceso en la nube: {ProcessName}", processName);

                // Generalmente, los disparadores de procesos (Lambdas/Step Functions) 
                // se exponen mediante un endpoint POST.
                var endpoint = $"api/cloud/trigger/{processName}";

                var response = await _httpClient.PostAsJsonAsync(endpoint, payload);

                if (response.IsSuccessStatusCode)
                {
                    return BaseResponse<bool>.Success(true, $"Proceso {processName} iniciado exitosamente.");
                }

                var error = await response.Content.ReadAsStringAsync();
                _logger.LogError("Fallo al disparar proceso {ProcessName}: {Error}", processName, error);

                return BaseResponse<bool>.Failure($"No se pudo iniciar el proceso: {response.StatusCode}");
            }
            catch (Exception ex)
            {
                // Reutilizamos nuestro manejador de excepciones genérico
                var result = HandleException<bool>(ex, "TRIGGER", processName);
                return result;
            }
        }

        private async Task<BaseResponse<T>> HandleResponseAsync<T>(HttpResponseMessage response)
        {
            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<T>();
                return BaseResponse<T>.Success(result!);
            }

            // Manejo específico de errores por código de estado
            var content = await response.Content.ReadAsStringAsync();
            _logger.LogError("API Externa error {Code}: {Content}", response.StatusCode, content);

            return response.StatusCode switch
            {
                System.Net.HttpStatusCode.NotFound => BaseResponse<T>.Failure("El recurso solicitado no existe en el servidor externo."),
                System.Net.HttpStatusCode.Forbidden => BaseResponse<T>.Failure("No tiene permisos para acceder a este recurso externo."),
                _ => BaseResponse<T>.Failure($"Error en servicio externo (Código: {response.StatusCode})")
            };
        }

        private BaseResponse<T> HandleException<T>(Exception ex, string method, string endpoint)
        {
            if (ex is TimeoutRejectedException)
            {
                _logger.LogWarning("Timeout de Polly en {Method} a {Endpoint}", method, endpoint);
                return BaseResponse<T>.Failure("El servicio externo tardó demasiado en responder.");
            }

            if (ex is HttpRequestException)
            {
                _logger.LogError(ex, "Error de red en {Method} a {Endpoint}", method, endpoint);
                return BaseResponse<T>.Failure("Error de comunicación o red con el servicio externo.");
            }

            _logger.LogCritical(ex, "Error inesperado en ExternalServiceClient");
            return BaseResponse<T>.Failure("Ocurrió un error interno al procesar la llamada externa.");
        }
    }
}
