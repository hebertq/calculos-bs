﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using MedfarLabs.Core.Domain.Interfaces.Http;
using MedfarLabs.Core.Infrastructure.Http.Configurations;
using System.Collections.Concurrent;
using System.Net.Http.Json;
public class TokenService : ITokenService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _config;
    private readonly ILogger<TokenService> _logger;

    // Guardamos el token y cuándo vence
    private readonly ConcurrentDictionary<string, (string Token, DateTime Expiry)> _tokenCache = new();

    public TokenService(HttpClient httpClient, IConfiguration config, ILogger<TokenService> logger)
    {
        _httpClient = httpClient;
        _config = config;
        _logger = logger;
    }

    public async Task<string> GetTokenAsync(string serviceName)
    {
        // Si el token existe y NO ha vencido (damos 1 minuto de gracia), lo devolvemos
        if (_tokenCache.TryGetValue(serviceName, out var cached) && cached.Expiry > DateTime.UtcNow.AddMinutes(1))
        {
            return cached.Token;
        }

        return await GetNewTokenAsync(serviceName);
    }

    public async Task<string> GetNewTokenAsync(string serviceName)
    {
        _logger.LogInformation("Solicitando nuevo token para el servicio: {ServiceName}", serviceName);

        var section = _config.GetSection($"ExternalServices:{serviceName}");
        var authType = section["AuthType"];

        if (authType != "Bearer") return string.Empty;

        var tokenUrl = section["TokenUrl"] ?? throw new InvalidOperationException($"TokenUrl no configurada para {serviceName}");

        var content = new FormUrlEncodedContent(new[]
        {
            new KeyValuePair<string, string>("grant_type", "client_credentials"),
            new KeyValuePair<string, string>("client_id", section["ClientId"] ?? ""),
            new KeyValuePair<string, string>("client_secret", section["ClientSecret"] ?? "")
        });

        try
        {
            var response = await _httpClient.PostAsync(tokenUrl, content);

            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                _logger.LogError("Error al solicitar token para {Service}: {Error}", serviceName, error);
                throw new HttpRequestException($"No se pudo obtener el token para {serviceName}");
            }

            var data = await response.Content.ReadFromJsonAsync<TokenResponse>();
            var newToken = data?.AccessToken ?? throw new Exception("Token nulo recibido.");

            // Calculamos la expiración. Si la API no devuelve expires_in, usamos 1 hora por defecto.
            var expiresIndSeconds = data.ExpiresIn > 0 ? data.ExpiresIn : 3600;
            var expiryDate = DateTime.UtcNow.AddSeconds(expiresIndSeconds);

            // Actualizar caché con la tupla (Token, Expiración)
            _tokenCache.AddOrUpdate(serviceName, (newToken, expiryDate), (_, _) => (newToken, expiryDate));

            return newToken;
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Fallo catastrófico al recuperar token para {Service}", serviceName);
            throw;
        }
    }
}
