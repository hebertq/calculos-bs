﻿using System.Security.Cryptography;
using System.Text;
using MedfarLabs.Core.Domain.Interfaces.Security;

namespace MedfarLabs.Core.Infrastructure.Shared.Security
{
    public class HashService : IHashService
    {
        private readonly string _salt; // Se saca de una variable de entorno

        public HashService(string salt) => _salt = salt;

        public byte[] GenerateHash(string input) // Cambiado de string a byte[]
        {
            if (string.IsNullOrWhiteSpace(input)) return Array.Empty<byte>();

            using var sha256 = SHA256.Create();

            // NORMALIZACIÓN: Paso vital para que las búsquedas sean exactas
            var normalized = input.Trim().ToLowerInvariant();
            var combined = normalized + _salt;

            // Devolvemos los 32 bytes puros del SHA256
            return sha256.ComputeHash(Encoding.UTF8.GetBytes(combined));
        }
    }
}
