﻿using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;
using MedfarLabs.Core.Domain.Interfaces.Security;

namespace MedfarLabs.Core.Infrastructure.Shared.Security
{
    public class GlobalSecurityCache : IGlobalSecurityCache
    {
        // Diccionario: Key = RoleId | Value = Set de ActionIds para búsqueda O(1)
        private Dictionary<int, HashSet<int>> _roleActionMatrix = new();

        public async Task InitializeAsync(ISecurityRepository repository)
        {
            // 1. Obtenemos todos los mapeos (Role-Action) de la DB
            var mappings = await repository.GetAllRoleActionMappingsAsync();

            // 2. Agrupamos por Rol y convertimos a HashSet para máxima velocidad
            _roleActionMatrix = mappings
                .GroupBy(m => m.RoleId)
                .ToDictionary(
                    g => g.Key,
                    g => g.Select(x => x.ActionId).ToHashSet()
                );
        }

        public bool RoleHasPermission(int roleId, int actionId)
        {
            return _roleActionMatrix.TryGetValue(roleId, out var actions)
                   && actions.Contains(actionId);
        }

        public HashSet<int> GetPermissionsForRoles(IEnumerable<int> roleIds)
        {
            var combinedPermissions = new HashSet<int>();

            foreach (var roleId in roleIds)
            {
                if (_roleActionMatrix.TryGetValue(roleId, out var actions))
                {
                    // Unión de permisos: Si tiene varios roles, suma sus acciones
                    foreach (var actionId in actions)
                    {
                        combinedPermissions.Add(actionId);
                    }
                }
            }

            return combinedPermissions;
        }
    }
}
