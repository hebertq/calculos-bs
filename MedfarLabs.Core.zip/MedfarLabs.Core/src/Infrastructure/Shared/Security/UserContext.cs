﻿using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;
using MedfarLabs.Core.Domain.Interfaces.Security;

namespace MedfarLabs.Core.Infrastructure.Shared.Security
{
    public class UserContext : IUserContext
    {
        private readonly ISecurityRepository _securityRepo;
        private readonly IGlobalSecurityCache _cache;

        // Caché local para la ejecución actual de la Lambda (evita repetir la consulta de roles)
        private HashSet<int>? _userPermissions;

        public UserContext(ISecurityRepository securityRepo, IGlobalSecurityCache cache)
        {
            _securityRepo = securityRepo;
            _cache = cache;
        }

        // Estas propiedades se asignan al inicio del Handler de la Lambda
        public long UserId { get; set; }
        public long OrganizationId { get; set; }

        public async Task<bool> HasPermissionAsync(int actionId)
        {
            // Si ya calculamos los permisos en este request, los devolvemos de inmediato
            if (_userPermissions == null)
            {
                await LoadUserPermissionsAsync();
            }

            return _userPermissions!.Contains(actionId);
        }

        private async Task LoadUserPermissionsAsync()
        {
            // 1. Consultamos a la DB qué ROLES tiene este usuario en esta organización
            // Esta es una consulta indexada muy rápida
            var userRoleIds = await _securityRepo.GetUserRoleIdsAsync(UserId, OrganizationId);

            // 2. Usamos el Caché Global (ya en RAM) para obtener las acciones de esos roles
            // El método GetPermissionsForRoles combina los permisos de todos los roles del usuario
            _userPermissions = _cache.GetPermissionsForRoles(userRoleIds);
        }
    }
}
