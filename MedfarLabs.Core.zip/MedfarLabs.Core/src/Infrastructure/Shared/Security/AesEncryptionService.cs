﻿using System.Security.Cryptography;
using System.Text;
using MedfarLabs.Core.Infrastructure.Common.Interfaces;

namespace MedfarLabs.Core.Infrastructure.Shared.Security
{
    public class AesEncryptionService : IEncryptionService
    {
        private readonly byte[] _key; // Debe venir de AWS Secrets Manager o Environment

        public AesEncryptionService(string key)
        {
            _key = Encoding.UTF8.GetBytes(key.PadRight(32).Substring(0, 32));
        }

        public byte[] Encrypt(string plainText)
        {
            if (string.IsNullOrEmpty(plainText)) return Array.Empty<byte>();

            using var aes = Aes.Create();
            aes.Key = _key;
            aes.GenerateIV();
            var iv = aes.IV;

            using var encryptor = aes.CreateEncryptor(aes.Key, iv);
            using var ms = new MemoryStream();
            ms.Write(iv, 0, iv.Length); // Guardamos el IV al inicio del byte array

            using (var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
            using (var sw = new StreamWriter(cs))
            {
                sw.Write(plainText);
            }

            return ms.ToArray();
        }

        public string Decrypt(byte[] cipherText)
        {
            if (cipherText == null || cipherText.Length == 0) return string.Empty;

            using var aes = Aes.Create();
            aes.Key = _key;
            var iv = new byte[aes.BlockSize / 8];
            Array.Copy(cipherText, 0, iv, 0, iv.Length);

            using var decryptor = aes.CreateDecryptor(aes.Key, iv);
            using var ms = new MemoryStream(cipherText, iv.Length, cipherText.Length - iv.Length);
            using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
            using var sr = new StreamReader(cs);

            return sr.ReadToEnd();
        }
    }
}
