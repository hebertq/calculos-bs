﻿using Npgsql;
using System.Data;
using MedfarLabs.Core.Domain.Interfaces.Repositories;
using MedfarLabs.Core.Domain.Interfaces.Security;
using MedfarLabs.Core.Infrastructure.Common.Interfaces;
using MedfarLabs.Core.Infrastructure.Persistence;
using MedfarLabs.Core.Infrastructure.Persistence.Factories;
using MedfarLabs.Core.Infrastructure.Shared.Security;
using MedfarLabs.Core.Domain.Interfaces.Http;
using MedfarLabs.Core.Infrastructure.Http.Handler;
using MedfarLabs.Core.Infrastructure.Http.Policies;
using MedfarLabs.Core.Infrastructure.Http.Services.Generic;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Billing;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Care;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Clinical;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Identity;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Inventory;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Laboratory;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Billing;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Care;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Clinical;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Identity;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Inventory;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Laboratory;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Security;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class ConfigureServices
    {
        public static IServiceCollection AddInfrastructureServices(this IServiceCollection services,
        string connectionString,
        string encryptionKey,
        string hashSalt)
        {
            // 1. Crear DataSource con los mapeos
            var dataSourceBuilder = new NpgsqlDataSourceBuilder(connectionString);
            var dataSource = dataSourceBuilder.Build();

            // 2. Registrar el DataSource
            services.AddSingleton(dataSource);

            // 3. Registrar la Factory pasándole el objeto dataSource (NO el string)
            services.AddSingleton<IDbConnectionFactory>(new PostgresConnectionFactory(dataSource));   

            // 4. La conexión ahora se obtiene del DataSource para que herede los mapeos
            services.AddScoped<IDbConnection>(sp =>
                sp.GetRequiredService<NpgsqlDataSource>().CreateConnection());

            // 5. Registro del Unit of Work (Punto de entrada principal)
            services.AddScoped<IUnitOfWork, UnitOfWork>();

            // 6. Registro de Repositorios Individuales
            // Esto permite inyectar solo un repositorio si un servicio no necesita transaccionalidad
            services.AddScoped<IPersonRepository, PersonRepository>();
            services.AddScoped<IOrganizationRepository, OrganizationRepository>();
            services.AddScoped<IMedicalRecordRepository, MedicalRecordRepository>();
            services.AddScoped<IPatientRepository, PatientRepository>();
            services.AddScoped<IVitalSignsRepository, VitalSignsRepository>();
            services.AddScoped<IConsultationRepository, ConsultationRepository>();
            services.AddScoped<IServiceRepository, ServiceRepository>();
            services.AddScoped<ILabResultRepository, LabResultRepository>();
            services.AddScoped<ILabOrderRepository, LabOrderRepository>();
            services.AddScoped<IInvoiceRepository, InvoiceRepository>();
            services.AddScoped<IInvoiceItemRepository, InvoiceItemRepository>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IPaymentRepository, PaymentRepository>();

            // -------------------- SecurityInfrastructure -------------------
            // 1. El Caché vive mientras la instancia de la Lambda esté viva
            services.AddSingleton<IGlobalSecurityCache, GlobalSecurityCache>();
            // 2. El Contexto se crea de cero en cada ejecución de la función
            services.AddScoped<IUserContext, UserContext>();
            // 3. El Repositorio de Seguridad para consultas de roles
            services.AddScoped<ISecurityRepository, SecurityRepository>();

            // 7. Registro de Seguridad
            var encryptionService = new AesEncryptionService(encryptionKey);
            services.AddSingleton<IEncryptionService>(encryptionService);
            services.AddSingleton<IHashService>(new HashService(hashSalt));
            InfrastructureRegistration.RegisterDapperHandlers(encryptionService);

            return services;
        }

        public static IServiceCollection AddInfrastructureServicesHost(this IServiceCollection services,IConfiguration configuration)
        {
            // 1. Registro del Handler
            services.AddTransient<HttpLoggingHandler>();

            // 2. Creamos un Logger temporal para las políticas
            var loggerFactory = services.BuildServiceProvider().GetRequiredService<ILoggerFactory>();
            var logger = loggerFactory.CreateLogger("HttpPolicies");

            // 3. Configuración del Cliente
            services.AddHttpClient<ITokenService, TokenService>();
            services.AddTransient<AuthTokenHandler>();
            services.AddHttpClient<IExternalServiceClient, ExternalServiceClient>()
                    .AddHttpMessageHandler<AuthTokenHandler>()
                    .AddPolicyHandler(HttpPolicies.GetRetryPolicy(configuration,logger))
                    .AddPolicyHandler(HttpPolicies.GetTimeoutPolicy(configuration, logger));

            return services;
        }
    }
}
