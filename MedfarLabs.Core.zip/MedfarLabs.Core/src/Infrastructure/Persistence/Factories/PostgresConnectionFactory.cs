﻿using System.Data;
using Npgsql;
using MedfarLabs.Core.Infrastructure.Common.Interfaces;

namespace MedfarLabs.Core.Infrastructure.Persistence.Factories
{
    public class PostgresConnectionFactory : IDbConnectionFactory
    {
        private readonly NpgsqlDataSource _dataSource;

        public PostgresConnectionFactory(NpgsqlDataSource dataSource)
        {
            _dataSource = dataSource;
        }

        public IDbConnection CreateConnection() => _dataSource.CreateConnection();
    }
}
