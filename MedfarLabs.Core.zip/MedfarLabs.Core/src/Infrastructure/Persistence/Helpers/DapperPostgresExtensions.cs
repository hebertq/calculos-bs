﻿using System.Data;
using System.Reflection;
using Dapper;

namespace MedfarLabs.Core.Infrastructure.Persistence.Helpers
{
    public static class DapperPostgresExtensions
    {
        /// <summary>
        /// Convierte un objeto en DynamicParameters, transformando Enums en strings
        /// para evitar el error de casting 'integer to enum' en PostgreSQL.
        /// </summary>
        public static DynamicParameters ToPostgresParams(this object obj)
        {
            var parameters = new DynamicParameters();
            if (obj == null) return parameters;

            var properties = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (var prop in properties)
            {
                var value = prop.GetValue(obj);

                if (value is Enum enumValue)
                {
                    // Enviamos el nombre del enum como string y especificamos DbType.String
                    parameters.Add(prop.Name, enumValue.ToString(), DbType.String);
                }
                else
                {
                    parameters.Add(prop.Name, value);
                }
            }

            return parameters;
        }
    }
}
