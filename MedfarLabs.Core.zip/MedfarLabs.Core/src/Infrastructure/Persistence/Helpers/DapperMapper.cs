﻿using System.Collections.Concurrent;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Security;
using MedfarLabs.Core.Infrastructure.Common.Interfaces;

namespace MedfarLabs.Core.Infrastructure.Persistence.Helpers
{
    public static class DapperMapper
    {
        // Caché de funciones compiladas: (Tipo, Delegado de mapeo)
        private static readonly ConcurrentDictionary<Type, Delegate> _mapperCache = new();

        public static T Map<T>(dynamic row, IEncryptionService encryptionService) where T : new()
        {
            if (row == null) return default!;

            // Obtenemos o creamos la función compilada para el tipo T
            var mapper = (Func<IDictionary<string, object>, IEncryptionService, T>)_mapperCache.GetOrAdd(typeof(T), t => CompileMapper<T>());

            return mapper((IDictionary<string, object>)row, encryptionService);
        }

        private static Func<IDictionary<string, object>, IEncryptionService, T> CompileMapper<T>() where T : new()
        {
            var type = typeof(T);
            var rowParam = Expression.Parameter(typeof(IDictionary<string, object>), "row");
            var encryptionServiceParam = Expression.Parameter(typeof(IEncryptionService), "encryptionService");

            var targetVariable = Expression.Variable(type, "target");
            var resultExpression = Expression.New(type);

            var assignments = new List<Expression> { Expression.Assign(targetVariable, resultExpression) };

            foreach (var prop in type.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                var attr = prop.GetCustomAttribute<DbColumnAttribute>();
                string columnName = attr?.Name ?? prop.Name.ToLower();

                // Lógica para extraer el valor del diccionario: row["columnName"]
                var getItemMethod = typeof(IDictionary<string, object>).GetMethod("get_Item")!;
                var columnKey = Expression.Constant(columnName);
                var valueExpression = Expression.Call(rowParam, getItemMethod, columnKey);

                // Verificamos si la columna existe en el resultado
                var containsKeyMethod = typeof(IDictionary<string, object>).GetMethod("ContainsKey")!;
                var checkKey = Expression.Call(rowParam, containsKeyMethod, columnKey);

                // Invocamos el método de ayuda para convertir el dato (Enum, Encriptado, etc.)
                // Usamos una llamada a un método estático externo para no complicar el árbol de expresiones
                var converterMethod = typeof(DapperMapper).GetMethod(nameof(ConvertValue), BindingFlags.NonPublic | BindingFlags.Static)!;
                var convertedValue = Expression.Call(converterMethod,
                    valueExpression,
                    Expression.Constant(prop.PropertyType),
                    encryptionServiceParam);

                var castedValue = Expression.Convert(convertedValue, prop.PropertyType);
                var assignProp = Expression.Assign(Expression.Property(targetVariable, prop), castedValue);

                // if (row.ContainsKey("col")) { target.Prop = Convert(row["col"]); }
                assignments.Add(Expression.IfThen(checkKey, assignProp));
            }

            assignments.Add(targetVariable); // Retorno

            var body = Expression.Block(new[] { targetVariable }, assignments);
            return Expression.Lambda<Func<IDictionary<string, object>, IEncryptionService, T>>(body, rowParam, encryptionServiceParam).Compile();
        }

        // Este método centraliza la lógica de conversión que ya probamos
        private static object? ConvertValue(object value, Type targetType, IEncryptionService encryptionService)
        {
            if (value == null || value is DBNull) return null;

            var actualType = Nullable.GetUnderlyingType(targetType) ?? targetType;

            if (actualType.IsEnum)
            {
                var str = value is byte[] b ? Encoding.UTF8.GetString(b) : value.ToString();
                return Enum.TryParse(actualType, str, true, out var res) ? res : Enum.ToObject(actualType, 0);
            }

            if (actualType == typeof(EncryptedData))
                return new EncryptedData(encryptionService.Decrypt((byte[])value));

            if (actualType == typeof(DateTime) && value is DateOnly d)
                return d.ToDateTime(TimeOnly.MinValue);

            return Convert.ChangeType(value, actualType);
        }
    }
}
