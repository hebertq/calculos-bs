﻿using System.Collections.Concurrent;
using System.Reflection;
using System.Data;
using Dapper;
using MedfarLabs.Core.Domain.Entities.Common;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Domain.Interfaces.Repositories;

namespace MedfarLabs.Core.Infrastructure.Persistence.Struct
{
    public abstract class BaseRepository<T> : IBaseRepository<T> where T : BaseEntity
    {
        protected readonly IDbConnection _connection;
        protected readonly string _tableName;
        protected readonly IDbTransaction? _transaction;
        // Caché estático para no repetir la reflexión en cada llamada
        private static readonly ConcurrentDictionary<Type, string> _insertCache = new();
        private static readonly ConcurrentDictionary<Type, string> _updateCache = new();

        protected BaseRepository(IDbConnection connection, string tableName, IDbTransaction? tr = null)
        {
            _connection = connection;
            _tableName = tableName;
            _transaction = tr;
        }

        public virtual async Task<long> AddAsync(T entity)
        {
            // 1. Automatización de Auditoría de Ingreso
            entity.CreatedAt = DateTime.Now;
            entity.UpdatedAt = DateTime.Now;
            // El CreatedByUserId debe venir seteado desde el ActionDispatcher/Contexto

            // 2. Obtener o generar SQL de inserción
            string sql = _insertCache.GetOrAdd(typeof(T), t => GenerateInsertSql());

            // 3. Ejecutar usando la extensión de identidad
            return await _connection.QueryIdentityOrThrowAsync<long>(sql, entity,
                $"Error al insertar en la tabla {_tableName}");
        }

        public virtual async Task<bool> UpdateAsync(T entity)
        {
            // 1. Automatización de Auditoría de Actualización
            entity.UpdatedAt = DateTime.Now;

            // 2. Obtener o generar SQL de actualización
            string sql = _updateCache.GetOrAdd(typeof(T), t => GenerateUpdateSql());

            // 3. Ejecutar usando la extensión de ejecución
            await _connection.ExecuteOrThrowAsync(sql, entity,
                $"No se pudo actualizar el registro con ID {entity.Id} en {_tableName}");

            return true;
        }

        #region Generadores de SQL Dinámico

        private string GenerateInsertSql()
        {
            var properties = GetMappedProperties();
            var columns = properties.Select(p => p.GetCustomAttribute<DbColumnAttribute>()!.Name);
            var values = properties.Select(p => "@" + p.Name);

            return $"INSERT INTO {_tableName} ({string.Join(", ", columns)}) " +
                   $"VALUES ({string.Join(", ", values)}) RETURNING id;";
        }

        private string GenerateUpdateSql()
        {
            var properties = GetMappedProperties();
            var updateSets = properties
                .Where(p => p.Name != "Id") // Excluir la PK del SET
                .Select(p => $"{p.GetCustomAttribute<DbColumnAttribute>()!.Name} = @{p.Name}");

            return $"UPDATE {_tableName} SET {string.Join(", ", updateSets)} WHERE id = @Id;";
        }

        private IEnumerable<PropertyInfo> GetMappedProperties()
        {
            return typeof(T).GetProperties()
                .Where(p => p.GetCustomAttribute<DbColumnAttribute>() != null && p.Name != "Id");
        }

        #endregion

        // Métodos de lectura simplificados
        public async Task<T?> GetByIdAsync(long id) =>
            await _connection.QueryFirstOrDefaultAsync<T>($"SELECT * FROM {_tableName} WHERE id = @id", new { id });

        public async Task<IEnumerable<T>> GetAllAsync() =>
            await _connection.QueryListOrThrowAsync<T>($"SELECT * FROM {_tableName}");

        public async Task<bool> DeleteAsync(long id) =>
            await _connection.ExecuteAsync($"DELETE FROM {_tableName} WHERE id = @id", new { id }) > 0;

        public async Task<IEnumerable<T>> QueryListAsync() =>
            await _connection.QueryListAsync<T>($"SELECT * FROM {_tableName}");
        
    }
}
