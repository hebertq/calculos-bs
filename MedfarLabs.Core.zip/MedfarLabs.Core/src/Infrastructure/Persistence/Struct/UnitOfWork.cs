﻿using System.Data;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Billing;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Care;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Clinical;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Identity;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Inventory;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Laboratory;
using MedfarLabs.Core.Domain.Interfaces.Repositories;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Billing;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Care;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Clinical;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Identity;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Inventory;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Laboratory;
using MedfarLabs.Core.Domain.Interfaces.Security;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Security;

namespace MedfarLabs.Core.Infrastructure.Persistence.Struct
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly IDbConnection _connection;
        private readonly IHashService _encryptionService;
        private IDbTransaction? _transaction;

        // Implementación con Lazy Loading para no instanciar lo que no se usa
        public IPersonRepository Persons => new PersonRepository(_encryptionService,_connection, _transaction);
        public IOrganizationRepository Organizations => new OrganizationRepository(_connection, _transaction);
        public IPatientRepository Patients => new PatientRepository(_connection, _transaction);
        public IVitalSignsRepository VitalSigns => new VitalSignsRepository(_connection, _transaction);
        public IConsultationRepository Consultations => new ConsultationRepository(_connection, _transaction);
        public IServiceRepository Services => new ServiceRepository(_connection, _transaction);
        public ILabResultRepository LabResults => new LabResultRepository(_connection, _transaction);
        public ILabOrderRepository LabOrders => new LabOrderRepository(_connection, _transaction);
        public IInvoiceRepository Invoices => new InvoiceRepository(_connection, _transaction);
        public IInvoiceItemRepository InvoiceItems => new InvoiceItemRepository(_connection, _transaction);
        public IMedicalRecordRepository MedicalRecords => new MedicalRecordRepository(_connection, _transaction);
        public IUserRepository Users => new UserRepository(_connection, _transaction);
        public IPaymentRepository Payments => new PaymentRepository(_connection, _transaction);
        public IActionPermissionRepository Actions => new ActionPermissionRepository(_connection, _transaction);
        public IRoleRepository Roles => new RoleRepository(_connection, _transaction);
        public IRoleGroupRepository RoleGroups => new RoleGroupRepository(_connection, _transaction);
        public ISecurityRepository Security => new SecurityRepository(_connection, _transaction);
        public UnitOfWork(IDbConnection connection, IHashService encryptionService)
        {
            _connection = connection;
            _encryptionService = encryptionService ?? throw new ArgumentNullException(nameof(encryptionService));
            if (_connection.State != ConnectionState.Open)
                _connection.Open();
        }

        public async Task BeginTransactionAsync()
        {
            _transaction = _connection.BeginTransaction();
            await Task.CompletedTask;
        }

        public async Task CommitAsync()
        {
            try
            {
                if (_transaction != null)
                {
                    _transaction.Commit();
                }
            }
            catch
            {
                await RollbackAsync();
                throw;
            }
            finally
            {
                _transaction?.Dispose();
                _transaction = null;
            }
        }

        public async Task RollbackAsync()
        {
            if (_transaction != null)
            {
                _transaction.Rollback();
                _transaction.Dispose();
                _transaction = null;
            }
            await Task.CompletedTask;
        }

        public void Dispose()
        {
            _transaction?.Dispose();
            _connection?.Close();
            _connection?.Dispose();
        }

        public async Task SaveChangesAsync()
        {
            try
            {
                if (_transaction != null)
                {
                    // En Dapper/Npgsql el commit es sincrónico, 
                    // pero lo envolvemos en Task para mantener la firma async
                    await Task.Run(() => _transaction.Commit());
                }
            }
            catch
            {
                await RollbackAsync();
                throw;
            }
            finally
            {
                _transaction?.Dispose();
                _transaction = null; // Reset para la siguiente operación si es necesario
            }
        }
    }
}
