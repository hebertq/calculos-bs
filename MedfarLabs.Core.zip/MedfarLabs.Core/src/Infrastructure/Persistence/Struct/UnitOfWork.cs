﻿using System.Data;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Billing;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Care;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Clinical;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Identity;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Inventory;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Laboratory;
using MedfarLabs.Core.Domain.Interfaces.Repositories;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Billing;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Care;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Clinical;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Identity;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Inventory;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Laboratory;
using MedfarLabs.Core.Domain.Interfaces.Security;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Security;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Common;
using MedfarLabs.Core.Infrastructure.Persistence.Repositories.Common;

namespace MedfarLabs.Core.Infrastructure.Persistence.Struct
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly IDbConnection _connection;
        private readonly IHashService _encryptionService;
        private IDbTransaction? _transaction;

        // Campos de respaldo para Lazy Loading
        private IPersonRepository? _persons;
        private IOrganizationRepository? _organizations;
        private IPatientRepository? _patients;
        private IVitalSignsRepository? _vitalSigns;
        private IConsultationRepository? _consultations;
        private IServiceRepository? _services;
        private ILabResultRepository? _labResults;
        private ILabOrderRepository? _labOrders;
        private IInvoiceRepository? _invoices;
        private IInvoiceItemRepository? _invoiceItems;
        private IMedicalRecordRepository? _medicalRecords;
        private IUserRepository? _users;
        private IPaymentRepository? _payments;
        private IActionPermissionRepository? _actions;
        private IRoleRepository? _roles;
        private IRoleGroupRepository? _roleGroups;
        private ISecurityRepository? _security;
        private ICatalogRepository? _catalogs;
        private IAppointmentRepository? _appointments;
        private IPrescriptionRepository? _prescriptions;
        private IBranchRepository? _branches;
        private IFacilityRoomRepository? _facilityRooms;
        private IPatientAntecedentRepository? _antecedents;

        public UnitOfWork(IDbConnection connection, IHashService encryptionService)
        {
            _connection = connection;
            _encryptionService = encryptionService ?? throw new ArgumentNullException(nameof(encryptionService));
            if (_connection.State != ConnectionState.Open)
                _connection.Open();
        }

        // Implementación con validación de instancia única por petición
        public IPersonRepository Persons => _persons ??= new PersonRepository(_encryptionService, _connection, _transaction);
        public IOrganizationRepository Organizations => _organizations ??= new OrganizationRepository(_connection, _transaction);
        public IPatientRepository Patients => _patients ??= new PatientRepository(_connection, _transaction);
        public IVitalSignsRepository VitalSigns => _vitalSigns ??= new VitalSignsRepository(_connection, _transaction);
        public IConsultationRepository Consultations => _consultations ??= new ConsultationRepository(_connection, _transaction);
        public IServiceRepository Services => _services ??= new ServiceRepository(_connection, _transaction);
        public ILabResultRepository LabResults => _labResults ??= new LabResultRepository(_connection, _transaction);
        public ILabOrderRepository LabOrders => _labOrders ??= new LabOrderRepository(_connection, _transaction);
        public IInvoiceRepository Invoices => _invoices ??= new InvoiceRepository(_connection, _transaction);
        public IInvoiceItemRepository InvoiceItems => _invoiceItems ??= new InvoiceItemRepository(_connection, _transaction);
        public IMedicalRecordRepository MedicalRecords => _medicalRecords ??= new MedicalRecordRepository(_connection, _transaction);
        public IUserRepository Users => _users ??= new UserRepository(_connection, _transaction);
        public IPaymentRepository Payments => _payments ??= new PaymentRepository(_connection, _transaction);
        public IActionPermissionRepository Actions => _actions ??= new ActionPermissionRepository(_connection, _transaction);
        public IRoleRepository Roles => _roles ??= new RoleRepository(_connection, _transaction);
        public IRoleGroupRepository RoleGroups => _roleGroups ??= new RoleGroupRepository(_connection, _transaction);
        public ISecurityRepository Security => _security ??= new SecurityRepository(_connection, _transaction);
        public ICatalogRepository Catalogs => _catalogs ??= new CatalogRepository(_connection, _transaction);
        public IAppointmentRepository Appointments => _appointments ??= new AppointmentRepository(_connection, _transaction);
        public IPrescriptionRepository Prescriptions => _prescriptions ??= new PrescriptionRepository(_connection, _transaction);
        public IBranchRepository Branches => _branches ??= new BranchRepository(_connection, _transaction);
        public IFacilityRoomRepository FacilityRooms => _facilityRooms ??= new FacilityRoomRepository(_connection, _transaction);
        public IPatientAntecedentRepository Antecedents => _antecedents ??= new PatientAntecedentRepository(_connection, _transaction);

        public async Task BeginTransactionAsync()
        {
            _transaction = _connection.BeginTransaction();
            await Task.CompletedTask;
        }

        public async Task CommitAsync()
        {
            try
            {
                _transaction?.Commit();
            }
            catch
            {
                await RollbackAsync();
                throw;
            }
            finally
            {
                DisposeTransaction();
            }
            await Task.CompletedTask;
        }

        public async Task RollbackAsync()
        {
            _transaction?.Rollback();
            DisposeTransaction();
            await Task.CompletedTask;
        }

        public async Task SaveChangesAsync()
        {
            // En Dapper el commit persiste los cambios realizados en la transacción
            if (_transaction != null)
                await CommitAsync();
        }

        private void DisposeTransaction()
        {
            _transaction?.Dispose();
            _transaction = null;
            // Reset de repositorios para que tomen la nueva transacción si se inicia otra
            ResetRepositories();
        }

        private void ResetRepositories()
        {
            _persons = null; _organizations = null; _patients = null; _vitalSigns = null;
            _consultations = null; _services = null; _labResults = null; _labOrders = null;
            _invoices = null; _invoiceItems = null; _medicalRecords = null; _users = null;
            _payments = null; _actions = null; _roles = null; _roleGroups = null;
            _security = null; _catalogs = null; _appointments = null; _prescriptions = null;
            _branches = null; _facilityRooms = null; _antecedents = null;
        }

        public void Dispose()
        {
            _transaction?.Dispose();
            if (_connection.State != ConnectionState.Closed)
                _connection.Close();
            _connection.Dispose();
        }
    }
}

