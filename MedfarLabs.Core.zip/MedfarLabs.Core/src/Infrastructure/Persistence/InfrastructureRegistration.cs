﻿using Dapper;
using MedfarLabs.Core.Infrastructure.Common.Interfaces;
using MedfarLabs.Core.Infrastructure.Persistence.Handlers;

namespace MedfarLabs.Core.Infrastructure.Persistence
{
    public static class InfrastructureRegistration
    {
        private static bool _handlersRegistered = false;
        private static readonly object _lock = new object();

        /// <summary>
        /// Registra los Handlers de Dapper necesarios.
        /// </summary>
        public static void RegisterDapperHandlers(IEncryptionService encryptionService)
        {
            lock (_lock)
            {
                if (_handlersRegistered) return;

                // 1. Registro del Handler de Encriptación Automática (AES-256)
                // ESTE SÍ SE QUEDA: Porque 'EncryptedData' es un tipo personalizado 
                // que Dapper no sabe manejar por sí solo.
                SqlMapper.AddTypeHandler(new EncryptedDataTypeHandler(encryptionService));

                // 2. Registro del Handler para DateOnly
                SqlMapper.AddTypeHandler(new DateOnlyTypeHandler());

                // Fix for CS0411: Explicitly specify the type argument for JsonbTypeHandler
                SqlMapper.AddTypeHandler(new JsonbTypeHandler());

                // ¡ELIMINADOS!: Dapper maneja la conversión int <-> Enum nativamente.
                // No necesitas gastar memoria ni ciclos de CPU en Handlers para esto.
                DefaultTypeMap.MatchNamesWithUnderscores = true;

                _handlersRegistered = true;
            }
        }
    }
}
