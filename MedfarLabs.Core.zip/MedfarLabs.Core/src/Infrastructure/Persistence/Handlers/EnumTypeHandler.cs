﻿using System.Data;
using Dapper;

namespace MedfarLabs.Core.Infrastructure.Persistence.Handlers
{
    public class EnumTypeHandler<T> : SqlMapper.TypeHandler<T> where T : struct, Enum
    {
        // Para INSERTAR: Enviamos el valor como String. 
        // Esto hace que Postgres acepte el dato siempre que usemos el cast en el SQL
        // O que el driver lo entienda como texto.
        public override void SetValue(IDbDataParameter parameter, T value)
        {
            parameter.Value = value.ToString();
            parameter.DbType = DbType.String;
        }

        // Para LEER: Aquí manejamos el Byte[] o el objeto nativo
        public override T Parse(object value)
        {
            if (value == null || value is DBNull) return default;

            // Caso 1: Npgsql ya lo convirtió (MapEnum activo)
            if (value is T enumValue) return enumValue;

            // Caso 2: Npgsql envió bytes (Protocolo binario)
            if (value is byte[] bytes)
            {
                var str = System.Text.Encoding.UTF8.GetString(bytes);
                return Enum.TryParse<T>(str, true, out var result) ? result : default;
            }

            // Caso 3: Viene como string u otro objeto
            return Enum.TryParse<T>(value.ToString(), true, out var result2) ? result2 : default;
        }
    }
}
