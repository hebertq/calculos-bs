﻿using System.Data;
using Dapper;
using Npgsql;
using NpgsqlTypes;
using MedfarLabs.Core.Domain.Entities.Public;

namespace MedfarLabs.Core.Infrastructure.Persistence.Handlers
{
    /// <summary>
    /// Manejador para que Dapper entienda las columnas JSONB de PostgreSQL
    /// </summary>
    // 2. Heredamos de TypeHandler<T> para que la registración sea automática
    public class JsonbTypeHandler : SqlMapper.TypeHandler<JsonValue>
    {
        public override void SetValue(IDbDataParameter parameter, JsonValue? value)
        {
            parameter.Value = value?.Value ?? (object)DBNull.Value;

            if (parameter is NpgsqlParameter npgsqlParameter)
            {
                npgsqlParameter.NpgsqlDbType = NpgsqlDbType.Jsonb;
            }
        }

        public override JsonValue Parse(object value)
        {
            return new JsonValue(value?.ToString() ?? string.Empty);
        }
    }
}
