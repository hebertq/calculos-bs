﻿using System.Data;
using Dapper;

namespace MedfarLabs.Core.Infrastructure.Persistence.Handlers
{
    public class DateOnlyTypeHandler : SqlMapper.TypeHandler<DateTime>
    {
        public override void SetValue(IDbDataParameter parameter, DateTime value)
        {
            parameter.Value = value;
        }

        public override DateTime Parse(object value)
        {
            // Si Postgres nos da un DateOnly, lo convertimos a DateTime
            if (value is DateOnly dateOnly)
            {
                return dateOnly.ToDateTime(TimeOnly.MinValue);
            }
            return Convert.ToDateTime(value);
        }
    }
}
