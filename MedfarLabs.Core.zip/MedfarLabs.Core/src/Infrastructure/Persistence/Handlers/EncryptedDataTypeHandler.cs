﻿using System.Data;
using Dapper;
using MedfarLabs.Core.Domain.Security;
using MedfarLabs.Core.Infrastructure.Common.Interfaces;

namespace MedfarLabs.Core.Infrastructure.Persistence.Handlers
{
    public class EncryptedDataTypeHandler : SqlMapper.TypeHandler<EncryptedData>
    {
        private readonly IEncryptionService _encryptionService;

        public EncryptedDataTypeHandler(IEncryptionService encryptionService)
        {
            _encryptionService = encryptionService;
        }

        // Se ejecuta al HACER UN INSERT/UPDATE (C# -> DB)
        public override void SetValue(IDbDataParameter parameter, EncryptedData? value) // Updated to allow nullable 'value'
        {
            parameter.Value = (value?.Value == null)
                ? (object)DBNull.Value
                : _encryptionService.Encrypt(value.Value);

            parameter.DbType = DbType.Binary;
        }

        // Se ejecuta al HACER UN SELECT (DB -> C#)
        public override EncryptedData Parse(object value)
        {
            if (value == null || value is DBNull) return new EncryptedData(null);

            // Verificamos que realmente sea un arreglo de bytes
            if (value is byte[] bytes)
            {
                // IMPORTANTE: Decodificamos y creamos el objeto
                var decryptedText = _encryptionService.Decrypt(bytes);
                return new EncryptedData(decryptedText);
            }

            throw new InvalidCastException($"Se esperaba byte[] pero se recibió {value.GetType().Name}");
        }
    }
}
