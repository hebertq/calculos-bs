﻿using System.Data;
using Dapper;

namespace MedfarLabs.Core.Infrastructure.Persistence.Extensions
{
    public static class DapperEnumExtensions
    {
        /// <summary>
        /// Agrega un parámetro Enum con el cast automático para Postgres.
        /// Ejemplo: p.AddEnum("rol", RolUsuario.MEDICO, "rol_usuario_enum");
        /// </summary>
        public static void AddEnum(this DynamicParameters parameters, string name, Enum value, string pgTypeName)
        {
            // Enviamos el nombre del Enum como string y Dapper se encarga del resto
            // El formato final en el SQL será: @name::pgTypeName
            parameters.Add(name, value.ToString(), DbType.String);
        }

        /// <summary>
        /// Helper para generar el fragmento de SQL con cast automático.
        /// </summary>
        public static string ToPgEnum(string paramName, string pgTypeName)
        {
            return $"@{paramName}::{pgTypeName}";
        }
    }
}
