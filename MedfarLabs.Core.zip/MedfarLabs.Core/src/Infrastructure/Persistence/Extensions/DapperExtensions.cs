﻿using System.Data;
using Dapper;
using MedfarLabs.Core.Domain.Common.Exceptions;

namespace MedfarLabs.Core.Infrastructure.Persistence.Extensions
{
    public static class DapperExtensions
    {
        /// <summary>
        /// Ejecuta una consulta y lanza KeyNotFoundException si no se encuentra el registro.
        /// </summary>
        public static async Task<T> QuerySingleOrThrowAsync<T>(
            this IDbConnection connection,
            string sql,
            object? param = null,
            string? customMessage = null)
        {
            var result = await connection.QueryFirstOrDefaultAsync<T>(sql, param);

            if (result == null)
            {
                var message = customMessage ?? $"No se encontró el registro de tipo {typeof(T).Name} con los criterios proporcionados.";
                throw new KeyNotFoundException(message);
            }

            return result;
        }

        /// <summary>
        /// Ejecuta una consulta que devuelve múltiples registros. 
        /// Lanza KeyNotFoundException si la lista está vacía.
        /// </summary>
        /// <typeparam name="T">Tipo de la entidad o DTO de respuesta.</typeparam>
        /// <param name="customMessage">Mensaje personalizado para la excepción.</param>
        public static async Task<IEnumerable<T>> QueryListOrThrowAsync<T>(
            this IDbConnection connection,
            string sql,
            object? param = null,
            string? customMessage = null)
        {
            try
            {
                var result = await connection.QueryAsync<T>(sql, param);

                // Simplified collection initialization
                var list = result?.ToList() ?? [];

                if (list.Count == 0) // Replaced Any() with Count == 0 for clarity and performance
                {
                    var message = customMessage ?? $"No se encontraron registros de tipo {typeof(T).Name} con los criterios proporcionados.";
                    throw new KeyNotFoundException(message);
                }

                return list;
            }
            catch (Exception ex) when (ex is not KeyNotFoundException)
            {
                // Envolvemos errores técnicos de SQL
                throw new PersistenceException($"Error al consultar lista de {typeof(T).Name}: {ex.Message}", ex);
            }
        }

        public static async Task<IEnumerable<T>> QueryListAsync<T>(
        this IDbConnection connection,
        string sql,
        object? param = null,
        IDbTransaction? transaction = null)
        {
            // Simplemente devuelve lo que encuentre, sin lanzar excepciones si es 0
            return await connection.QueryAsync<T>(sql, param, transaction);
        }

        /// <summary>
        /// Ejecuta una consulta para obtener un ID generado tras una inserción.
        /// </summary>
        /// <typeparam name="TId"></typeparam>
        /// <param name="connection"></param>
        /// <param name="sql"></param>
        /// <param name="param"></param>
        /// <param name="customMessage"></param>
        /// <returns></returns>
        /// <exception cref="PersistenceException"></exception>
        public static async Task<TId> QueryIdentityOrThrowAsync<TId>(
        this IDbConnection connection,
        string sql,
        object? param = null,
        string? customMessage = null)
        {
            try
            {
                // Usamos QuerySingleOrDefault para obtener el ID generado
                var result = await connection.QuerySingleOrDefaultAsync<TId>(sql, param);

                // Si el resultado es el valor por defecto (null para objetos, 0 para ints)
                if (result == null || result.Equals(default(TId)))
                {
                    throw new PersistenceException(customMessage ?? "La inserción no generó un identificador válido.");
                }

                return result;
            }
            catch (Exception ex) when (ex is not PersistenceException)
            {
                // Envolvemos errores de BD (ej: error de sintaxis o conexión)
                throw new PersistenceException($"Fallo al insertar el registro: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Ejecuta una consulta de modificación y lanza PersistenceException si no se afectó ninguna fila.
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="sql"></param>
        /// <param name="param"></param>
        /// <param name="customMessage"></param>
        /// <returns></returns>
        /// <exception cref="PersistenceException"></exception>
        public static async Task ExecuteOrThrowAsync(
        this IDbConnection connection,
        string sql,
        object? param = null,
        string? customMessage = null)
        {
            try
            {
                var rowsAffected = await connection.ExecuteAsync(sql, param);

                if (rowsAffected == 0)
                {
                    throw new PersistenceException(customMessage ?? "La operación no afectó a ninguna fila.");
                }
            }
            catch (Exception ex) when (ex is not PersistenceException)
            {
                // Aquí capturamos errores de BD (ej: Duplicate Key) y los envolvemos
                throw new PersistenceException($"Error de base de datos: {ex.Message}", ex);
            }
        }
    }
}

