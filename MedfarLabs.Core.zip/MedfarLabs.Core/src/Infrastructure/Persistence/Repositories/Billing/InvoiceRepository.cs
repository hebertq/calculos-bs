﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Billing;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Billing;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Billing
{
    public class InvoiceRepository : BaseRepository<Invoice>, IInvoiceRepository
    {
        public InvoiceRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "billing.mst_invoice", tr) { }

        public async Task<Invoice> GetByNumberAsync(string invoiceNumber, long orgId)
        {
            var invoice = await _connection.QueryIdentityOrThrowAsync<Invoice>(
                $"SELECT * FROM {_tableName} WHERE invoice_number = @invoiceNumber AND organization_id = @orgId",
                new { invoiceNumber, orgId });

            return invoice;
        }
    }
}
