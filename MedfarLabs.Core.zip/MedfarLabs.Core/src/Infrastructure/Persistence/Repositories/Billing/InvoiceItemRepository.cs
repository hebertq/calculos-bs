﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Billing;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Billing;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Billing
{
    public class InvoiceItemRepository : BaseRepository<InvoiceItem>, IInvoiceItemRepository
    {
        public InvoiceItemRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "billing.det_invoice_item", tr) { }
    }
}
