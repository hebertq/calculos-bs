﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Billing;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Billing;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Billing
{
    public class PaymentRepository : BaseRepository<Payment>, IPaymentRepository
    {
        public PaymentRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "billing.mst_payments", tr) { }

        public async Task<IEnumerable<Payment>> GetByInvoiceIdAsync(long invoiceId, long organizationId)
        {
            var sql = $"SELECT * FROM {_tableName} WHERE invoice_id = @invoiceId AND organization_id = @organizationId AND is_active = true";

            return await _connection.QueryListAsync<Payment>(sql, new { invoiceId, organizationId }, _transaction);
        }
    }
}
