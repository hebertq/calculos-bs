﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Care;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Care;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Care
{
    public class ConsultationRepository : BaseRepository<Consultation>, IConsultationRepository
    {
        public ConsultationRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "care.mst_consultation", tr) { }
    }
}
