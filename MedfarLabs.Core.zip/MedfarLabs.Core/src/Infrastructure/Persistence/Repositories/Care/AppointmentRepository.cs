﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Care;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Care;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Care
{
    public class AppointmentRepository : BaseRepository<Appointment>, IAppointmentRepository
    {
        public AppointmentRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "care.mst_appointment", tr) { }

        public async Task<IEnumerable<Appointment>> GetByBranchAndDateAsync(long branchId, DateTime date)
        {
            string sql = $"SELECT * FROM {_tableName} WHERE branch_id = @branchId AND scheduled_date = @date";
            return await _connection.QueryListAsync<Appointment>(sql, new { branchId, date });
        }
    }
}
