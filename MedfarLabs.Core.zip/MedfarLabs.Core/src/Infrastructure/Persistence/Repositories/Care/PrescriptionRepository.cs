﻿using System.Data;
using Dapper;
using MedfarLabs.Core.Domain.Entities.Care;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Care;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Care
{
    public class PrescriptionRepository : BaseRepository<Prescription>, IPrescriptionRepository
    {
        public PrescriptionRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "care.mst_prescription", tr) { }

        public async Task<long> AddItemAsync(PrescriptionItem item)
        {
            string sql = $"INSERT INTO care.det_prescription_item (prescription_id, " +
                         "medication_name, dosage, frequency, duration, instructions)VALUES "+
                         "(@PrescriptionId, @MedicationName, @Dosage, @Frequency, @Duration, @Instructions) RETURNING id;";

            return await _connection.ExecuteScalarAsync<long>(sql, item);
        }

        public async Task<IEnumerable<PrescriptionItem>> GetItemsByPrescriptionIdAsync(long prescriptionId)
        {
            string sql = $"SELECT * FROM care.det_prescription_item WHERE prescription_id = @prescriptionId";
            return await _connection.QueryListAsync<PrescriptionItem>(sql, new { prescriptionId });
        }
    }
}
