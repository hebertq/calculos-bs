﻿using System.Data;
using System.Text.Json;
using Dapper;
using MedfarLabs.Core.Domain.Entities.Common;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Common;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Common
{
    public class CatalogRepository : ICatalogRepository
    {
        private readonly IDbConnection _connection;
        private readonly IDbTransaction? _transaction;
        public CatalogRepository(IDbConnection connection, IDbTransaction? transaction = null)
        {
            _connection = connection;
            _transaction = transaction;
        }

        public async Task<IEnumerable<CatalogDetail>> GetByCatalogAsync(CatalogType catalog)
        {
            const string sql = @"
                SELECT id, catalog_id as CatalogId, code, alternative_code as AlternativeCode, 
                       name, additional_data as AdditionalData, is_active as IsActive
                FROM common.mst_catalog_detail
                WHERE catalog_id = @catalogId AND is_active = true
                ORDER BY name ASC";

            return await _connection.QueryListAsync<CatalogDetail>(sql, new { catalogId = (int)catalog });
        }

        public async Task<CatalogDetail?> GetByCodeAsync(CatalogType catalog, string code)
        {
            const string sql = @"
                SELECT id, catalog_id as CatalogId, code, alternative_code as AlternativeCode, 
                       name, additional_data as AdditionalData, is_active as IsActive
                FROM common.mst_catalog_detail
                WHERE catalog_id = @catalogId AND code = @code";

            return await _connection.QueryFirstOrDefaultAsync<CatalogDetail>(sql,
                new { catalogId = (int)catalog, code });
        }

        public async Task<T?> GetMetadataAsync<T>(CatalogType catalog, string code) where T : class
        {
            var detail = await GetByCodeAsync(catalog, code);
            if (string.IsNullOrEmpty(detail?.AdditionalData)) return null;

            return JsonSerializer.Deserialize<T>(detail.AdditionalData, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });
        }

        public async Task<IEnumerable<CatalogDetail>> GetActiveItemsAsync()
        {
            const string sql = "SELECT * FROM common.mst_catalog_detail WHERE is_active = true";
            return await _connection.QueryListAsync<CatalogDetail>(sql);
        }
    }
}
