﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Security;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Security
{
    public class RoleRepository : BaseRepository<Role>, IRoleRepository
    {
        public RoleRepository(IDbConnection connection, IDbTransaction? transaction)
            : base(connection, "security.mst_role", transaction) { }

        public async Task<IEnumerable<Role>> GetActiveRolesAsync()
        {
            string sql = $"SELECT * FROM {_tableName} WHERE is_active = true";
            return await _connection.QueryListAsync<Role>(sql, null);
        }
    }
}
