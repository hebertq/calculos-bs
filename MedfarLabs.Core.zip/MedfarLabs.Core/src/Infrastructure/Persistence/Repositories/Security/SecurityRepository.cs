﻿using System.Data;
using Dapper;
using MedfarLabs.Core.Domain.Entities.Security;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Security
{
    public class SecurityRepository : ISecurityRepository
    {
        private readonly IDbConnection _connection;
        private readonly IDbTransaction? _transaction;

        // EL CAMBIO CLAVE: Se agrega '= null' para que el DI lo trate como opcional
        public SecurityRepository(IDbConnection connection, IDbTransaction? transaction = null)
        {
            _connection = connection;
            _transaction = transaction;
        }

        public async Task<IEnumerable<int>> GetUserPermissionIdsAsync(long userId, long organizationId)
        {
            const string sql = @"
            SELECT DISTINCT mra.action_id
            FROM security.map_user_role_group murg
            JOIN security.mst_role_group mrg ON murg.role_group_id = mrg.id
            JOIN security.map_role_group_role mrgr ON mrg.id = mrgr.role_group_id
            JOIN security.map_role_action mra ON mrgr.role_id = mra.role_id
            WHERE murg.user_id = @userId 
              AND mrg.organization_id = @organizationId
              AND mrg.is_active = true";

            // Pasamos _transaction para mantener consistencia
            return await _connection.QueryListAsync<int>(sql, new { userId, organizationId }, _transaction);
        }

        public async Task AssignRolesToGroupAsync(long roleGroupId, IEnumerable<int> roleIds)
        {
            // DELETE: Debe usar la transacción para poder hacer Rollback si falla el INSERT
            await _connection.ExecuteAsync(
                "DELETE FROM security.map_role_group_role WHERE role_group_id = @roleGroupId",
                new { roleGroupId },
                _transaction);

            const string sql = "INSERT INTO security.map_role_group_role (role_group_id, role_id) VALUES (@roleGroupId, @roleId)";

            foreach (var roleId in roleIds)
            {
                await _connection.ExecuteAsync(sql, new { roleGroupId, roleId }, _transaction);
            }
        }

        public async Task<IEnumerable<RoleActionMap>> GetAllRoleActionMappingsAsync()
        {
            const string sql = "SELECT role_id as RoleId, action_id as ActionId FROM security.map_role_action";

            // Se agrega _transaction aunque sea para lectura
            return await _connection.QueryListAsync<RoleActionMap>(sql, null, _transaction);
        }

        public async Task<IEnumerable<int>> GetUserRoleIdsAsync(long userId, long organizationId)
        {
            const string sql = @"
            SELECT DISTINCT mrgr.role_id
            FROM security.map_user_role_group murg
            JOIN security.mst_role_group mrg ON murg.role_group_id = mrg.id
            JOIN security.map_role_group_role mrgr ON mrg.id = mrgr.role_group_id
            WHERE murg.user_id = @userId 
              AND mrg.organization_id = @organizationId
              AND mrg.is_active = true";

            // Cambiamos QueryAsync por tu extensión QueryListAsync para mantener el estándar
            return await _connection.QueryListAsync<int>(sql, new { userId, organizationId }, _transaction);
        }

        public async Task AssignUserToGroupAsync(long userId, long roleGroupId)
        {
            const string sql = @"
            INSERT INTO security.map_user_role_group (user_id, role_group_id)
            VALUES (@userId, @roleGroupId)
            ON CONFLICT (user_id, role_group_id) DO NOTHING;";

            await _connection.ExecuteAsync(sql,
                new { userId, roleGroupId },
                transaction: _transaction);
        }

        public async Task<long> RegisterAuditAsync(
            long orgId,
            long userId,
            int moduleId,
            int actionId,
            string jsonInput,
            bool success,
            string context = "Main",
            long? parentId = null)
        {
            const string sql = @"
        INSERT INTO security.log_audit (
            organization_id, 
            user_id, 
            module_id, 
            action_id, 
            input_data, 
            is_success, 
            execution_context, -- Nuevo campo para distinguir el entorno
            parent_id,         -- Referencia al padre (recursividad)
            created_at
        ) VALUES (
            @orgId, 
            @userId, 
            @moduleId, 
            @actionId, 
            @jsonInput::jsonb, 
            @success, 
            @context,
            @parentId,
            NOW()
        ) RETURNING id;"; // Retornamos el ID para pasarlo a los hijos

            var parameters = new
            {
                orgId,
                userId,
                moduleId,
                actionId,
                jsonInput,
                success,
                context,
                parentId
            };

            // Usamos ExecuteScalarAsync para obtener el ID recién generado
            return await _connection.ExecuteScalarAsync<long>(sql, parameters, _transaction);
        }

        public async Task<long> RegisterTelemetryAsync(long orgId, long userId, int moduleId, int actionId,
        double durationMs, bool success, string? exceptionType, string context, long? parentId = null)
        {
            const string sql = @"
                INSERT INTO security.log_telemetry (
                    organization_id, user_id, module_id, action_id, 
                    duration_ms, is_success, exception_type, execution_context, parent_id
                ) VALUES (
                    @orgId, @userId, @moduleId, @actionId, 
                    @durationMs, @success, @exceptionType, @context, @parentId
                ) RETURNING id;"; // Clave para obtener el ID generado

            return await _connection.ExecuteScalarAsync<long>(sql, new
            {
                orgId,
                userId,
                moduleId,
                actionId,
                durationMs,
                success,
                exceptionType,
                context,
                parentId
            }, _transaction);
        }
    }
}
