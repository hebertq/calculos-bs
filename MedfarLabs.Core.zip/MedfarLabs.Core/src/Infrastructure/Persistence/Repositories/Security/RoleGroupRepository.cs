﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Security;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Security
{
    public class RoleGroupRepository : BaseRepository<RoleGroup>, IRoleGroupRepository
    {
        public RoleGroupRepository(IDbConnection connection, IDbTransaction? transaction)
            : base(connection, "security.mst_role_group", transaction) { }

        public async Task<IEnumerable<RoleGroup>> GetByOrganizationAsync(long organizationId)
        {
            string sql = $"SELECT * FROM {_tableName} WHERE organization_id = @organizationId AND is_active = true";
            return await _connection.QueryListAsync<RoleGroup>(sql, new { organizationId });
        }
    }
}
