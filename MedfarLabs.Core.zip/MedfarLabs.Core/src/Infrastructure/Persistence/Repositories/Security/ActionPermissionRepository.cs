﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Security;
using MedfarLabs.Core.Domain.Enums;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Security
{
    public class ActionPermissionRepository : BaseRepository<ActionPermission>, IActionPermissionRepository
    {
        public ActionPermissionRepository(IDbConnection connection, IDbTransaction? transaction)
            : base(connection, "security.mst_action", transaction) { }

        public async Task<IEnumerable<ActionPermission>> GetByModuleAsync(AppModule moduleId)
        {
            string sql = $"SELECT * FROM {_tableName} WHERE module_id = @moduleId";
            return await _connection.QueryListAsync<ActionPermission>(sql, new { moduleId });
        }
    }
}
