﻿using System;
using System.Data;
using MedfarLabs.Core.Domain.Entities.Clinical;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Clinical;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Clinical
{
    public class PatientRepository : BaseRepository<Patient>, IPatientRepository
    {
        public PatientRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "clinical.mst_patient", tr) { }
    }
}
