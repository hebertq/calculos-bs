﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Clinical;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Clinical;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Clinical
{
    public class VitalSignsRepository : BaseRepository<VitalSigns>, IVitalSignsRepository
    {
        public VitalSignsRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "clinical.mst_vital_signs", tr) { }

        public async Task<IEnumerable<VitalSigns>> GetHistoryByPatientAsync(long patientId, int limit = 10)
        {
            string sql = $"SELECT * FROM {_tableName} WHERE patient_id = @patientId ORDER BY created_at DESC LIMIT @limit";
            return await _connection.QueryListOrThrowAsync<VitalSigns>(sql, new { patientId, limit },
                "No se encontró historial clínico de signos vitales.");
        }
    }
}
