﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Clinical;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Clinical;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Clinical
{
    public class MedicalRecordRepository : BaseRepository<MedicalRecord>, IMedicalRecordRepository
    {
        public MedicalRecordRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "clinical.mst_medical_record", tr) { }

        public async Task<MedicalRecord?> GetByPatientIdAsync(long patientId)
        {
            const string sql = "SELECT * FROM clinical.mst_medical_record WHERE patient_id = @patientId";
            return await _connection.QueryIdentityOrThrowAsync<MedicalRecord>(sql, new { patientId });
        }
    }
}
