﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Inventory;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Inventory;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Inventory
{
    public class ServiceRepository : BaseRepository<MedicalService>, IServiceRepository
    {
        public ServiceRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "inventory.mst_service", tr) { }

        public async Task<IEnumerable<MedicalService>> GetByOrganizationAsync(long orgId)
        {
            return await _connection.QueryListAsync<MedicalService>(
                $"SELECT * FROM {_tableName} WHERE organization_id = @orgId AND is_active = true",
                new { orgId });
        }
    }
}
