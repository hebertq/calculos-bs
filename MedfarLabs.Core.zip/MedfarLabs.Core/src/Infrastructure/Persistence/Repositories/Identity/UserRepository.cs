﻿using System.Data;
using Dapper;
using MedfarLabs.Core.Domain.Entities.Identity;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Identity;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Identity
{
    public class UserRepository : BaseRepository<User>, IUserRepository
    {
        public UserRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "identity.mst_user", tr) { }

        //public async Task<User?> GetByUsernameAsync(string username)
        //{
        //    return await _connection.QueryIdentityOrThrowAsync<User>($"SELECT * FROM {_tableName} WHERE username = @username", new { username });
        //}

        public async Task<User?> GetByUsernameAsync(string username)
        {
            const string sql = @"
        SELECT id, person_id as PersonId, organization_id as OrganizationId, 
               username, password_hash as PasswordHash, is_active as IsActive
        FROM identity.mst_user 
        WHERE username = @username AND is_active = true";

            // INCORRECTO: QueryIdentityOrThrowAsync (solo para INSERT)
            // CORRECTO:
            return await _connection.QueryFirstOrDefaultAsync<User>(sql, new { username });
        }
    }
}
