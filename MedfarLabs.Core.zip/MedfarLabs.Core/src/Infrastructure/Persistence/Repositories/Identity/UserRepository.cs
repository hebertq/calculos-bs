﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Identity;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Identity;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Identity
{
    public class UserRepository : BaseRepository<User>, IUserRepository
    {
        public UserRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "identity.mst_user", tr) { }

        public async Task<User?> GetByUsernameAsync(string username)
        {
            return await _connection.QueryIdentityOrThrowAsync<User>($"SELECT * FROM {_tableName} WHERE username = @username", new { username });
        }
    }
}
