﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Identity;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Identity;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using Dapper;
using MedfarLabs.Core.Domain.Interfaces.Security;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Identity
{
    public class PersonRepository : BaseRepository<Person>, IPersonRepository
    {
        private readonly IHashService _encryptionService;
        public PersonRepository(IHashService encryptionService,IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "identity.mst_person", tr)
        {
            _encryptionService = encryptionService;
        }

        public async Task<Person?> GetByBiometricHashAsync(byte[] hash)
        {
            return await _connection.QueryIdentityOrThrowAsync<Person?>(
                $"SELECT * FROM {_tableName} WHERE biometric_hash = @hash::bytea", new { hash });
        }

        public async Task<bool> ExistsByEmailAsync(string email)
        {
            // Usamos COUNT(1) porque es más rápido que traer todo el registro
            // Filtramos por is_active para permitir reutilizar correos de cuentas borradas si tu lógica lo permite
            byte[] encryptedEmail = _encryptionService.GenerateHash(email);
            string sql = $@"SELECT COUNT(1) FROM {_tableName} 
                            WHERE email = @encryptedEmail::bytea";

            // Fix: Ensure ExecuteScalar is awaited properly by wrapping it in Task.FromResult
            var count = await _connection.ExecuteScalarAsync<int>(sql, new { encryptedEmail });

            return count > 0;
        }
    }
}
