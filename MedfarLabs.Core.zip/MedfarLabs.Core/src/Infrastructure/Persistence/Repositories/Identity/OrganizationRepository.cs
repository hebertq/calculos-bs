﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Identity;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Identity;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Identity
{
    public class OrganizationRepository : BaseRepository<Organization>, IOrganizationRepository
    {
        public OrganizationRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "identity.mst_organization", tr) { }
    }
}
