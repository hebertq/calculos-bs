﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Identity;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Identity;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Identity
{
    public class BranchRepository : BaseRepository<Branch>, IBranchRepository
    {
        public BranchRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "identity.mst_branch", tr) { }

        public async Task<IEnumerable<Branch>> GetByOrganizationAsync(long organizationId)
        {
            string sql = $"SELECT * FROM {_tableName} WHERE organization_id = @organizationId";
            return await _connection.QueryListAsync<Branch>(sql, new { organizationId });
        }
    }
}
