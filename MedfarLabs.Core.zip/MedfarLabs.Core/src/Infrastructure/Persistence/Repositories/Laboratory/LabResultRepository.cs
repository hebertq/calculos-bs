﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Laboratory;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Laboratory;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Laboratory
{
    public class LabResultRepository : BaseRepository<LabResult>, ILabResultRepository
    {
        public LabResultRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "laboratory.det_lab_result", tr) { }
    }
}
