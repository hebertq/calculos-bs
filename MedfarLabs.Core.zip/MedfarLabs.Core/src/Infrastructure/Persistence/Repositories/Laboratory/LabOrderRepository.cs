﻿using System.Data;
using MedfarLabs.Core.Domain.Entities.Laboratory;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Laboratory;
using MedfarLabs.Core.Infrastructure.Persistence.Extensions;
using MedfarLabs.Core.Infrastructure.Persistence.Struct;

namespace MedfarLabs.Core.Infrastructure.Persistence.Repositories.Laboratory
{
    public class LabOrderRepository : BaseRepository<LabOrder>, ILabOrderRepository
    {
        public LabOrderRepository(IDbConnection cn, IDbTransaction? tr = null)
            : base(cn, "laboratory.mst_lab_order", tr) { }

        public async Task<IEnumerable<LabOrder>> GetByPatientIdAsync(long patientId)
        {
            const string sql = "SELECT * FROM laboratory.mst_lab_order WHERE patient_id = @patientId";
            return await _connection.QueryListOrThrowAsync<LabOrder>(sql, new { patientId });
        }
    }
}
