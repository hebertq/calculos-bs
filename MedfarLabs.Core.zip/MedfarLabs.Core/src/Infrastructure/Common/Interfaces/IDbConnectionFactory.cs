﻿using System.Data;

namespace MedfarLabs.Core.Infrastructure.Common.Interfaces
{
    public interface IDbConnectionFactory
    {
        IDbConnection CreateConnection();
    }
}
