﻿namespace MedfarLabs.Core.Infrastructure.Common.Interfaces
{
    public interface IEncryptionService
    {
        byte[] Encrypt(string plainText);
        string Decrypt(byte[] cipherText);
    }
}
