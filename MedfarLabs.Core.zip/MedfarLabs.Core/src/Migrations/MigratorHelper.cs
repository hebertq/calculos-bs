﻿using System.Reflection;
using DbUp;

namespace Migrations
{
    public static class MigratorHelper
    {
        public static bool Run(string connectionString)
        {
            var upgrader = DeployChanges.To
                .PostgresqlDatabase(connectionString)
                .WithScriptsEmbeddedInAssembly(Assembly.GetExecutingAssembly())
                .LogToConsole() // Replacing LogToEmptyLog with LogToConsole as LogToEmptyLog does not exist
                .Build();

            return upgrader.PerformUpgrade().Successful;
        }
    }
}
