﻿using System.Reflection;
using DbUp;

namespace Migrations
{
    public static class MigratorHelper
    {
        public static void Run(string connectionString)
        {
            var upgrader = DeployChanges.To
                .PostgresqlDatabase(connectionString)
                .WithScriptsEmbeddedInAssembly(Assembly.GetExecutingAssembly())
                .LogToConsole() // Replacing LogToEmptyLog with LogToConsole as LogToEmptyLog does not exist
                .Build();

            var result = upgrader.PerformUpgrade();
            if (!result.Successful)
            {
                throw new Exception($"Fallo en la migración de base de datos: {result.Error}");
            }
        }
    }
}
