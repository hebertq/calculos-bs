INSERT INTO security.mst_module (id, name, is_active) VALUES
(1, 'Security', true),
(2, 'Identity', true),
(3, 'Billing', true),
(4, 'Clinical', true),
(5, 'Care', true),
(6, 'Common', true),
(7, 'Inventory', true),
(8, 'Laboratory', true)
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

-- --- SECURITY (Module 1) ---
INSERT INTO security.mst_action (id, module_id, name) VALUES
(1001, 1, 'Crear Rol Global'),
(1002, 1, 'Asignar Acciones a Rol'),
(1003, 1, 'Crear Grupo de Roles'),
(1004, 1, 'Asignar Usuario a Grupo'),
(1005, 1, 'Consultar Permisos Usuario'),
(1006, 1, 'Registrar Usuario'),

-- --- IDENTITY (Module 2) ---
(2001, 2, 'Registrar Persona'),
(2002, 2, 'Consultar Persona'),
(2003, 2, 'Actualizar Biometr�a'),
(2004, 2, 'Baja de Persona'),
(2005, 2, 'Registrar Organizaci�n'),

-- --- BILLING (Module 3) ---
(3001, 3, 'Generar Factura'),
(3002, 3, 'Anular Factura'),
(3003, 3, 'Consultar Saldos'),
(3004, 3, 'Configurar Plan SaaS'),
(3005, 3, 'Buscar Factura'),
(3006, 3, 'Registrar Pago'),

-- --- CLINICAL (Module 4) ---
(4001, 4, 'Abrir Historia Cl�nica'),
(4002, 4, 'Registrar Atenci�n M�dica'),
(4003, 4, 'Agendar Cita'),
(4004, 4, 'Cargar Resultado Laboratorio'),
(4005, 4, 'Registrar Paciente'),
(4006, 4, 'Registrar Signos Vitales'),
(4007, 4, 'Registrar Expediente'),

-- --- CARE (Module 5) ---
(5000, 5, 'Registrar Consulta'),

-- --- COMMON (Module 6) ---
(6001, 6, 'Consultar Pa�ses'),
(6002, 6, 'Consultar G�neros'),
(6003, 6, 'Consultar Cat�logos Maestros'),

-- --- INVENTORY (Module 7) ---
(7000, 7, 'Registrar Servicio'),

-- --- LABORATORY (Module 8) ---
(8000, 8, 'Registrar Resultado'),
(8001, 8, 'Registrar Orden')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, module_id = EXCLUDED.module_id;

-- 1. ORGANIZACI�N MAESTRA
INSERT INTO identity.mst_organization (id, name, is_active) 
VALUES (1, 'MedfarLabs', true)
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

-- 2. ROLES DIN�MICOS POR M�DULO (Admin-Modulo)
-- Creamos un rol para cada registro que existe en mst_module
INSERT INTO security.mst_role (name, description)
SELECT 'Admin-' || name, 'Administrador total del m�dulo ' || name
FROM security.mst_module
ON CONFLICT (name) DO NOTHING;

-- 3. MAPEOROL-ACCI�N (Full Permissions per Role)
-- Asignamos todas las acciones de un m�dulo a su respectivo rol 'Admin-Modulo'
INSERT INTO security.map_role_action (role_id, action_id)
SELECT r.id, a.id
FROM security.mst_role r
JOIN security.mst_module m ON r.name = 'Admin-' || m.name
JOIN security.mst_action a ON a.module_id = m.id
ON CONFLICT DO NOTHING;

-- 4. GRUPO DE ROLES PARA MEDFARLABS
-- Este grupo centraliza todos los permisos de m�dulo para la organizaci�n maestra
INSERT INTO security.mst_role_group (id, organization_id, name, description)
VALUES (1, 1, 'MedfarLabs SuperGroup', 'Acceso total a todos los m�dulos del sistema')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

-- 5. VINCULAR ROLES AL GRUPO
INSERT INTO security.map_role_group_role (role_group_id, role_id)
SELECT 1, id FROM security.mst_role WHERE name LIKE 'Admin-%'
ON CONFLICT DO NOTHING;
