-- 1. M�DULOS DEL SISTEMA
INSERT INTO security.mst_module (id, name, is_active) VALUES
(1, 'Security', true),
(2, 'Identity', true),
(3, 'Billing', true),
(4, 'Clinical', true),
(5, 'Care', true),
(6, 'Common', true),
(7, 'Inventory', true),
(8, 'Laboratory', true)
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

-- 2. ACCIONES POR M�DULO (AppAction Enum)
INSERT INTO security.mst_action (id, module_id, name) VALUES
-- --- SECURITY (Module 1) ---
(1001, 1, 'Crear Rol Global'),
(1002, 1, 'Asignar Acciones a Rol'),
(1003, 1, 'Crear Grupo de Roles'),
(1004, 1, 'Asignar Usuario a Grupo'),
(1005, 1, 'Consultar Permisos Usuario'),
(1006, 1, 'Registrar Usuario'),

-- --- IDENTITY (Module 2) ---
(2001, 2, 'Registrar Persona'),
(2002, 2, 'Consultar Persona'),
(2003, 2, 'Actualizar Biometr�a'),
(2004, 2, 'Baja de Persona'),
(2005, 2, 'Registrar Organizaci�n'),
(2006, 2, 'RegistrarSucursal'),
(2007, 2, 'RegistrarConsultorio'),
(2008, 2, 'RegistrarInformacionMedico'),
(2009, 2, 'ActualizarConfiguracionOrganizacion'),

-- --- BILLING (Module 3) ---
(3001, 3, 'Generar Factura'),
(3002, 3, 'Anular Factura'),
(3003, 3, 'Consultar Saldos'),
(3004, 3, 'Configurar Plan SaaS'),
(3005, 3, 'Buscar Factura'),
(3006, 3, 'Registrar Pago'),

-- --- CLINICAL (Module 4) ---
(4001, 4, 'Abrir Historia Cl�nica'),
(4002, 4, 'Registrar Atenci�n M�dica'),
(4003, 4, 'Agendar Cita'),
(4004, 4, 'Cargar Resultado Laboratorio'),
(4005, 4, 'Registrar Paciente'),
(4006, 4, 'Registrar Signos Vitales'),
(4007, 4, 'Registrar Expediente'),
(4008, 4, 'Registrar Antecedente'),
(4009, 4, 'Registrar Alergia'),
(4010, 4, 'Registra Consentimiento'),
(4011, 4, 'Consultar Catalogo CIE10'),
(4012, 4, 'Registrar Consulta directa'),

-- --- CARE (Module 5) ---
(5000, 5, 'EmitirReceta'),
(5001, 5, 'Registrar Consulta'),
(5002, 5, 'Gestionar Cita'),
(5003, 5, 'Cargar Resultados de Laboratorio'),

-- --- COMMON (Module 6) ---
(6000, 6, 'Consultar Cat�logos Maestros'),
(6001, 6, 'Consultar Cat�logos Especifico'),
(6002, 6, 'Consultar Cat�logo Item'),

-- --- INVENTORY (Module 7) ---
(7000, 7, 'Registrar Servicio'),
(7001, 7, 'Registrar Bodega'),
(7002, 7, 'Ajustar Stock'),
(7003, 7, 'Trasladar Insumos'),

-- --- LABORATORY (Module 8) ---
(8000, 8, 'Registrar Resultado'),
(8001, 8, 'Registrar Orden')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, module_id = EXCLUDED.module_id;

-- 3. ORGANIZACI�N MAESTRA Y ROLES
INSERT INTO identity.mst_organization (id, name, is_active) 
VALUES (1, 'MedfarLabs', true)
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

INSERT INTO security.mst_role (name, description)
SELECT 'Admin-' || name, 'Administrador total del m�dulo ' || name
FROM security.mst_module
ON CONFLICT (name) DO NOTHING;

INSERT INTO security.map_role_action (role_id, action_id)
SELECT r.id, a.id
FROM security.mst_role r
JOIN security.mst_module m ON r.name = 'Admin-' || m.name
JOIN security.mst_action a ON a.module_id = m.id
ON CONFLICT DO NOTHING;

INSERT INTO security.mst_role_group (id, organization_id, name, description)
VALUES (1, 1, 'MedfarLabs SuperGroup', 'Acceso total a todos los m�dulos del sistema')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

INSERT INTO security.map_role_group_role (role_group_id, role_id)
SELECT 1, id FROM security.mst_role WHERE name LIKE 'Admin-%'
ON CONFLICT DO NOTHING;

-- 4. CATEGOR�AS DE CAT�LOGOS (Padres)
INSERT INTO common.mst_catalog (id, name, description) VALUES
(1, 'GENDER', 'G�neros biol�gicos'),
(2, 'COUNTRY', 'Listado de pa�ses ISO'),
(3, 'APPOINTMENT_STATUS', 'Estados del flujo de una cita m�dica'),
(4, 'MEDICAL_SPECIALTIES', 'Especialidades m�dicas profesionales'),
(5, 'SERVICE_CATEGORY', 'Categor�as de servicios de inventario'),
(6, 'ALLERGY_TYPE', 'Clasificaci�n de tipos de alergias'),
(7, 'ALLERGY_SEVERITY', 'Nivels de criticidad de una alergia'),
(8, 'BLOOD_TYPE', 'Grupos sangu�neos y factor RH'),
(9, 'IDENTIFICATION_TYPE', 'Documentos de identidad legal'),
(10, 'DIAGNOSIS_TYPE', 'Clasificaci�n cl�nica del diagn�stico'),
(11, 'MEDICATION_ROUTE', 'V�as de administraci�n de f�rmacos'),
(12, 'LAB_ORDER_STATUS', 'Estados del ciclo de vida de una orden de lab'),
(13, 'PAYMENT_METHOD', 'M�todos de pago aceptados'),
(14, 'UNIT_OF_MEASURE', 'Unidades de medida para inventario'),
(15, 'FACILITY_ROOM_TYPE', 'Tipos de consultorios o salas'),
(16, 'STOCK_MOVEMENT_TYPE', 'Tipos de transacci�n en bodega'),
(17, 'MARITAL_STATUS', 'Estado civil legal del paciente'),
(18, 'INVOICE_STATUS', 'Ciclo de vida de una factura'),
(19, 'PATHOLOGY_CATEGORY', 'Cap�tulos y categor�as del est�ndar CIE-10'),
(20, 'CONSENT_TYPE', 'Tipos de consentimientos informados'),
(21, 'MEDICAL_RECORD_STATUS', 'Estados del expediente (Activo, Cerrado)'),
(22, 'ANTECEDENT_TYPE', 'Tipos de antecedentes (Patol�gico, Familiar)'),
(23, 'PAYMENT_STATUS', 'Estados del pago (Procesado, Fallido)');

-- 5. DETALLES DE CAT�LOGO (Hijos)
-- G�NEROS
INSERT INTO common.mst_catalog_detail (catalog_id, code, alternative_code, name) VALUES
(1, 'M', 'MAS', 'Masculino'),
(1, 'F', 'FEM', 'Femenino'),
(1, 'U', 'UNK', 'No definido');

-- PA�SES
INSERT INTO common.mst_catalog_detail (catalog_id, code, alternative_code, name) VALUES
(2, 'CRI', '188', 'Costa Rica'),
(2, 'PAN', '591', 'Panam�'),
(2, 'USA', '840', 'Estados Unidos'),
(2, 'NIC', '558', 'Nicaragua');

-- ESTADOS DE CITA
INSERT INTO common.mst_catalog_detail (catalog_id, code, alternative_code, name) VALUES
(3, 'SCH', '1', 'Programada'),
(3, 'CON', '2', 'Confirmada'),
(3, 'WAI', '3', 'En Espera / Check-in'),
(3, 'ATT', '4', 'Atendida'),
(3, 'CAN', '5', 'Cancelada');

-- ESPECIALIDADES
INSERT INTO common.mst_catalog_detail (catalog_id, code, alternative_code, name) VALUES
(4, 'GEN', '001', 'Medicina General'),
(4, 'CAR', '002', 'Cardiolog�a'),
(4, 'LAB', '003', 'Patolog�a Cl�nica / Laboratorio'),
(4, 'PED', '004', 'Pediatr�a');

-- CATEGOR�AS DE SERVICIO
INSERT INTO common.mst_catalog_detail (catalog_id, code, alternative_code, name) VALUES
(5, 'CONS', 'C', 'Consulta M�dica'),
(5, 'LAB', 'L', 'Examen de Laboratorio'),
(5, 'PROC', 'P', 'Procedimiento Quir�rgico'),
(5, 'ITEM', 'I', 'Insumo / Medicamento');

-- TIPOS DE ALERGIAS
INSERT INTO common.mst_catalog_detail (catalog_id, code, alternative_code, name, additional_data) VALUES
(6, 'ALG_DRG', '001', 'Medicamentos', '{"severity_risk": "High", "requires_proxy": true}'),
(6, 'ALG_FOO', '002', 'Alimentaria', '{"severity_risk": "Medium", "requires_proxy": true}'),
(6, 'ALG_ENV', '003', 'Ambiental', '{"severity_risk": "Low", "requires_proxy": false}'),
(6, 'ALG_INS', '004', 'Veneno de Insectos', '{"severity_risk": "High", "requires_proxy": true}'),
(6, 'ALG_LAT', '005', 'L�tex', '{"severity_risk": "Medium", "requires_proxy": true}'),
(6, 'ALG_SKI', '006', 'Cut�nea / Contacto', '{"severity_risk": "Low", "requires_proxy": false}');

-- NIVELES DE SEVERIDAD
INSERT INTO common.mst_catalog_detail (catalog_id, code, alternative_code, name) VALUES
(7, 'SEV_LOW', 'L', 'Leve (Prurito, estornudos)'),
(7, 'SEV_MID', 'M', 'Moderada (Urticaria, angioedema)'),
(7, 'SEV_HIG', 'H', 'Severa (Dificultad respiratoria)'),
(7, 'SEV_ANA', 'A', 'Cr�tica (Choque Anafil�ctico)');

-- TIPOS DE SANGRE
INSERT INTO common.mst_catalog_detail (catalog_id, code, name) VALUES
(8, 'O+', 'O Positivo'), 
(8, 'O-', 'O Negativo'), 
(8, 'A+', 'A Positivo'), 
(8, 'B+', 'B Positivo');

-- IDENTIFICACI�N
INSERT INTO common.mst_catalog_detail (catalog_id, code, alternative_code, name, additional_data) VALUES
(9, 'ID_CED', '001', 'C�dula de Identidad', '{"regex": "^[0-9]{9,12}$", "is_required_for_billing": true}'),
(9, 'ID_PAS', '002', 'Pasaporte', '{"regex": "^[A-Z0-9]{6,15}$", "is_required_for_billing": true}'),
(9, 'ID_TAX', '003', 'Registro Tributario (RUC/NIT)', '{"is_business_only": true}');

-- DIAGN�STICO
INSERT INTO common.mst_catalog_detail (catalog_id, code, alternative_code, name, additional_data) VALUES
(10, 'DX_PRE', 'P', 'Presuntivo', '{"requires_follow_up": true, "is_final": false}'),
(10, 'DX_DEF', 'D', 'Definitivo', '{"requires_follow_up": false, "is_final": true}'),
(10, 'DX_SYN', 'S', 'Sintom�tico', '{"requires_follow_up": true, "is_final": false}'),
(10, 'DX_DIF', 'F', 'Diferencial', '{"requires_follow_up": true, "is_final": false}');

-- V�AS DE ADMINISTRACI�N
INSERT INTO common.mst_catalog_detail (catalog_id, code, name, additional_data) VALUES
(11, 'ORAL', 'V�a Oral', '{"requires_water": true}'),
(11, 'IV', 'Intravenosa', '{"requires_professional": true, "max_speed_ml_h": 100}'),
(11, 'IM', 'Intramuscular', '{"requires_professional": true}');

-- ESTADOS ORDEN LABORATORIO
INSERT INTO common.mst_catalog_detail (catalog_id, code, alternative_code, name, additional_data) VALUES
(12, 'LAB_REQ', '01', 'Solicitada', '{"is_final": false, "billable": true, "ui_color": "#FFA500"}'),
(12, 'LAB_SAM', '02', 'Muestra Tomada', '{"is_final": false, "notifiable": false, "ui_color": "#0000FF"}'),
(12, 'LAB_PRO', '03', 'En Proceso', '{"is_final": false, "allows_edit": true, "ui_color": "#FFFF00"}'),
(12, 'LAB_COM', '04', 'Resultados Listos', '{"is_final": false, "requires_signature": true, "ui_color": "#ADFF2F"}'),
(12, 'LAB_VAL', '05', 'Validada / Finalizada', '{"is_final": true, "send_to_patient": true, "ui_color": "#008000"}'),
(12, 'LAB_REJ', '06', 'Muestra Rechazada', '{"is_final": true, "alert_doctor": true, "ui_color": "#FF0000"}'),
(12, 'LAB_CAN', '07', 'Cancelada', '{"is_final": true, "billable": false, "ui_color": "#808080"}');

-- PAGOS
INSERT INTO common.mst_catalog_detail (catalog_id, code, name, additional_data) VALUES
(13, 'CASH', 'Efectivo', '{"is_instant": true}'),
(13, 'CARD', 'Tarjeta Cr�dito/D�bito', '{"requires_terminal": true, "fee_percentage": 3.5}'),
(13, 'INS', 'Seguro M�dico', '{"requires_authorization": true}');

-- UNIDADES DE MEDIDA E INFRAESTRUCTURA
INSERT INTO common.mst_catalog_detail (catalog_id, code, name) VALUES
(14, 'UNIT', 'Unidad / Pieza'), 
(14, 'BOX', 'Caja'), 
(14, 'ML', 'Mililitros'),
(14, 'MG', 'Miligramos'),
(14, 'U_PCS', 'Pieza / Unidad'),
(14, 'U_BOX', 'Caja'),
(14, 'U_ML', 'Mililitros'),
(14, 'U_TAB', 'Tabletas / C�psulas'),
(15, 'CONSULT', 'Consultorio Est�ndar'), 
(15, 'SURGERY', 'Sala de Cirug�a');

-- MOVIMIENTOS DE STOCK
INSERT INTO common.mst_catalog_detail (catalog_id, code, name, additional_data) VALUES
(16, 'STK_IN', 'Entrada por Compra', '{"operation": "ADD"}'),
(16, 'STK_OUT', 'Salida por Venta', '{"operation": "SUBTRACT"}'),
(16, 'STK_ADJ', 'Ajuste de Inventario', '{"operation": "MANUAL"}'),
(16, 'STK_TRA', 'Traslado entre Bodegas', '{"operation": "NEUTRAL"}');

-- ESTADO CIVIL
INSERT INTO common.mst_catalog_detail (catalog_id, code, name) VALUES
(17, 'SOL', 'Soltero(a)'), 
(17, 'CAS', 'Casado(a)'), 
(17, 'DIV', 'Divorciado(a)'), 
(17, 'VIU', 'Viudo(a)');

-- FACTURACI�N
INSERT INTO common.mst_catalog_detail (catalog_id, code, name, additional_data) VALUES
(18, 'INV_DRA', 'Borrador', '{"is_final": false, "can_edit": true}'),
(18, 'INV_PAI', 'Pagada', '{"is_final": true, "trigger_receipt": true}'),
(18, 'INV_PAR', 'Pago Parcial', '{"is_final": false, "can_edit": false}'),
(18, 'INV_CAN', 'Anulada', '{"is_final": true, "requires_reason": true}');

-- CAP�TULOS CIE-10
INSERT INTO common.mst_catalog_detail (catalog_id, code, name) VALUES
(19, 'CIE_CH1', 'Cap�tulo I: Enfermedades infecciosas y parasitarias'),
(19, 'CIE_CH2', 'Cap�tulo II: Neoplasias (C�ncer)'),
(19, 'CIE_CH4', 'Cap�tulo IV: Enfermedades endocrinas y metab�licas'),
(19, 'CIE_CH9', 'Cap�tulo IX: Enfermedades del sistema circulatorio'),
(19, 'CIE_CH10', 'Cap�tulo X: Enfermedades del sistema respiratorio');

-- LEGAL Y CL�NICA (FK Resolution)
INSERT INTO common.mst_catalog_detail (catalog_id, code, name) VALUES 
(20, 'SURGICAL', 'Consentimiento Quir�rgico'), 
(20, 'TELEMED', 'Consentimiento Telemedicina'),
(21, 'ACT', 'Activo'), 
(21, 'INA', 'Inactivo'), 
(21, 'ARC', 'Archivado/Pasivo'),
(22, 'PAT', 'Patol�gico'), 
(22, 'FAM', 'Heredo-Familiar'), 
(22, 'SUR', 'Quir�rgico'), 
(22, 'NON', 'No Patol�gico');

-- ESTADOS DE PAGO
INSERT INTO common.mst_catalog_detail (catalog_id, code, name) VALUES 
(23, 'PAY_PRO', 'Procesado'), 
(23, 'PAY_PEN', 'Pendiente'), 
(23, 'PAY_FAL', 'Fallido'), 
(23, 'PAY_REV', 'Reversado');

-- Sincronizar secuencias tras inserciones manuales
SELECT setval('identity.mst_organization_id_seq', (SELECT MAX(id) FROM identity.mst_organization));
SELECT setval('common.mst_catalog_detail_id_seq', (SELECT MAX(id) FROM common.mst_catalog_detail));