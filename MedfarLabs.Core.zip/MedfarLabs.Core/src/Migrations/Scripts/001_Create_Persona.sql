-- -----------------------------------------------------------------------------
-- 1. CONFIGURACI�N INICIAL Y EXTENSIONES
-- -----------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. SCHEMAS
CREATE SCHEMA IF NOT EXISTS identity;
CREATE SCHEMA IF NOT EXISTS inventory;
CREATE SCHEMA IF NOT EXISTS clinical;
CREATE SCHEMA IF NOT EXISTS care;
CREATE SCHEMA IF NOT EXISTS laboratory;
CREATE SCHEMA IF NOT EXISTS billing;
CREATE SCHEMA IF NOT EXISTS security;

-- -----------------------------------------------------------------------------
-- 3. SEGURIDAD MAESTRA (Nivel 0)
-- -----------------------------------------------------------------------------
CREATE TABLE security.mst_module (
    id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE security.mst_action (
    id INT PRIMARY KEY, -- ID del Enum AppAction (ej: 2001)
    module_id INT REFERENCES security.mst_module(id),
    name VARCHAR(100) NOT NULL,
    description TEXT
);

CREATE TABLE security.mst_role (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE security.map_role_action (
    role_id INT NOT NULL REFERENCES security.mst_role(id),
    action_id INT NOT NULL REFERENCES security.mst_action(id),
    PRIMARY KEY (role_id, action_id)
);

-- -----------------------------------------------------------------------------
-- 4. IDENTITY (Nivel 0-1)
-- -----------------------------------------------------------------------------
CREATE TABLE identity.mst_organization (
    id BIGSERIAL PRIMARY KEY,
    organization_uuid UUID UNIQUE DEFAULT uuid_generate_v4(),
    name VARCHAR(200) NOT NULL,
    tax_id BYTEA, 
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT,
    updated_by_user_id BIGINT,
    audit_notes TEXT
);

CREATE TABLE identity.mst_person (
    id BIGSERIAL PRIMARY KEY,
    person_uuid UUID UNIQUE DEFAULT uuid_generate_v4(),
    biometric_hash BYTEA UNIQUE, -- Removido NOT NULL temporalmente para facilitar seeding
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    last_name VARCHAR(100) NOT NULL,
    second_last_name VARCHAR(100),
    birth_date DATE NOT NULL,
    gender_id INT NOT NULL,
    birth_country_id INT NOT NULL,
    email BYTEA, 
    mobile_phone BYTEA,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT,
    updated_by_user_id BIGINT,
    audit_notes TEXT
);

CREATE UNIQUE INDEX idx_unique_email_index_bin ON identity.mst_person (email) WHERE email IS NOT NULL;

CREATE TABLE identity.mst_user (
    id BIGSERIAL PRIMARY KEY,
    person_id BIGINT REFERENCES identity.mst_person(id),
    organization_id BIGINT REFERENCES identity.mst_organization(id),
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash BYTEA NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT,
    updated_by_user_id BIGINT,
    audit_notes TEXT
);

-- -----------------------------------------------------------------------------
-- 5. SEGURIDAD POR ORGANIZACI�N (Nivel 2)
-- -----------------------------------------------------------------------------
CREATE TABLE security.mst_role_group (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES identity.mst_organization(id),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE security.map_role_group_role (
    role_group_id BIGINT NOT NULL REFERENCES security.mst_role_group(id) ON DELETE CASCADE,
    role_id INT NOT NULL REFERENCES security.mst_role(id),
    PRIMARY KEY (role_group_id, role_id)
);

CREATE TABLE security.map_user_role_group (
    user_id BIGINT NOT NULL REFERENCES identity.mst_user(id),
    role_group_id BIGINT NOT NULL REFERENCES security.mst_role_group(id),
    PRIMARY KEY (user_id, role_group_id)
);

-- -----------------------------------------------------------------------------
-- 6. INVENTORY
-- -----------------------------------------------------------------------------
CREATE TABLE inventory.mst_service (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT REFERENCES identity.mst_organization(id),
    category_id INT NOT NULL, -- 1: Consulta, 2: Lab, 3: Proc, 4: Insumo
    sku_code VARCHAR(50),
    name VARCHAR(200) NOT NULL,
    description TEXT,
    base_price DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    is_taxable BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

-- -----------------------------------------------------------------------------
-- 7. CLINICAL & CARE
-- -----------------------------------------------------------------------------
CREATE TABLE clinical.mst_patient (
    id BIGSERIAL PRIMARY KEY,
    person_id BIGINT NOT NULL REFERENCES identity.mst_person(id),
    organization_id BIGINT NOT NULL REFERENCES identity.mst_organization(id),
    internal_code VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT,
    UNIQUE(organization_id, internal_code)
);

CREATE TABLE clinical.mst_medical_record (
    id BIGSERIAL PRIMARY KEY,
    patient_id BIGINT REFERENCES clinical.mst_patient(id),
    record_number VARCHAR(50) UNIQUE NOT NULL,
    status_id INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE TABLE care.mst_consultation (
    id BIGSERIAL PRIMARY KEY,
    medical_record_id BIGINT REFERENCES clinical.mst_medical_record(id),
    doctor_user_id BIGINT REFERENCES identity.mst_user(id),
    subjective_data TEXT,
    objective_data TEXT, 
    analysis_data TEXT,
    plan_data TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE TABLE clinical.mst_vital_signs (
    id BIGSERIAL PRIMARY KEY,
    patient_id BIGINT NOT NULL REFERENCES clinical.mst_patient(id),
    consultation_id BIGINT REFERENCES care.mst_consultation(id),
    systolic_pressure NUMERIC(5,2),
    diastolic_pressure NUMERIC(5,2),
    heart_rate INT,
    respiratory_rate INT,
    temperature NUMERIC(4,2),
    weight_kg NUMERIC(5,2),
    height_cm NUMERIC(5,2),
    oxygen_saturation NUMERIC(5,2),
    body_mass_index NUMERIC(4,2),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

-- -----------------------------------------------------------------------------
-- 8. LABORATORY
-- -----------------------------------------------------------------------------
CREATE TABLE laboratory.mst_lab_order (
    id BIGSERIAL PRIMARY KEY,
    consultation_id BIGINT REFERENCES care.mst_consultation(id),
    patient_id BIGINT REFERENCES clinical.mst_patient(id),
    service_id BIGINT REFERENCES inventory.mst_service(id),
    status_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE TABLE laboratory.det_lab_result (
    id BIGSERIAL PRIMARY KEY,
    lab_order_id BIGINT REFERENCES laboratory.mst_lab_order(id),
    technical_data_json JSONB NOT NULL,
    attachment_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

-- -----------------------------------------------------------------------------
-- 9. BILLING
-- -----------------------------------------------------------------------------
CREATE TABLE billing.mst_invoice (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT REFERENCES identity.mst_organization(id),
    patient_id BIGINT REFERENCES clinical.mst_patient(id),
    invoice_number VARCHAR(30) UNIQUE NOT NULL,
    subtotal DECIMAL(18,2) NOT NULL DEFAULT 0,
    tax_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
    total_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
    status_id INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE TABLE billing.det_invoice_item (
    id BIGSERIAL PRIMARY KEY,
    invoice_id BIGINT REFERENCES billing.mst_invoice(id),
    service_id BIGINT REFERENCES inventory.mst_service(id),
    quantity DECIMAL(18,2) NOT NULL DEFAULT 1.00,
    unit_price DECIMAL(18,2) NOT NULL,
    line_total DECIMAL(18,2) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE TABLE billing.mst_payments (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES identity.mst_organization(id),
    invoice_id BIGINT NOT NULL REFERENCES billing.mst_invoice(id),
    payment_method_id INT NOT NULL,
    amount NUMERIC(18, 2) NOT NULL,
    transaction_reference VARCHAR(100),
    payment_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    status_id INT NOT NULL DEFAULT 1,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by_user_id BIGINT NOT NULL
);

-- �ndices estrat�gicos finales
CREATE INDEX idx_payments_organization ON billing.mst_payments(organization_id);
CREATE INDEX idx_payments_invoice ON billing.mst_payments(invoice_id);

-------- Tabla de audtoria --------------------------------------------------
CREATE TABLE security.log_audit (
    id                BIGSERIAL PRIMARY KEY,
    organization_id   BIGINT NOT NULL,
    user_id           BIGINT NOT NULL,
    module_id         INT NOT NULL,
    action_id         INT NOT NULL,
    input_data        JSONB NOT NULL,          -- El DTO serializado
    is_success        BOOLEAN NOT NULL,
    execution_context VARCHAR(50) NOT NULL,    -- 'Main' o 'Worker'
    parent_id         BIGINT NULL,             -- ID de la acci�n padre
    created_at        TIMESTAMPTZ DEFAULT NOW(),

    -- Relaci�n recursiva
    CONSTRAINT fk_audit_parent 
        FOREIGN KEY (parent_id) REFERENCES security.log_audit(id)
);

-- �ndices optimizados
CREATE INDEX idx_audit_org_module ON security.log_audit(organization_id, module_id);
CREATE INDEX idx_audit_parent_id ON security.log_audit(parent_id);

CREATE TABLE security.log_telemetry (
    id                BIGSERIAL PRIMARY KEY,
    organization_id   BIGINT NOT NULL,
    user_id           BIGINT NOT NULL,
    module_id         INT NOT NULL,
    action_id         INT NOT NULL,
    duration_ms       NUMERIC(18, 4) NOT NULL, -- Tiempo en milisegundos
    is_success        BOOLEAN NOT NULL,
    exception_type    TEXT NULL,               -- Mensaje de error si fall�
    execution_context VARCHAR(50) NOT NULL,    -- 'Main' o 'Worker'
    parent_id         BIGINT NULL,             -- ID de la m�trica padre
    created_at        TIMESTAMPTZ DEFAULT NOW(),

    -- Relaci�n recursiva
    CONSTRAINT fk_telemetry_parent 
        FOREIGN KEY (parent_id) REFERENCES security.log_telemetry(id)
);

-- �ndices optimizados para reportes de lentitud
CREATE INDEX idx_telemetry_perf ON security.log_telemetry(module_id, action_id, duration_ms DESC);
CREATE INDEX idx_telemetry_parent_id ON security.log_telemetry(parent_id);