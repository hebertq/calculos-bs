-- -----------------------------------------------------------------------------
-- 1. CONFIGURACI�N INICIAL Y EXTENSIONES
-- -----------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. SCHEMAS
CREATE SCHEMA IF NOT EXISTS identity;
CREATE SCHEMA IF NOT EXISTS inventory;
CREATE SCHEMA IF NOT EXISTS clinical;
CREATE SCHEMA IF NOT EXISTS care;
CREATE SCHEMA IF NOT EXISTS laboratory;
CREATE SCHEMA IF NOT EXISTS billing;
CREATE SCHEMA IF NOT EXISTS security;
CREATE SCHEMA IF NOT EXISTS common;

-- Tabla para agrupar tipos de cat�logos (Ej: Pa�ses, G�neros, Especialidades)
CREATE TABLE common.mst_catalog (
    id          INT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    is_active   BOOLEAN DEFAULT TRUE
);

-- Detalle de los cat�logos con soporte para l�gica de negocio
CREATE TABLE common.mst_catalog_detail (
    id              BIGSERIAL PRIMARY KEY,
    catalog_id      INT REFERENCES common.mst_catalog(id),
    code            VARCHAR(50) NOT NULL, -- DetailCode
    alternative_code VARCHAR(50),          -- CoreCode
    name            VARCHAR(200) NOT NULL,
    additional_data JSONB,                -- Para ponderaciones de riesgo
    is_active       BOOLEAN DEFAULT TRUE,
    UNIQUE(catalog_id, code)
);

CREATE INDEX idx_catalog_search ON common.mst_catalog_detail(catalog_id, code, alternative_code);


-- -----------------------------------------------------------------------------
-- 3. SEGURIDAD MAESTRA (Nivel 0)
-- -----------------------------------------------------------------------------
CREATE TABLE security.mst_module (
    id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE security.mst_action (
    id INT PRIMARY KEY, -- ID del Enum AppAction (ej: 2001)
    module_id INT REFERENCES security.mst_module(id),
    name VARCHAR(100) NOT NULL,
    description TEXT
);

CREATE TABLE security.mst_role (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE security.map_role_action (
    role_id INT NOT NULL REFERENCES security.mst_role(id),
    action_id INT NOT NULL REFERENCES security.mst_action(id),
    PRIMARY KEY (role_id, action_id)
);

-- -----------------------------------------------------------------------------
-- 4. IDENTITY (Nivel 0-1)
-- -----------------------------------------------------------------------------
CREATE TABLE identity.mst_organization (
    id BIGSERIAL PRIMARY KEY,
    organization_uuid UUID UNIQUE DEFAULT uuid_generate_v4(),
    name VARCHAR(200) NOT NULL,
    tax_id BYTEA, 
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT,
    updated_by_user_id BIGINT,
    audit_notes TEXT
);

CREATE TABLE identity.mst_person (
    id BIGSERIAL PRIMARY KEY,
    person_uuid UUID UNIQUE DEFAULT uuid_generate_v4(),
    biometric_hash BYTEA UNIQUE,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    last_name VARCHAR(100) NOT NULL,
    second_last_name VARCHAR(100),
    birth_date DATE NOT NULL,
    -- FKs a Cat�logos
    gender_id INT REFERENCES common.mst_catalog_detail(id),
    birth_country_id INT REFERENCES common.mst_catalog_detail(id),
    id_type_id INT REFERENCES common.mst_catalog_detail(id),
    marital_status_id INT REFERENCES common.mst_catalog_detail(id),
    email BYTEA, 
    mobile_phone BYTEA,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT,
    updated_by_user_id BIGINT,
    audit_notes TEXT
);

CREATE UNIQUE INDEX idx_unique_email_index_bin ON identity.mst_person (email) WHERE email IS NOT NULL;

CREATE TABLE identity.mst_user (
    id BIGSERIAL PRIMARY KEY,
    person_id BIGINT REFERENCES identity.mst_person(id),
    organization_id BIGINT REFERENCES identity.mst_organization(id),
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash BYTEA NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT,
    updated_by_user_id BIGINT,
    audit_notes TEXT
);

CREATE TABLE identity.mst_organization_config (
    id              BIGSERIAL PRIMARY KEY,
    organization_id BIGINT UNIQUE REFERENCES identity.mst_organization(id),
    currency_code   VARCHAR(10) DEFAULT 'USD',
    tax_percentage  DECIMAL(5,2) DEFAULT 0.00,
    logo_url        VARCHAR(500),
    timezone        VARCHAR(50) DEFAULT 'UTC',
    settings        JSONB, -- Configuraciones din�micas adicionales
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT,
    updated_by_user_id BIGINT,
    audit_notes TEXT
);

-- Sucursales de la organizaci�n
CREATE TABLE identity.mst_branch (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES identity.mst_organization(id),
    name VARCHAR(200) NOT NULL,
    address TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT,
    updated_by_user_id BIGINT,
    audit_notes TEXT
);

-- Consultorios f�sicos dentro de una sucursal
CREATE TABLE identity.mst_facility_room (
    id BIGSERIAL PRIMARY KEY,
    branch_id BIGINT NOT NULL REFERENCES identity.mst_branch(id),
    name VARCHAR(100) NOT NULL, -- Ej: Consultorio 101, Sala de Rayos X
    type_id INT REFERENCES common.mst_catalog_detail(id), -- Referencia a common.mst_catalog_detail (Consultorio, Quir�fano, etc.)
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT,
    updated_by_user_id BIGINT,
    audit_notes TEXT
);

-- -----------------------------------------------------------------------------
-- 5. SEGURIDAD POR ORGANIZACI�N (Nivel 2)
-- -----------------------------------------------------------------------------
CREATE TABLE security.mst_role_group (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES identity.mst_organization(id),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE security.map_role_group_role (
    role_group_id BIGINT NOT NULL REFERENCES security.mst_role_group(id) ON DELETE CASCADE,
    role_id INT NOT NULL REFERENCES security.mst_role(id),
    PRIMARY KEY (role_group_id, role_id)
);

CREATE TABLE security.map_user_role_group (
    user_id BIGINT NOT NULL REFERENCES identity.mst_user(id),
    role_group_id BIGINT NOT NULL REFERENCES security.mst_role_group(id),
    PRIMARY KEY (user_id, role_group_id)
);

-- -----------------------------------------------------------------------------
-- 6. INVENTORY
-- -----------------------------------------------------------------------------
CREATE TABLE inventory.mst_service (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT REFERENCES identity.mst_organization(id),
    category_id INT REFERENCES common.mst_catalog_detail(id), -- 1: Consulta, 2: Lab, 3: Proc, 4: Insumo
    sku_code VARCHAR(50),
    name VARCHAR(200) NOT NULL,
    description TEXT,
    base_price DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    is_taxable BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

-- Bodegas o Almacenes
CREATE TABLE inventory.mst_warehouse (
    id BIGSERIAL PRIMARY KEY,
    branch_id BIGINT NOT NULL REFERENCES identity.mst_branch(id),
    name VARCHAR(100) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE
);

-- Existencias (Stock)
CREATE TABLE inventory.det_stock (
    id BIGSERIAL PRIMARY KEY,
    warehouse_id BIGINT NOT NULL REFERENCES inventory.mst_warehouse(id),
    service_id BIGINT NOT NULL REFERENCES inventory.mst_service(id),
    quantity DECIMAL(18,2) NOT NULL DEFAULT 0,
    min_stock DECIMAL(18,2) DEFAULT 0,
    batch_number VARCHAR(50), -- Lote
    expiration_date DATE,
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Movimientos de Inventario
CREATE TABLE inventory.log_stock_movement (
    id BIGSERIAL PRIMARY KEY,
    warehouse_id BIGINT NOT NULL REFERENCES inventory.mst_warehouse(id),
    service_id BIGINT NOT NULL REFERENCES inventory.mst_service(id),
    type_id INT REFERENCES common.mst_catalog_detail(id), -- 1: Entrada, 2: Salida por Venta, 3: Ajuste, 4: Traslado
    quantity DECIMAL(18,2) NOT NULL,
    reference_id BIGINT, -- ID de la factura o de la orden de compra
    created_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id)
);
-- -----------------------------------------------------------------------------
-- 7. CLINICAL & CARE
-- -----------------------------------------------------------------------------
-- Diagn�sticos realizados en una consulta
CREATE TABLE clinical.mst_diagnosis_code (
    id              SERIAL PRIMARY KEY,
    code            VARCHAR(20) UNIQUE NOT NULL, -- C�digo CIE-10
    description     TEXT NOT NULL,               -- Nombre de la enfermedad
    category_id     INT REFERENCES common.mst_catalog_detail(id),-- Cap�tulo o Grupo (Ej: Neoplasias)
    additional_data JSONB,                       -- Metadatos (Cr�nico, Alerta, etc.)
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT NOW()
);

-- �ndice de b�squeda r�pida por c�digo
CREATE INDEX idx_diagnosis_code ON clinical.mst_diagnosis_code(code);
-- �ndice GIN para b�squeda de texto completo en la descripci�n (B�squeda inteligente)
CREATE INDEX idx_diagnosis_description_gin ON clinical.mst_diagnosis_code USING gin(to_tsvector('spanish', description));

CREATE TABLE clinical.mst_patient (
    id BIGSERIAL PRIMARY KEY,
    person_id BIGINT NOT NULL REFERENCES identity.mst_person(id),
    organization_id BIGINT NOT NULL REFERENCES identity.mst_organization(id),
    internal_code VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT,
    UNIQUE(organization_id, internal_code)
);

CREATE TABLE clinical.mst_medical_record (
    id BIGSERIAL PRIMARY KEY,
    patient_id BIGINT REFERENCES clinical.mst_patient(id),
    record_number VARCHAR(50) UNIQUE NOT NULL,
    status_id INT REFERENCES common.mst_catalog_detail(id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE TABLE care.mst_consultation (
    id BIGSERIAL PRIMARY KEY,
    medical_record_id BIGINT REFERENCES clinical.mst_medical_record(id),
    doctor_user_id BIGINT REFERENCES identity.mst_user(id),
    subjective_data TEXT,
    objective_data TEXT, 
    analysis_data TEXT,
    plan_data TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

-- Antecedentes m�dicos del paciente (Patol�gicos, Familiares, etc.)
CREATE TABLE clinical.mst_patient_antecedent (
    id              BIGSERIAL PRIMARY KEY,
    patient_id      BIGINT REFERENCES clinical.mst_patient(id),
    type_id         INT REFERENCES common.mst_catalog_detail (id), -- 1: Patol�gico, 2: Alergia, etc.
    description     TEXT NOT NULL,
    is_active       BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE INDEX idx_patient_antecedents ON clinical.mst_patient_antecedent(patient_id);

CREATE TABLE clinical.mst_vital_signs (
    id BIGSERIAL PRIMARY KEY,
    patient_id BIGINT NOT NULL REFERENCES clinical.mst_patient(id),
    consultation_id BIGINT REFERENCES care.mst_consultation(id),
    systolic_pressure NUMERIC(5,2),
    diastolic_pressure NUMERIC(5,2),
    heart_rate INT,
    respiratory_rate INT,
    temperature NUMERIC(4,2),
    weight_kg NUMERIC(5,2),
    height_cm NUMERIC(5,2),
    oxygen_saturation NUMERIC(5,2),
    body_mass_index NUMERIC(4,2),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE TABLE care.mst_prescription (
    id              BIGSERIAL PRIMARY KEY,
    consultation_id BIGINT REFERENCES care.mst_consultation(id),
    patient_id      BIGINT REFERENCES clinical.mst_patient(id),
    doctor_user_id  BIGINT REFERENCES identity.mst_user(id),
    notes           TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE TABLE care.det_prescription_item (
    id              BIGSERIAL PRIMARY KEY,
    prescription_id BIGINT REFERENCES care.mst_prescription(id),
    medication_name VARCHAR(200) NOT NULL,
    dosage          VARCHAR(100), -- Ej: 500mg
    frequency       VARCHAR(100), -- Ej: Cada 8 horas
    duration        VARCHAR(100), -- Ej: 7 d�as
    instructions    TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE INDEX idx_prescription_patient ON care.mst_prescription(patient_id);

CREATE TABLE care.mst_appointment (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES identity.mst_organization(id),
    branch_id BIGINT NOT NULL REFERENCES identity.mst_branch(id),
    patient_id BIGINT NOT NULL REFERENCES clinical.mst_patient(id),
    doctor_user_id BIGINT NOT NULL REFERENCES identity.mst_user(id),
    facility_room_id BIGINT REFERENCES identity.mst_facility_room(id),
    scheduled_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status_id INT REFERENCES common.mst_catalog_detail (id), -- 1: Programada, 2: Confirmada, 3: En Espera, 4: Atendida, 5: Cancelada
    reason_notes TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE INDEX idx_appointment_date ON care.mst_appointment(branch_id, scheduled_date);
-- -----------------------------------------------------------------------------
-- 8. LABORATORY
-- -----------------------------------------------------------------------------
CREATE TABLE laboratory.mst_lab_order (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES identity.mst_organization(id), -- AGREGAR ESTA L�NEA
    consultation_id BIGINT REFERENCES care.mst_consultation(id),
    patient_id BIGINT REFERENCES clinical.mst_patient(id),
    service_id BIGINT REFERENCES inventory.mst_service(id),
    status_id  INT REFERENCES common.mst_catalog_detail(id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE TABLE laboratory.det_lab_result (
    id BIGSERIAL PRIMARY KEY,
    lab_order_id BIGINT REFERENCES laboratory.mst_lab_order(id),
    technical_data_json JSONB NOT NULL,
    attachment_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

-- -----------------------------------------------------------------------------
-- 9. BILLING
-- -----------------------------------------------------------------------------
CREATE TABLE billing.mst_invoice (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT REFERENCES identity.mst_organization(id),
    patient_id BIGINT REFERENCES clinical.mst_patient(id),
    invoice_number VARCHAR(30) UNIQUE NOT NULL,
    subtotal DECIMAL(18,2) NOT NULL DEFAULT 0,
    tax_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
    total_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
    status_id  INT REFERENCES common.mst_catalog_detail(id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE TABLE billing.det_invoice_item (
    id BIGSERIAL PRIMARY KEY,
    invoice_id BIGINT REFERENCES billing.mst_invoice(id),
    service_id BIGINT REFERENCES inventory.mst_service(id),
    quantity DECIMAL(18,2) NOT NULL DEFAULT 1.00,
    unit_price DECIMAL(18,2) NOT NULL,
    line_total DECIMAL(18,2) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id BIGINT REFERENCES identity.mst_user(id),
    updated_by_user_id BIGINT REFERENCES identity.mst_user(id),
    audit_notes TEXT
);

CREATE TABLE billing.mst_payments (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES identity.mst_organization(id),
    invoice_id BIGINT NOT NULL REFERENCES billing.mst_invoice(id),
    payment_method_id INT REFERENCES common.mst_catalog_detail(id), 
    amount NUMERIC(18, 2) NOT NULL,
    transaction_reference VARCHAR(100),
    payment_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    status_id INT REFERENCES common.mst_catalog_detail(id), 
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by_user_id BIGINT NOT NULL
);

-- �ndices estrat�gicos finales
CREATE INDEX idx_payments_organization ON billing.mst_payments(organization_id);
CREATE INDEX idx_payments_invoice ON billing.mst_payments(invoice_id);

-------- Tabla de audtoria --------------------------------------------------
CREATE TABLE security.log_audit (
    id                BIGSERIAL PRIMARY KEY,
    organization_id   BIGINT REFERENCES identity.mst_organization(id),
    user_id           BIGINT NOT NULL,
    module_id         INT NOT NULL,
    action_id         INT NOT NULL,
    input_data        JSONB NOT NULL,          -- El DTO serializado
    is_success        BOOLEAN NOT NULL,
    execution_context VARCHAR(50) NOT NULL,    -- 'Main' o 'Worker'
    parent_id         BIGINT NULL,             -- ID de la acci�n padre
    created_at        TIMESTAMPTZ DEFAULT NOW(),

    -- Relaci�n recursiva
    CONSTRAINT fk_audit_parent 
        FOREIGN KEY (parent_id) REFERENCES security.log_audit(id)
);

-- �ndices optimizados
CREATE INDEX idx_audit_org_module ON security.log_audit(organization_id, module_id);
CREATE INDEX idx_audit_parent_id ON security.log_audit(parent_id);

CREATE TABLE security.log_telemetry (
    id                BIGSERIAL PRIMARY KEY,
    organization_id   BIGINT REFERENCES identity.mst_organization(id),
    user_id           BIGINT NOT NULL,
    module_id         INT NOT NULL,
    action_id         INT NOT NULL,
    duration_ms       NUMERIC(18, 4) NOT NULL, -- Tiempo en milisegundos
    is_success        BOOLEAN NOT NULL,
    exception_type    TEXT NULL,               -- Mensaje de error si fall�
    execution_context VARCHAR(50) NOT NULL,    -- 'Main' o 'Worker'
    parent_id         BIGINT NULL,             -- ID de la m�trica padre
    created_at        TIMESTAMPTZ DEFAULT NOW(),

    -- Relaci�n recursiva
    CONSTRAINT fk_telemetry_parent 
        FOREIGN KEY (parent_id) REFERENCES security.log_telemetry(id)
);

-- -----------------------------------------------------------------------------
-- 10. PROFESSIONAL & CLINICAL EXPANSION (Final Layer)
-- -----------------------------------------------------------------------------

-- Informaci�n Profesional del M�dico
-- Esencial para Recetas y Reclamos a Seguradoras
CREATE TABLE identity.mst_doctor_info (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT UNIQUE NOT NULL REFERENCES identity.mst_user(id),
    professional_license VARCHAR(50) NOT NULL, -- C�dula Profesional
    specialty_id INT REFERENCES common.mst_catalog_detail(id),
    digital_signature_url VARCHAR(500), -- Para firmar recetas/resultados
    is_active BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Alergias Estructuradas
-- Diferenciamos alergias de antecedentes por su criticidad cl�nica
CREATE TABLE clinical.mst_allergy (
    id BIGSERIAL PRIMARY KEY,
    patient_id BIGINT NOT NULL REFERENCES clinical.mst_patient(id),
    allergy_type_id INT REFERENCES common.mst_catalog_detail(id), -- Medicamento, Alimento, Ambiental
    substance VARCHAR(200) NOT NULL, -- Ej: Penicilina
    reaction_severity_id INT REFERENCES common.mst_catalog_detail(id), -- Leve, Moderada, Severa
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Plantillas de Laboratorio
-- Define qu� campos (JSON) debe tener cada tipo de examen
CREATE TABLE laboratory.mst_lab_template (
    id BIGSERIAL PRIMARY KEY,
    service_id BIGINT UNIQUE NOT NULL REFERENCES inventory.mst_service(id),
    schema_definition JSONB NOT NULL, -- Definici�n de rangos normales, unidades y campos
    is_active BOOLEAN DEFAULT TRUE
);

-- Consentimientos Informados y Documentos Legales
-- Crucial para evitar demandas y cumplir normativas
CREATE TABLE clinical.mst_patient_consent (
    id BIGSERIAL PRIMARY KEY,
    patient_id BIGINT NOT NULL REFERENCES clinical.mst_patient(id),
    consent_type_id INT NOT NULL, -- Quir�rgico, Tratamiento, Telemedicina
    document_url VARCHAR(500) NOT NULL, -- Link al PDF firmado
    signed_at TIMESTAMP NOT NULL,
    ip_address VARCHAR(45), -- Para firmas digitales/biom�tricas
    is_active BOOLEAN DEFAULT TRUE
);

-- -----------------------------------------------------------------------------
-- 11. FINANCIAL & MULTI-CURRENCY SUPPORT
-- -----------------------------------------------------------------------------

-- Tasas de Cambio (Para SaaS multi-pa�s)
CREATE TABLE common.mst_exchange_rate (
    id SERIAL PRIMARY KEY,
    organization_id BIGINT REFERENCES identity.mst_organization(id),
    from_currency VARCHAR(10) NOT NULL,
    to_currency VARCHAR(10) NOT NULL,
    rate NUMERIC(18, 6) NOT NULL,
    effective_date TIMESTAMP DEFAULT NOW()
);

-- -----------------------------------------------------------------------------
-- 12. �NDICES DE ALTA DISPONIBILIDAD Y CUMPLIMIENTO
-- -----------------------------------------------------------------------------
-- B�squeda r�pida de alertas cr�ticas (Alergias) al abrir expediente
CREATE INDEX idx_allergy_patient ON clinical.mst_allergy(patient_id) WHERE is_active = TRUE;
-- Verificaci�n de licencias m�dicas en el dispatcher de recetas
CREATE INDEX idx_doctor_license ON identity.mst_doctor_info(professional_license);
-- B�squeda de consentimientos por fecha para auditor�as legales
CREATE INDEX idx_consent_search ON clinical.mst_patient_consent(patient_id, signed_at DESC);
-- Optimizaci�n de Stock por sucursal
CREATE INDEX idx_stock_warehouse_service ON inventory.det_stock(warehouse_id, service_id);
-- �ndices optimizados para reportes de lentitud
CREATE INDEX idx_telemetry_perf ON security.log_telemetry(module_id, action_id, duration_ms DESC);

CREATE INDEX idx_telemetry_parent_id ON security.log_telemetry(parent_id);
-- Optimiza el login y la carga de UserContext
CREATE INDEX idx_user_organization_id ON identity.mst_user(organization_id);
-- Optimiza la b�squeda de personas por nombre (com�n en recepci�n)
CREATE INDEX idx_person_names ON identity.mst_person(last_name, first_name);
-- Optimiza la vinculaci�n de pacientes por persona
CREATE INDEX idx_patient_person_id ON clinical.mst_patient(person_id);
-- Optimiza la b�squeda de expedientes por paciente
CREATE INDEX idx_medical_record_patient_id ON clinical.mst_medical_record(patient_id);
-- Optimiza la carga de consultas por expediente
CREATE INDEX idx_consultation_medical_record_id ON care.mst_consultation(medical_record_id);
-- �ndice compuesto para historial de signos vitales (Ordenado por fecha)
CREATE INDEX idx_vital_signs_history ON clinical.mst_vital_signs(patient_id, created_at DESC);
-- Optimiza el seguimiento de �rdenes de laboratorio por estado
CREATE INDEX idx_lab_order_status ON laboratory.mst_lab_order(organization_id, status_id);
-- Optimiza reportes financieros y b�squeda de facturas por fecha
CREATE INDEX idx_invoice_org_date ON billing.mst_invoice(organization_id, created_at DESC);
-- Optimiza la carga de detalles de factura (Dapper usualmente hace Join aqu�)
CREATE INDEX idx_invoice_item_invoice_id ON billing.det_invoice_item(invoice_id);
-- Optimiza la b�squeda de logs de auditor�a por tiempo
CREATE INDEX idx_audit_created_at ON security.log_audit(created_at DESC);
-- Optimiza la telemetr�a por organizaci�n y tiempo (Dashboards de rendimiento SaaS)
CREATE INDEX idx_telemetry_org_time ON security.log_telemetry(organization_id, created_at DESC);
-- Para el Dashboard de la cl�nica (Citas del d�a)
CREATE INDEX idx_appointment_today ON care.mst_appointment(organization_id, scheduled_date, status_id);
-- Para farmacia (Stock bajo o vencido)
CREATE INDEX idx_stock_alerts ON inventory.det_stock(warehouse_id, quantity, expiration_date);
