﻿namespace MedfarLabs.Core.Domain.Enums
{
    public enum Genero
    {
        MASCULINO = 1,
        FEMENINO = 2,
        OTRO = 3,
        NO_ESPECIFICADO = 4
    }
}
