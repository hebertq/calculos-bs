﻿namespace MedfarLabs.Core.Domain.Enums
{
    public enum PlanSuscripcion
    {
        SOLO_CITAS = 1,       // Acceso restringido a agenda
        EXPEDIENTE_FULL = 2,  // Acceso a todo el historial clínico
        LABORATORIO_TOTAL = 3,// Gestión completa de LIMS e inventario
        ENTERPRISE = 4        // Multi-sede y reportes avanzados
    }
}
