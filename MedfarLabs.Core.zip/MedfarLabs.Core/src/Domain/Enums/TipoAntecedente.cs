﻿namespace MedfarLabs.Core.Domain.Enums
{
    public enum TipoAntecedente
    {
        PATOLOGICO = 1,
        NO_PATOLOGICO = 2,
        QUIRURGICO = 3,
        HEREDITARIO = 4,
        GINECO_OBSTETRICO = 5
    }
}
