﻿namespace MedfarLabs.Core.Domain.Enums
{
    public enum CatalogType
    {
        Gender = 1,
        Country = 2,
        AppointmentStatus = 3,
        MedicalSpecialties = 4,
        ServiceCategory = 5,
        AllergyType = 6,
        AllergySeverity = 7,
        BloodType = 8,
        IdentificationType = 9,
        DiagnosisType = 10,
        MedicationRoute = 11,
        LabOrderStatus = 12,
        PaymentMethod = 13,
        UnitOfMeasure = 14,
        FacilityRoomType = 15,    // Coincide con SQL 002:99
        StockMovementType = 16,   // Coincide con SQL 002:100
        MaritalStatus = 17,       // Coincide con SQL 002:101
        InvoiceStatus = 18,       // Coincide con SQL 002:102
        PathologyCategory = 19,   // Coincide con SQL 002:103
        ConsentType = 20,
        MedicalRecordStatus = 21,
        AntecedentType = 22,
        PaymentStatus = 23
    }
}
