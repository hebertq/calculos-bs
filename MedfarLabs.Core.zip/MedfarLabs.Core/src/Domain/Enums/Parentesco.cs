﻿namespace MedfarLabs.Core.Domain.Enums
{
    public enum Parentesco
    {
        PADRE = 1,
        MADRE = 2,
        HIJO_A = 3,
        ESPOSO_A = 4,
        HERMANO_A = 5,
        TUTOR_LEGAL = 6,
        OTRO = 7
    }
}
