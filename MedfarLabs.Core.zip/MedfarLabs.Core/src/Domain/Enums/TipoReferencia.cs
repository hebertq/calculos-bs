﻿namespace MedfarLabs.Core.Domain.Enums
{
    public enum TipoReferencia
    {
        MEDICO_SINDICADO = 1,      // Médico interno de la red
        MEDICO_EXTERNO = 2,        // Orden de papel de médico ajeno
        CLINICA_HOSPITAL = 3,      // Referencia institucional
        PARTICULAR = 4,            // Paciente llega por iniciativa propia
        CONVENIO_EMPRESA = 5       // Medicina del trabajo
    }
}
