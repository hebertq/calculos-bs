﻿namespace MedfarLabs.Core.Domain.Enums
{
    public enum EstatusOrden
    {
        SOLICITADO = 1,            // El médico creó la orden
        EN_PROCESO = 2,            // El laboratorio recibió la muestra
        PARA_REVISION_MEDICA = 3,  // Resultados listos en el sistema
        FINALIZADO = 4,            // El médico revisó y cerró el caso
        CANCELADO = 5
    }
}
