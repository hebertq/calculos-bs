﻿namespace MedfarLabs.Core.Domain.Enums
{
    public enum TipoOrganizacion
    {
        CLINICA = 1,
        LABORATORIO = 2,
        MEDICO_INDEPENDIENTE = 3
    }
}
