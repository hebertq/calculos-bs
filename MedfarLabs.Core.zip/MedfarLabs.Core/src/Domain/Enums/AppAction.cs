﻿
namespace MedfarLabs.Core.Domain.Enums
{
    public enum AppAction : int
    {
        // --- SECURITY (1000 - 1999) ---
        CrearRolGlobal = 1001,
        AsignarAccionesARol = 1002,
        CrearGrupoDeRoles = 1003,
        AsignarUsuarioAGrupo = 1004,
        ConsultarPermisosUsuario = 1005,
        RegistrarUsuario = 1006,

        // --- IDENTITY (2000 - 2999) ---
        RegistrarPersona = 2001,
        ConsultarPersona = 2002,
        ActualizarBiometria = 2003,
        BajaDePersona = 2004,
        RegistrarOrganizacion = 2005,

        // --- BILLING (3000 - 3999) ---
        GenerarFactura = 3001,
        AnularFactura = 3002,
        ConsultarSaldos = 3003,
        ConfigurarPlanSaaS = 3004,
        SearchInvoice  = 3005,
        RegistrarPago = 3006,

        // --- CLINICAL (4000 - 4999) ---
        AbrirHistoriaClinica = 4001,
        RegistrarAtencionMedica = 4002,
        AgendarCita = 4003,
        CargarResultadoLaboratorio = 4004,
        RegistrarPaciente = 4005,
        RegistrarSignos = 4006,
        RegistrarExpediente = 4007,

        // --- CARE (5000 - 5999) ---
        RegistrarConsulta = 5000,

        // --- COMMON (6000 - 6999) ---
        ConsultarPaises = 6001,
        ConsultarGeneros = 6002,
        ConsultarCatalogosMaestros = 6003,

        // --- INVENTARY (7000 - 7999) ---
        RegistrarServicio = 7000,

        // --- LABORATORY (8000 - 899) ----
        RegistrarResultado = 8000,
        RegistrarOrden = 8001,
    }
}
