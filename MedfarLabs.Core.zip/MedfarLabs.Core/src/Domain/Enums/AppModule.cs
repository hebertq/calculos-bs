﻿namespace MedfarLabs.Core.Domain.Enums
{
    public enum AppModule : int
    {
        /// <summary>
        /// Módulo dedicado a la seguridad de la aplicación, incluyendo autenticación, autorización, y gestión de roles y permisos.
        /// </summary>
        Security = 1,
        /// <summary>
        /// Módulo dedicado a la gestión de la identidad de los usuarios, incluyendo perfiles, credenciales, y datos personales.
        /// </summary>
        Identity = 2,
        /// <summary>
        /// Módulo dedicado a la facturación y gestión financiera, incluyendo facturas, pagos, y reportes financieros.
        /// </summary>
        Billing = 3,
        /// <summary>
        /// Módulo dedicado a la gestión clínica, incluyendo citas, historiales médicos, y procedimientos clínicos.
        /// </summary>
        Clinical = 4,   
        /// <summary>
        /// Módulo dedicado a la gestión de la atención médica, incluyendo registros de pacientes, tratamientos, y seguimiento clínico.
        /// </summary>
        Care = 5,
        /// <summary>
        /// Módulo dedicado a funcionalidades comunes y transversales que son utilizadas por múltiples módulos dentro de la aplicación.
        /// </summary>
        Common = 6,
        /// <summary>
        /// Módulo dedicado a la gestión de inventarios, incluyendo control de stock, órdenes de compra, y suministros médicos.
        /// </summary>
        Inventory = 7,
        /// <summary>
        /// Módulo dedicado a la gestión de laboratorios, incluyendo órdenes de laboratorio, resultados de pruebas, y reportes asociados.
        /// </summary>
        Laboratory = 8,
    }
}
