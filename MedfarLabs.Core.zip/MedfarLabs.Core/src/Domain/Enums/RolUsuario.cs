﻿namespace MedfarLabs.Core.Domain.Enums
{
    public enum RolUsuario
    {
        ADMIN_ORG = 1,    // Dueño de clínica o laboratorio
        MEDICO = 2,       // Personal médico con acceso a expediente
        SECRETARIA = 3,   // Acceso a agenda y citas únicamente
        TECNICO_LAB = 4,  // Solo gestión de muestras y resultados
        CONTADOR = 5      // Solo acceso a reportes financieros y facturación
    }
}
