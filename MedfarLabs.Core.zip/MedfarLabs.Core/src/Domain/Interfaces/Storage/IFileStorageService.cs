﻿namespace MedfarLabs.Core.Domain.Interfaces.Storage
{
    public interface IFileStorageService
    {
        /// <summary>
        /// Sube un archivo al almacenamiento y retorna la URL pública o la llave del objeto.
        /// </summary>
        Task<string> UploadFileAsync(Stream fileStream, string fileName, string contentType);

        /// <summary>
        /// Genera una URL temporal (Pre-signed) para acceso seguro y limitado.
        /// </summary>
        string GetPresignedUrl(string fileKey, int expiresInMinutes = 60);
    }
}
