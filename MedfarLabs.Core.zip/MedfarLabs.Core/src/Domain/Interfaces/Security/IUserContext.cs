﻿namespace MedfarLabs.Core.Domain.Interfaces.Security
{
    public interface IUserContext
    {
        // Identidad del usuario y su organización
        long UserId { get; set; }
        long OrganizationId { get; set; }

        /// <summary>
        /// Verifica si el usuario actual tiene permiso para una acción específica.
        /// Utiliza el caché global precargado en la Lambda.
        /// </summary>
        Task<bool> HasPermissionAsync(int actionId);
    }
}
