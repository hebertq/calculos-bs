﻿using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Domain.Interfaces.Security
{
    public interface IGlobalSecurityCache
    {
        // Método vital para cargar los datos en el Cold Start o SetUp de Tests
        Task InitializeAsync(ISecurityRepository repository);
        bool RoleHasPermission(int roleId, int actionId);
        HashSet<int> GetPermissionsForRoles(IEnumerable<int> roleIds);
    }
}
