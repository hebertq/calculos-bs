﻿namespace MedfarLabs.Core.Domain.Interfaces.Security
{
    public interface IHashService
    {
        // Genera un SHA-256 con un Salt fijo para que el mismo DNI 
        // siempre genere el mismo Hash y podamos buscarlo.
        byte[] GenerateHash(string input);
    }
}
