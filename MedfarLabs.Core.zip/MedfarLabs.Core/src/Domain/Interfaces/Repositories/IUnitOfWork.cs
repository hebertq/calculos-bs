﻿using MedfarLabs.Core.Domain.Interfaces.Repositories.Billing;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Care;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Clinical;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Identity;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Inventory;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Laboratory;
using MedfarLabs.Core.Domain.Interfaces.Repositories.Security;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories
{
    public interface IUnitOfWork : IDisposable
    {
        // Exponemos las interfaces específicas para tener acceso a métodos personalizados
        IPersonRepository Persons { get; }
        IOrganizationRepository Organizations { get; }
        IPatientRepository Patients { get; }
        IVitalSignsRepository VitalSigns { get; }
        IConsultationRepository Consultations { get; }
        IServiceRepository Services { get; }
        ILabResultRepository LabResults { get; }
        ILabOrderRepository LabOrders { get; }
        IInvoiceRepository Invoices { get; }
        IInvoiceItemRepository InvoiceItems { get; }
        IMedicalRecordRepository MedicalRecords { get; }
        IUserRepository Users { get; }
        IPaymentRepository Payments { get; }
        IActionPermissionRepository Actions { get; }
        IRoleRepository Roles { get; }
        IRoleGroupRepository RoleGroups { get; }
        ISecurityRepository Security { get; }

        // Gestión de Transaccionalidad Atómica
        Task SaveChangesAsync();
        Task BeginTransactionAsync();
        Task CommitAsync();
        Task RollbackAsync();
    }
}
