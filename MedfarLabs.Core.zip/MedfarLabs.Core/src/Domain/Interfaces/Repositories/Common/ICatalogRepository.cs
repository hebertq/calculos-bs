﻿using MedfarLabs.Core.Domain.Entities.Common;
using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Common
{
    public interface ICatalogRepository
    {
        Task<IEnumerable<CatalogDetail>> GetByCatalogAsync(CatalogType catalog);
        Task<CatalogDetail?> GetByCodeAsync(CatalogType catalog, string code);
        Task<T?> GetMetadataAsync<T>(CatalogType catalog, string code) where T : class;
        Task<IEnumerable<CatalogDetail>> GetActiveItemsAsync();
    }
}
