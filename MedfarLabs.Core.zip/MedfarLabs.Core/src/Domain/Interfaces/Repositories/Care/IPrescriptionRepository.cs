﻿using MedfarLabs.Core.Domain.Entities.Care;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Care
{
    public interface IPrescriptionRepository : IBaseRepository<Prescription>
    {
        Task<long> AddItemAsync(PrescriptionItem item);
        Task<IEnumerable<PrescriptionItem>> GetItemsByPrescriptionIdAsync(long prescriptionId);
    }
}
