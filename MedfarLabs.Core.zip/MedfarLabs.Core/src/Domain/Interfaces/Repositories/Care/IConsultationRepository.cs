﻿using MedfarLabs.Core.Domain.Entities.Care;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Care
{
    public interface IConsultationRepository : IBaseRepository<Consultation> { }
}
