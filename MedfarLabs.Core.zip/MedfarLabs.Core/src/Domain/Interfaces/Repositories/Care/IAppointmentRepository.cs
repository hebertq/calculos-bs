﻿using MedfarLabs.Core.Domain.Entities.Care;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Care
{
    public interface IAppointmentRepository : IBaseRepository<Appointment>
    {
        Task<IEnumerable<Appointment>> GetByBranchAndDateAsync(long branchId, DateTime date);
    }
}
