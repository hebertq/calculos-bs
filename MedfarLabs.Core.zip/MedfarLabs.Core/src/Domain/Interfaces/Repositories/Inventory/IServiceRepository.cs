﻿using MedfarLabs.Core.Domain.Entities.Inventory;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Inventory
{
    public interface IServiceRepository : IBaseRepository<MedicalService>
    {
        Task<IEnumerable<MedicalService>> GetByOrganizationAsync(long orgId);
    }
}
