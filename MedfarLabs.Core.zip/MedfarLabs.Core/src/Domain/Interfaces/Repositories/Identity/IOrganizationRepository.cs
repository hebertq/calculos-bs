﻿using MedfarLabs.Core.Domain.Entities.Identity;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Identity
{
    public interface IOrganizationRepository : IBaseRepository<Organization> { }
}
