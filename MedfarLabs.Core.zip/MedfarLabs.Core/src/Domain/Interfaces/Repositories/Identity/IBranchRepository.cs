﻿using MedfarLabs.Core.Domain.Entities.Identity;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Identity
{
    public interface IBranchRepository : IBaseRepository<Branch>
    {
        Task<IEnumerable<Branch>> GetByOrganizationAsync(long organizationId);
    }
}
