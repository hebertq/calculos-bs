﻿using MedfarLabs.Core.Domain.Entities.Identity;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Identity
{
    public interface IUserRepository : IBaseRepository<User>
    {
        Task<User?> GetByUsernameAsync(string username);
    }
}
