﻿using MedfarLabs.Core.Domain.Entities.Identity;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Identity
{
    public interface IFacilityRoomRepository : IBaseRepository<FacilityRoom> { }
}
