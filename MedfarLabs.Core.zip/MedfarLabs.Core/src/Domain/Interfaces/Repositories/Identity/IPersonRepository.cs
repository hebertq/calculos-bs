﻿using MedfarLabs.Core.Domain.Entities.Identity;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Identity
{
    // Repositorio de Personas (Núcleo Biológico)
    public interface IPersonRepository : IBaseRepository<Person>
    {
        Task<Person?> GetByBiometricHashAsync(byte[] hash);
        Task<bool> ExistsByEmailAsync(string email);
    }
}
