﻿using MedfarLabs.Core.Domain.Entities.Billing;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Billing
{
    public interface IInvoiceItemRepository : IBaseRepository<InvoiceItem>{ }
}
