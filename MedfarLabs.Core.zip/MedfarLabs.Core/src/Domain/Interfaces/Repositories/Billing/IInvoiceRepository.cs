﻿using MedfarLabs.Core.Domain.Entities.Billing;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Billing
{
    public interface IInvoiceRepository : IBaseRepository<Invoice>
    {
        Task<Invoice> GetByNumberAsync(string invoiceNumber, long orgId);
    }
}
