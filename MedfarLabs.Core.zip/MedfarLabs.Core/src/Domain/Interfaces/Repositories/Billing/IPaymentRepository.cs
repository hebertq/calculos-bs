﻿using MedfarLabs.Core.Domain.Entities.Billing;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Billing
{
    public interface IPaymentRepository : IBaseRepository<Payment> 
    {
        Task<IEnumerable<Payment>> GetByInvoiceIdAsync(long invoiceId, long organizationId);
    }
}
