﻿using System;
using MedfarLabs.Core.Domain.Entities.Clinical;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Clinical
{
    public interface IPatientRepository : IBaseRepository<Patient> { }
}
