﻿using MedfarLabs.Core.Domain.Entities.Clinical;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Clinical
{
    public interface IVitalSignsRepository : IBaseRepository<VitalSigns>
    {
        Task<IEnumerable<VitalSigns>> GetHistoryByPatientAsync(long patientId, int limit = 10);
    }
}
