﻿using MedfarLabs.Core.Domain.Entities.Clinical;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Clinical
{
    public interface IMedicalRecordRepository : IBaseRepository<MedicalRecord>
    {
        Task<MedicalRecord?> GetByPatientIdAsync(long patientId);
    }
}
