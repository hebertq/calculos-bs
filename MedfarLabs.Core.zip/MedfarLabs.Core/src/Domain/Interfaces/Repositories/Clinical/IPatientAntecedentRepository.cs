﻿using MedfarLabs.Core.Domain.Entities.Clinical;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Clinical
{
    public interface IPatientAntecedentRepository : IBaseRepository<PatientAntecedent> { }
}
