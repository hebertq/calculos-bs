﻿using MedfarLabs.Core.Domain.Entities.Laboratory;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Laboratory
{
    public interface ILabResultRepository : IBaseRepository<LabResult> { }
}
