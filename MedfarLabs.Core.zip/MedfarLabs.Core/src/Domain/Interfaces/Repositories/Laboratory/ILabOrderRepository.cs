﻿using MedfarLabs.Core.Domain.Entities.Laboratory;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Laboratory
{
    public interface ILabOrderRepository : IBaseRepository<LabOrder>
    {
        Task<IEnumerable<LabOrder>> GetByPatientIdAsync(long patientId);
    }
}
