﻿namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Security
{
    // El DTO requiere saber a qué clínica/empresa pertenece
    public interface IHasOrganization
    {
        long OrganizationId { get; set; }
    }
}
