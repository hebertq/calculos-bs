﻿using MedfarLabs.Core.Domain.Entities.Security;
using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Security
{
    public interface IActionPermissionRepository : IBaseRepository<ActionPermission>
    {
        Task<IEnumerable<ActionPermission>> GetByModuleAsync(AppModule moduleId);
    }
}
