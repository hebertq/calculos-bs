﻿using MedfarLabs.Core.Domain.Entities.Security;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Security
{
    public interface IRoleGroupRepository : IBaseRepository<RoleGroup>
    {
        Task<IEnumerable<RoleGroup>> GetByOrganizationAsync(long organizationId);
    }
}
