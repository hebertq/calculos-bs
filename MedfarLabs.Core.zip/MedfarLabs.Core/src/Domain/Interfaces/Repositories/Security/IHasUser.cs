﻿namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Security
{
    // El DTO requiere saber qué usuario está ejecutando la acción (para auditoría)
    public interface IHasUser
    {
        long UserId { get; set; }
    }
}
