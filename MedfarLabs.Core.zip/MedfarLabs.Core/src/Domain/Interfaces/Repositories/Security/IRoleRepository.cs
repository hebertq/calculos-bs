﻿using MedfarLabs.Core.Domain.Entities.Security;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Security
{
    public interface IRoleRepository : IBaseRepository<Role>
    {
        Task<IEnumerable<Role>> GetActiveRolesAsync();
    }
}
