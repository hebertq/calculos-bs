﻿using MedfarLabs.Core.Domain.Entities.Security;

namespace MedfarLabs.Core.Domain.Interfaces.Repositories.Security
{
    public interface ISecurityRepository
    {
        Task<IEnumerable<int>> GetUserPermissionIdsAsync(long userId, long organizationId);
        Task AssignRolesToGroupAsync(long roleGroupId, IEnumerable<int> roleIds);
        Task<IEnumerable<RoleActionMap>> GetAllRoleActionMappingsAsync();

        /// <summary>
        /// Obtiene los IDs de los Roles Globales que el usuario tiene asignados 
        /// a través de sus Grupos de Roles en una organización específica.
        /// </summary>
        Task<IEnumerable<int>> GetUserRoleIdsAsync(long userId, long organizationId);
        Task AssignUserToGroupAsync(long userId, long roleGroupId);
        Task<long> RegisterAuditAsync(long orgId,long userId,int moduleId,int actionId,string jsonInput,
             bool success,string context = "Main",long? parentId = null);
        Task<long> RegisterTelemetryAsync(long orgId, long userId, int moduleId, int actionId,
        double durationMs, bool success, string? exceptionType, string context, long? parentId = null);
    }
}
