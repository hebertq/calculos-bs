﻿namespace MedfarLabs.Core.Domain.Interfaces.Http
{
    public interface ITokenService
    {
        // Obtiene el token según el nombre del servicio configurado
        Task<string> GetTokenAsync(string serviceName);
        Task<string> GetNewTokenAsync(string serviceName);
    }
}
