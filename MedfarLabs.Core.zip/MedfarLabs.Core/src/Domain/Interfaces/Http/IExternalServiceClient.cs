﻿using MedfarLabs.Core.Domain.Common.Responses.Generic;

namespace MedfarLabs.Core.Domain.Interfaces.Http
{
    /// <summary>
    /// Contrato genérico para el consumo de servicios web externos, 
    /// lambdas o APIs internas con resiliencia y autenticación integrada.
    /// </summary>
    public interface IExternalServiceClient
    {
        /// <summary>
        /// Realiza una petición HTTP GET de forma asíncrona.
        /// </summary>
        /// <typeparam name="TResponse">Tipo de dato esperado en la respuesta.</typeparam>
        /// <param name="endpoint">Ruta relativa del recurso.</param>
        Task<BaseResponse<TResponse>> GetAsync<TResponse>(string endpoint);

        /// <summary>
        /// Realiza una petición HTTP POST de forma asíncrona.
        /// </summary>
        /// <typeparam name="TRequest"></typeparam>
        /// <typeparam name="TResponse"></typeparam>
        /// <param name="endpoint"></param>
        /// <param name="data"></param>
        /// <param name="serviceName"></param>
        /// <returns></returns>
        Task<BaseResponse<TResponse>> PostAsync<TRequest, TResponse>(
        string endpoint,
        TRequest data,
        string? serviceName = null);

        /// <summary>
        /// Orquestador para disparar procesos en la nube (Lambdas, Step Functions, etc.)
        /// </summary>
        /// <param name="processName">Nombre del proceso o función.</param>
        /// <param name="payload">Datos necesarios para el proceso.</param>
        Task<BaseResponse<bool>> TriggerCloudProcessAsync(string processName, object payload);
    }
}
