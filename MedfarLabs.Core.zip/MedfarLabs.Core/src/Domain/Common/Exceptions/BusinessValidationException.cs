﻿using MedfarLabs.Core.Domain.Common.Responses.Generic;

namespace MedfarLabs.Core.Domain.Common.Exceptions
{
    // 1. Clase base para que el Middleware la reconozca sin importar el tipo <T>
    // Clase base no genérica para que el Dispatcher pueda capturarla
    public class BusinessValidationException : Exception
    {
        public List<string>? Errors { get; }

        public BusinessValidationException(string message, List<string>? errors = null)
            : base(message)
        {
            Errors = errors;
        }
    }

    // Tu clase genérica actual debe heredar de la anterior
    public class BusinessValidationException<T> : BusinessValidationException
    {
        public BaseResponse<T> Response { get; }

        public BusinessValidationException(BaseResponse<T> response)
            : base(response.Message ?? "Errores de validación", response.Errors)
        {
            Response = response;
        }
    }
}
