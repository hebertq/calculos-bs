﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Text.Json;
using System.Text.Json.Serialization;
using MedfarLabs.Core.Domain.Common.Responses.Generic;

namespace MedfarLabs.Core.Domain.Common.Exceptions
{
    public class ExceptionHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionHandlingMiddleware> _logger;

        public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (BusinessValidationException ex)
            {
                // Errores controlados de reglas de negocio (400)
                await HandleExceptionAsync(context, ex, HttpStatusCode.BadRequest, "Validación de Negocio");
            }
            catch (UnauthorizedAccessException ex)
            {
                // Errores de permisos (401)
                await HandleExceptionAsync(context, ex, HttpStatusCode.Unauthorized, "No autorizado");
            }
            catch (KeyNotFoundException ex)
            {
                // Cuando no se encuentra un registro (404)
                await HandleExceptionAsync(context, ex, HttpStatusCode.NotFound, "Recurso no encontrado");
            }
            catch (Exception ex)
            {
                // Error catastrófico no controlado (500)
                _logger.LogCritical(ex, "ERROR FATAL: {Message}", ex.Message);
                await HandleExceptionAsync(context, ex, HttpStatusCode.InternalServerError, "Error Interno del Servidor");
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception exception, HttpStatusCode code, string title)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)code;

            object? responsePayload = null; // Changed to nullable object to fix CS8600

            // Si es nuestra excepción de validación, extraemos su BaseResponse original
            if (exception is BusinessValidationException businessEx)
            {
                //responsePayload = businessEx.GetResponse();
            }
            else
            {
                // Para cualquier otra excepción, construimos un BaseResponse de falla al vuelo
                responsePayload = BaseResponse<object>.Failure(
                    message: $"{title}: {exception.Message}",
                    errors: new List<string> { exception.StackTrace?.Split('\n').FirstOrDefault()?.Trim() ?? "Sin detalles adicionales" }
                );
            }

            var options = new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
            };

            return context.Response.WriteAsync(JsonSerializer.Serialize(responsePayload, options));
        }
    }
}
