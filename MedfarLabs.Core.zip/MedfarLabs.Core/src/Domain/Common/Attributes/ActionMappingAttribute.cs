﻿using MedfarLabs.Core.Domain.Enums;

namespace MedfarLabs.Core.Domain.Common.Attributes
{
    [AttributeUsage(AttributeTargets.Class)]
    public class ActionMappingAttribute : Attribute
    {
        public AppModule Module { get; }
        public int Action { get; }

        public ActionMappingAttribute(AppModule module, int action)
        {
            Module = module;
            Action = action;
        }
    }
}
