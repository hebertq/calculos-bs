﻿namespace MedfarLabs.Core.Domain.Common.Responses.Generic
{
    public class BaseResponse<T>
    {
        public bool IsSuccess { get; set; }
        public string? Message { get; set; }
        public T? Data { get; set; }
        public List<string>? Errors { get; set; }

        public static BaseResponse<T> Success(T? data, string message = "Proceso Exitoso")
            => new() { IsSuccess = true, Data = data, Message = message };

        public static BaseResponse<T> Failure(string message = "Hubo un error", List<string>? errors = null)
            => new() { IsSuccess = false, Errors = errors, Message = message };
    }
}
