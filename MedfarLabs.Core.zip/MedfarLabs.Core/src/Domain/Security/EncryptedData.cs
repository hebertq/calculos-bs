﻿namespace MedfarLabs.Core.Domain.Security
{
    public class EncryptedData
    {
        public string? Value { get; set; }

        public EncryptedData(string? value) => Value = value;

        // Conversión implícita para facilitar el uso: 
        // EncryptedData data = "Hola";
        public static implicit operator EncryptedData(string? value) => new(value);
        public static implicit operator string?(EncryptedData? data) => data?.Value;
    }
}
