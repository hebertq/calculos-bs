﻿using Microsoft.Extensions.Logging;

namespace MedfarLabs.Core.Domain.Extensions
{
    public static class LoggerExtensions
    {
        /// <summary>
        /// Extension para logger de información
        ///   
        /// EJEMPLO DE USO
        /// 
        /// _logger.LogInfoExt(
        ///        "Kyc log creado desde ReceiveJumioWebhookCommandHandler",
        ///      ("kyc", kycLog),
        ///        ("userId", userId),
        ///        ("fecha", DateTime.Now));    
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="message"></param>
        /// <param name="data"></param>
        public static void LogInfoExt(this ILogger logger, string message, params (string key, object? value)[] data)
        {
            string tracemessage = BuildMessage(message, data);
            logger.LogInformation("{Message}", tracemessage);
        }

        /// <summary>
        /// Extensión para logger de errores controlados
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="message"></param>
        /// <param name="data"></param>
        public static void LogErrorExt(this ILogger logger, string message, params (string key, object? value)[] data)
        {
            string tracemessage = BuildMessage(message, data!);
            logger.LogError("{Message}", tracemessage);
        }

        /// <summary>
        /// Extensión para logger de fallos con exceptions
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="ex"></param>
        /// <param name="message"></param>
        /// <param name="data"></param>
        public static void LogFailExt(this ILogger logger, Exception ex, string message, params (string key, object? value)[] data)
        {
            string tracemessage = BuildMessage(message, data!);
            logger.LogError(ex, "{Message}", tracemessage);
        }

        public static void LogWarlExt(this ILogger logger, Exception ex, string message, params (string key, object? value)[] data)
        {
            string tracemessage = BuildMessage(message, data!);
            logger.LogWarning(ex, "{Message}", tracemessage);
        }

        private static string BuildMessage(string message, (string key, object? value)[] data)
        {
            if (data == null || data.Length == 0)
                return message;

            var dict = new Dictionary<string, object>();
            foreach (var (key, value) in data)
            {
                dict[key] = value ?? "null";
            }

            string json = dict.SerializeWithCamelCase();
            return $"{message} | Datos: {json}";
        }
    }
}
