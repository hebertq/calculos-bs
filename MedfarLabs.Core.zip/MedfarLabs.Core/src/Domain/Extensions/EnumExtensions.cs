﻿namespace MedfarLabs.Core.Domain.Extensions
{
    public static class EnumExtensions
    {
        /// <summary>
        /// Parses a string value into its enum value by variable name
        /// </summary>
        /// <typeparam name="T">enum Type</typeparam>
        /// <param name="value">this string value</param>
        /// <param name="enumResult">The parsed enum value as an object</param>
        /// <returns>The parsed enum value, default if not found</returns>
        public static T ParseEnum<T>(this string value, out object enumResult) where T : struct, Enum
        {
            if (Enum.TryParse<T>(value, true, out var result))
            {
                enumResult = result;
                return result;
            }

            enumResult = default(T);
            return default(T);
        }
    }
}
