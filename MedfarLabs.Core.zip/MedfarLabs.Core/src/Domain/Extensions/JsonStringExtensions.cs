﻿using System.Text.Json;

namespace MedfarLabs.Core.Domain.Extensions
{
    public static class JsonStringExtensions
    {
        /// <summary>
        /// Parsea una cadena JSON y extrae el valor de 'provider_url'.
        /// </summary>
        /// <param name="json">La cadena JSON a procesar.</param>
        /// <returns>El string de la URL o string.Empty si no se encuentra.</returns>
        public static string ExtractData(this string json,string find)
        {
            if (string.IsNullOrWhiteSpace(json)) return string.Empty;

            try
            {
                // Usamos JsonDocument para un acceso rápido y eficiente en memoria
                using var doc = JsonDocument.Parse(json);
                JsonElement root = doc.RootElement;

                // Intentamos obtener la propiedad específica solicitada
                if (root.TryGetProperty(find, out JsonElement providerUrlElement))
                {
                    return providerUrlElement.GetString() ?? string.Empty;
                }
            }
            catch (JsonException)
            {
                // En caso de que el string no sea un JSON válido
                return string.Empty;
            }

            return string.Empty;
        }

        /// <summary>
        /// Versión genérica para obtener cualquier propiedad string de un JSON.
        /// </summary>
        public static string GetJsonValue(this string json, string propertyName)
        {
            if (string.IsNullOrWhiteSpace(json)) return string.Empty;

            try
            {
                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.TryGetProperty(propertyName, out JsonElement element))
                {
                    return element.GetString() ?? string.Empty;
                }
            }
            catch { }

            return string.Empty;
        }
        /// <summary>
        ///     
        /// </summary>
        /// <param name="element"></param>
        /// <param name="propertyName"></param>
        /// <param name="expectedValue"></param>
        /// <returns></returns>
        public static IEnumerable<JsonElement> FilterByName(this JsonElement element, string propertyName, string expectedValue)
        {
            if (element.ValueKind != JsonValueKind.Array)
                return Enumerable.Empty<JsonElement>();

            return element.EnumerateArray()
                .Where(item =>
                    item.TryGetProperty(propertyName, out var prop) &&
                    prop.GetString() == expectedValue);
        }

        /// <summary>
        ///     
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source"></param>
        /// <param name="jsonSelector"></param>
        /// <param name="propertyName"></param>
        /// <param name="expectedValue"></param>
        /// <returns></returns>
        public static IEnumerable<T> WhereJsonContains<T>(
        this IEnumerable<T> source,
        Func<T, JsonElement?> jsonSelector,
        string propertyName,
        string expectedValue)
        {
            if (source == null) return Enumerable.Empty<T>();

            return source.Where(item =>
            {
                var rootElement = jsonSelector(item);

                // Cambiamos la validación: Ahora esperamos un Objeto, no un Array
                if (!rootElement.HasValue || rootElement.Value.ValueKind != JsonValueKind.Object)
                    return false;

                // Buscamos la propiedad directamente en el objeto
                if (rootElement.Value.TryGetProperty(propertyName, out JsonElement prop))
                {
                    // Optimizamos usando ValueEquals para no crear basura en el Heap (GC Friendly)
                    return prop.ValueKind == JsonValueKind.String && prop.ValueEquals(expectedValue);
                }

                return false;
            });
        }
    }
}
