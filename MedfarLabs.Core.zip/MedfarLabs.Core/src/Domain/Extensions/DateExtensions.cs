﻿using System.Globalization;

namespace MedfarLabs.Core.Domain.Extensions
{
    public static class DateExtensions
    {
        private static readonly List<String> AcceptableDateFormats = new(72);
        /// <summary>
        /// Convert datetime to UNIX time including miliseconds
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns>The datetime in unix format in milliseconds</returns>
        public static long ToUnixTimeSeconds(this DateTime dateTime)
        {
            DateTimeOffset dto = new(dateTime.ToUniversalTime());
            return dto.ToUnixTimeSeconds();
        }

        /// <summary>
        /// Convert a date time to a datetime of the specific time zone id
        /// </summary>
        /// <param name="dateTime">The datetime to convert</param>
        /// <param name="timeZoneId">The timezone id</param>
        /// <returns>The datetime converted</returns>
        public static DateTime ToTimeZoneDateTime(this DateTime dateTime, string timeZoneId)
        {
            var timeInfo = TimeZoneInfo.FindSystemTimeZoneById(timeZoneId);
            return TimeZoneInfo.ConvertTimeFromUtc(dateTime.ToUniversalTime(), timeInfo);
        }

        /// <summary>
        /// Convert a string to a DateTime object
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static DateTime? ToDateTime(this string dateTime)
        {
            IFormatProvider formatProvider = CultureInfo.InvariantCulture;
            return DateFormat(dateTime, formatProvider);
        }

        /// <summary>
        /// Convert a object to a DateTime object
        /// </summary>
        /// <param name="value"></param>
        /// <param name="formatInfo"></param>
        /// <returns></returns>
        private static DateTime? DateFormat(Object value, IFormatProvider formatInfo)
        {
            AddformatDate(["yy", "yyyy"], ["M", "MM", "MMM"], ["d", "dd"]);
            AddformatDate(["d", "dd"], ["M", "MM", "MMM"], ["yy", "yyyy"]);
            AddformatDate(["M", "MM"], ["d", "dd"], ["yy", "yyyy"]);

            String sValue = value.ToString()!.Trim();
            DateTime unused;

            foreach (String format in AcceptableDateFormats)
            {
                if (DateTime.TryParseExact(sValue, format, formatInfo, DateTimeStyles.None, out unused)) return unused;
            }

            return null;
        }

        /// <summary>
        /// Add date formats to the acceptable formats list
        /// </summary>
        /// <param name="format1"></param>
        /// <param name="format2"></param>
        /// <param name="format3"></param>
        private static void AddformatDate(string[] format1, string[] format2, string[] format3)
        {
            foreach (var dateFormat in format1)
            {
                foreach (var monthFormat in format2)
                {
                    foreach (var yearFormat in format3)
                    {
                        foreach (var separator in new[] { "-", "/", ".", "" }) // formatInfo.DateSeparator ?
                        {
                            String shortDateFormat;
                            shortDateFormat = dateFormat + separator + monthFormat + separator + yearFormat;
                            AcceptableDateFormats.Add(shortDateFormat);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Get current date time as string
        /// </summary>
        /// <returns></returns>
        public static string StrNow() => DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
    }
}
