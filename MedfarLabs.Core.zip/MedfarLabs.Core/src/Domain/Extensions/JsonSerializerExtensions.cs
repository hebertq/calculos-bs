﻿using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MedfarLabs.Core.Domain.Extensions
{
    public static class JsonSerializerExtensions
    {
        /// <summary>
        /// Opciones de serialización para camelCase.
        /// </summary>
        private static readonly JsonSerializerOptions CamelCaseOptions = new()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };

        /// <summary>
        /// Opciones de serialización para snake_case.
        /// </summary>
        private static readonly JsonSerializerOptions SnakeCaseOptions = new()
        {
            PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };

        /// <summary>
        /// Opciones de serialización para PascalCase.
        /// </summary>
        private static readonly JsonSerializerOptions PascalCaseOptions = new()
        {
            // Por defecto System.Text.Json es PascalCase si no se define Policy
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };

        #region Serialization
        /// <summary>
        /// Serializa el objeto a JSON con formato camelCase.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public static string SerializeWithCamelCase<T>(this T data) =>
            JsonSerializer.Serialize(data, CamelCaseOptions);

        /// <summary>
        /// Serializa el objeto a JSON con formato snake_case.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public static string SerializeWithSnakeCase<T>(this T data) =>
            JsonSerializer.Serialize(data, SnakeCaseOptions);

        /// <summary>
        /// Serializa el objeto a JSON con formato PascalCase.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public static string SerializeWithPascalCase<T>(this T data) =>
            JsonSerializer.Serialize(data, PascalCaseOptions);

        #endregion

        #region Deserialization
        /// <summary>
        /// Deserializa el JSON con formato camelCase al objeto correspondiente.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="json"></param>
        /// <returns></returns>
        public static T? DeserializeFromCamelCase<T>(this string json) =>
            JsonSerializer.Deserialize<T>(json, CamelCaseOptions);

        /// <summary>
        /// Deserializa el JSON con formato snake_case al objeto correspondiente.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="json"></param>
        /// <returns></returns>
        public static T? DeserializeFromSnakeCase<T>(this string json) =>
            JsonSerializer.Deserialize<T>(json, SnakeCaseOptions);

        /// <summary>
        /// Deserializa el JSON con formato PascalCase al objeto correspondiente.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="json"></param>
        /// <returns></returns>
        public static T? DeserializeFromPascalCase<T>(this string json) =>
            JsonSerializer.Deserialize<T>(json, PascalCaseOptions);

        /// <summary>
        /// Detecta automáticamente el formato y deserializa.
        /// </summary>
        // QUITAMOS: where T : new()
        // AGREGAMOS: where T : class (para asegurar que sea un objeto de referencia)
        public static T? DeserializeGeneric<T>(this string json) where T : class
        {
            if (string.IsNullOrWhiteSpace(json)) return default;

            var jsonCase = DetectJsonCase(json);

            return jsonCase switch
            {
                "snake_case" => DeserializeFromSnakeCase<T>(json),
                "camelCase" => DeserializeFromCamelCase<T>(json),
                _ => DeserializeFromPascalCase<T>(json),
            };
        }

        #endregion

        #region Utilities
        /// <summary>
        /// Detecta el formato del JSON (camelCase, snake_case, PascalCase).
        /// </summary>
        /// <param name="json"></param>
        /// <returns></returns>
        private static string DetectJsonCase(string json)
        {
            try
            {
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;

                if (root.ValueKind != JsonValueKind.Object) return "Unknown";

                // Obtenemos las llaves del JSON
                var keys = root.EnumerateObject().Select(p => p.Name).ToList();

                if (!keys.Any()) return "Unknown";

                if (keys.Any(k => k.Contains('_'))) return "snake_case";
                if (keys.Any(k => char.IsLower(k[0]))) return "camelCase";

                return "pascalCase";
            }
            catch
            {
                return "Unknown";
            }
        }

        /// <summary>
        /// Convierte un diccionario a una representación en cadena.
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="dictionary"></param>
        /// <returns></returns>
        public static string DictionaryToString<TKey, TValue>(this Dictionary<TKey, TValue>? dictionary) where TKey : notnull
        {
            if (dictionary is null || dictionary.Count == 0) return string.Empty;

            var sb = new StringBuilder();
            foreach (var pair in dictionary)
            {
                if (sb.Length > 0) sb.Append(", ");
                sb.Append($"{pair.Key}:{pair.Value}");
            }
            return sb.ToString();
        }
        #endregion
    }
}
