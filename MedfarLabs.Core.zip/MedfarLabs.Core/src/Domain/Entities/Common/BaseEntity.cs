﻿using MedfarLabs.Core.Domain.Common.Attributes;

namespace MedfarLabs.Core.Domain.Entities.Common
{
    /// <summary>
    /// Clase base que proporciona las columnas de auditoría estándar para todas las entidades.
    /// </summary>
    public abstract class BaseEntity
    {
        [DbColumn("id")]
        public long Id { get; set; }

        [DbColumn("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [DbColumn("updated_at")]
        public DateTime UpdatedAt { get; set; } = DateTime.Now;

        [DbColumn("created_by_user_id")]
        public long? CreatedByUserId { get; set; }

        [DbColumn("updated_by_user_id")]
        public long? UpdatedByUserId { get; set; }

        [DbColumn("audit_notes")]
        public string? AuditNotes { get; set; }
    }
}
