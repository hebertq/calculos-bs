﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedfarLabs.Core.Domain.Entities.Common
{
    public class CatalogDetail
    {
        public long Id { get; set; }
        public int CatalogId { get; set; }
        public string Code { get; set; } = string.Empty;
        public string? AlternativeCode { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? AdditionalData { get; set; } // JSONB como string para procesar con System.Text.Json
        public bool IsActive { get; set; }
    }
}
