﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Clinical
{
    public class MedicalRecord : BaseEntity
    {
        [DbColumn("patient_id")]
        public long PatientId { get; set; }

        [DbColumn("record_number")]
        public string RecordNumber { get; set; } = string.Empty;

        [DbColumn("status_id")]
        public int StatusId { get; set; } // 1: Activo, 2: Pasivo, 3: Bloqueado
    }
}
