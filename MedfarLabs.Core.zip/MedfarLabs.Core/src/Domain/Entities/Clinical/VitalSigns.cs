﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Clinical
{
    public class VitalSigns : BaseEntity
    {
        [DbColumn("patient_id")]
        public long PatientId { get; set; }

        [DbColumn("consultation_id")]
        public long? ConsultationId { get; set; }

        [DbColumn("systolic_pressure")]
        public decimal? SystolicPressure { get; set; }

        [DbColumn("diastolic_pressure")]
        public decimal? DiastolicPressure { get; set; }

        [DbColumn("heart_rate")]
        public int? HeartRate { get; set; }

        [DbColumn("temperature")]
        public decimal? Temperature { get; set; }

        [DbColumn("weight_kg")]
        public decimal? WeightKg { get; set; }

        [DbColumn("body_mass_index")]
        public decimal? BodyMassIndex { get; set; }

        [DbColumn("height_cm")]
        public decimal? HeightCm { get; set; }
    }
}
