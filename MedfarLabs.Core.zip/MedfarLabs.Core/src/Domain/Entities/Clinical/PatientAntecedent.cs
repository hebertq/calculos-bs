﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Clinical
{
    public class PatientAntecedent : BaseEntity
    {
        [DbColumn("patient_id")]
        public long PatientId { get; set; } // Referencia al paciente

        [DbColumn("type_id")]
        public long TypeId { get; set; } // 1: Patológico, 2: Alergia, etc.

        [DbColumn("description")]
        public string Description { get; set; } = string.Empty;

        [DbColumn("is_active")]
        public bool IsActive { get; set; } = true;
    }
}
