﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Clinical
{
    public class Patient : BaseEntity
    {
        [DbColumn("person_id")] public long PersonId { get; set; }
        [DbColumn("organization_id")] public long OrganizationId { get; set; }
        [DbColumn("internal_code")] public string? InternalCode { get; set; }
        [DbColumn("is_active")] public bool IsActive { get; set; }
    }
}
