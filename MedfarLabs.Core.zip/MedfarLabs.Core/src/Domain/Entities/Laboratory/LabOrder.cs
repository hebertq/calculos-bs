﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Laboratory
{
    public class LabOrder : BaseEntity
    {
        [DbColumn("consultation_id")]
        public long? ConsultationId { get; set; }

        [DbColumn("patient_id")]
        public long PatientId { get; set; }

        [DbColumn("service_id")]
        public long ServiceId { get; set; } // Referencia al examen en inventory.mst_service

        [DbColumn("status_id")]
        public int StatusId { get; set; } // 1: Pendiente, 2: Procesada, 3: Anulada
    }
}
