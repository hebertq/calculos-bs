﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;
using MedfarLabs.Core.Domain.Entities.Public;

namespace MedfarLabs.Core.Domain.Entities.Laboratory
{
    public class LabResult : BaseEntity
    {
        [DbColumn("lab_order_id")]
        public long LabOrderId { get; set; }

        [DbColumn("technical_data_json")]
        public JsonValue? TechnicalDataJson { get; set; } // Almacena campos técnicos de los 25 exámenes

        [DbColumn("attachment_url")]
        public string? AttachmentUrl { get; set; }
    }
}
