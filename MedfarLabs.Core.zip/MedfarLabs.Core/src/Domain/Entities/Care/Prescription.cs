﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Care
{
    public class Prescription : BaseEntity
    {
        [DbColumn("consultation_id")]
        public long? ConsultationId { get; set; }

        [DbColumn("patient_id")]
        public long PatientId { get; set; }

        [DbColumn("doctor_user_id")]
        public long DoctorUserId { get; set; }

        [DbColumn("notes")]
        public string? Notes { get; set; }
    }
}
