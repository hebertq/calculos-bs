﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Care
{
    public class Consultation : BaseEntity
    {
        [DbColumn("medical_record_id")]
        public long MedicalRecordId { get; set; }

        [DbColumn("doctor_user_id")]
        public long DoctorUserId { get; set; }

        [DbColumn("subjective_data")]
        public string? SubjectiveData { get; set; }

        [DbColumn("objective_data")]
        public string? ObjectiveData { get; set; }

        [DbColumn("analysis_data")]
        public string? AnalysisData { get; set; }

        [DbColumn("plan_data")]
        public string? PlanData { get; set; }
    }
}
