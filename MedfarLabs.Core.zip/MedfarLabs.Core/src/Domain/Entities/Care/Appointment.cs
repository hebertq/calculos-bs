﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Care
{
    public class Appointment : BaseEntity
    {
        [DbColumn("organization_id")]
        public long OrganizationId { get; set; }

        [DbColumn("branch_id")]
        public long BranchId { get; set; }

        [DbColumn("patient_id")]
        public long PatientId { get; set; }

        [DbColumn("doctor_user_id")]
        public long DoctorUserId { get; set; }

        [DbColumn("facility_room_id")]
        public long? FacilityRoomId { get; set; }

        [DbColumn("scheduled_date")]
        public DateTime ScheduledDate { get; set; }

        [DbColumn("start_time")]
        public TimeSpan StartTime { get; set; }

        [DbColumn("end_time")]
        public TimeSpan EndTime { get; set; }

        [DbColumn("status_id")]
        public int StatusId { get; set; }

        [DbColumn("reason_notes")]
        public string? ReasonNotes { get; set; }
    }
}
