﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Care
{
    public class PrescriptionItem : BaseEntity
    {
        [DbColumn("prescription_id")]
        public long PrescriptionId { get; set; }

        [DbColumn("medication_name")]
        public string MedicationName { get; set; } = string.Empty;

        [DbColumn("dosage")]
        public string? Dosage { get; set; }

        [DbColumn("frequency")]
        public string? Frequency { get; set; }

        [DbColumn("duration")]
        public string? Duration { get; set; }

        [DbColumn("instructions")]
        public string? Instructions { get; set; }
    }
}
