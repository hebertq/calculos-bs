﻿using MedfarLabs.Core.Domain.Common.Attributes;

namespace MedfarLabs.Core.Domain.Entities.Security
{
    public class RoleGroupRoleMap
    {
        [DbColumn("role_group_id")]
        public long RoleGroupId { get; set; }

        [DbColumn("role_id")]
        public int RoleId { get; set; }
    }
}
