﻿using MedfarLabs.Core.Domain.Common.Attributes;

namespace MedfarLabs.Core.Domain.Entities.Security
{
    public class RoleActionMap
    {
        [DbColumn("role_id")]
        public int RoleId { get; set; }

        [DbColumn("action_id")]
        public int ActionId { get; set; }
    }
}
