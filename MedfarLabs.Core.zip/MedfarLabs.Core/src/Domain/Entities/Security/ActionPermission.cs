﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Security
{
    public class ActionPermission : BaseEntity
    {
        [DbColumn("module_id")]
        public int ModuleId { get; set; }

        [DbColumn("name")]
        public string Name { get; set; } = string.Empty;
    }
}
