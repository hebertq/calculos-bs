﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Security
{
    public class Role : BaseEntity
    {
        [DbColumn("name")]
        public string Name { get; set; } = string.Empty;

        [DbColumn("description")]
        public string? Description { get; set; }

        [DbColumn("is_active")]
        public bool IsActive { get; set; }
    }
}
