﻿using System;
using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Billing
{
    public class Payment : BaseEntity
    {
        [DbColumn("organization_id")]
        public long OrganizationId { get; set; }

        [DbColumn("invoice_id")]
        public long InvoiceId { get; set; }

        [DbColumn("payment_method_id")]
        public int PaymentMethodId { get; set; }

        [DbColumn("amount")]
        public decimal Amount { get; set; }

        [DbColumn("transaction_reference")]
        public string? TransactionReference { get; set; }

        [DbColumn("payment_date")]
        public DateTime PaymentDate { get; set; } = DateTime.UtcNow;

        [DbColumn("status_id")]
        public int StatusId { get; set; } // 1: Completado, 2: Anulado, 3: Pendiente
    }
}
