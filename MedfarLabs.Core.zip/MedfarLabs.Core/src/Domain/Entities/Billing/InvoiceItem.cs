﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Billing
{
    public class InvoiceItem : BaseEntity
    {
        [DbColumn("invoice_id")]
        public long InvoiceId { get; set; }

        [DbColumn("service_id")]
        public long ServiceId { get; set; }

        [DbColumn("quantity")]
        public decimal Quantity { get; set; }

        [DbColumn("unit_price")]
        public decimal UnitPrice { get; set; }

        [DbColumn("line_total")]
        public decimal LineTotal { get; set; }
    }
}
