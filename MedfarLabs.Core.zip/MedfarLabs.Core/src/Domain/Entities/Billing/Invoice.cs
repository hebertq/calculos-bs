﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Billing
{
    public class Invoice : BaseEntity
    {
        [DbColumn("organization_id")] public long OrganizationId { get; set; }
        [DbColumn("patient_id")] public long PatientId { get; set; }
        [DbColumn("invoice_number")] public string? InvoiceNumber { get; set; }
        [DbColumn("subtotal")] public decimal Subtotal { get; set; }
        [DbColumn("tax_amount")] public decimal TaxAmount { get; set; }
        [DbColumn("total_amount")] public decimal TotalAmount { get; set; }
        [DbColumn("status_id")] public int StatusId { get; set; }
    }
}
