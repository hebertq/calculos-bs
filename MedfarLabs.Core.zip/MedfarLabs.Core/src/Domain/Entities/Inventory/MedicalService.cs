﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Inventory
{
    public class MedicalService : BaseEntity
    {
        [DbColumn("organization_id")]
        public long OrganizationId { get; set; }

        [DbColumn("category_id")]
        public int CategoryId { get; set; } // 1: Consulta, 2: Lab, etc.

        [DbColumn("name")]
        public string? Name { get; set; }

        [DbColumn("base_price")]
        public decimal BasePrice { get; set; }

        [DbColumn("sku_code")]
        public string? SkuCode { get; set; }
    }
}
