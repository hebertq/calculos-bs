﻿namespace MedfarLabs.Core.Domain.Entities.Public
{
    // 1. Definimos un tipo marcador para JSON
    public record JsonValue(string Value);
}
