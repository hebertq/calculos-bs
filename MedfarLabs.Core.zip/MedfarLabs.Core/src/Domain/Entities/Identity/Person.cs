﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Identity
{
    // Entidad: Persona (Unicidad Biográfica)
    public class Person : BaseEntity
    {
        [DbColumn("person_uuid")]
        public Guid PersonUuid { get; set; }

        [DbColumn("biometric_hash")]
        public byte[]? BiometricHash { get; set; } // Hash SHA-256 de identidad

        [DbColumn("first_name")]
        public string? FirstName { get; set; }

        [DbColumn("middle_name")]
        public string? MiddleName { get; set; }

        [DbColumn("last_name")]
        public string? LastName { get; set; }

        [DbColumn("second_last_name")]
        public string? SecondLastName { get; set; }

        [DbColumn("birth_date")]
        public DateTime BirthDate { get; set; }

        [DbColumn("gender_id")]
        public int GenderId { get; set; }

        [DbColumn("birth_country_id")]
        public int BirthCountryId { get; set; }

        [DbColumn("email")]
        public byte[]? Email { get; set; } // Encriptado AES

        [DbColumn("mobile_phone")]
        public byte[]? MobilePhone { get; set; } // Encriptado AES
    }
}
