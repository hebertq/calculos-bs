﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Identity
{
    public class Branch : BaseEntity
    {
        [DbColumn("organization_id")]
        public long OrganizationId { get; set; }

        [DbColumn("name")]
        public string Name { get; set; } = string.Empty;

        [DbColumn("address")]
        public string? Address { get; set; }

        [DbColumn("is_active")]
        public bool IsActive { get; set; }
    }
}
