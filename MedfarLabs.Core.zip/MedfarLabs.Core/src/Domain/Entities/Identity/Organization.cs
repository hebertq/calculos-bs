﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Identity
{
    public class Organization : BaseEntity
    {
        [DbColumn("organization_uuid")]
        public Guid OrganizationUuid { get; set; }

        [DbColumn("name")]
        public string? Name { get; set; }

        [DbColumn("tax_id")]
        public byte[]? TaxId { get; set; } // Encriptado

        [DbColumn("is_active")]
        public bool IsActive { get; set; }
    }
}
