﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Identity
{
    public class FacilityRoom : BaseEntity
    {
        [DbColumn("branch_id")]
        public long BranchId { get; set; } // Referencia a la sucursal

        [DbColumn("name")]
        public string Name { get; set; } = string.Empty; // Nombre del consultorio

        [DbColumn("type_id")]
        public int TypeId { get; set; } // Tipo de sala (Consultorio, Quirófano, etc.)

        [DbColumn("is_active")]
        public bool IsActive { get; set; } = true;
    }
}
