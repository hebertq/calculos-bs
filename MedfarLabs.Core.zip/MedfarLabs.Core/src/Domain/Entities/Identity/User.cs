﻿using MedfarLabs.Core.Domain.Common.Attributes;
using MedfarLabs.Core.Domain.Entities.Common;

namespace MedfarLabs.Core.Domain.Entities.Identity
{
    public class User : BaseEntity
    {
        [DbColumn("person_id")]
        public long PersonId { get; set; }

        [DbColumn("organization_id")]
        public long OrganizationId { get; set; }

        [DbColumn("username")]
        public string Username { get; set; } = string.Empty;

        [DbColumn("password_hash")]
        public byte[] PasswordHash { get; set; } = Array.Empty<byte>();

        [DbColumn("is_active")]
        public bool IsActive { get; set; } = true;
    }
}
