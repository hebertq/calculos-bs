﻿namespace MedfarLabs.Core.Domain.Const
{
    public static partial class AppAction
    {
        public static class Clinical
        {
            public const int AbrirHistoriaClinica = 4001; //
            public const int RegistrarAtencionMedica = 4002; //
            public const int AgendarCita = 4003; //
            public const int CargarResultadoLaboratorio = 4004; //
            public const int RegistrarPaciente = 4005; //
            public const int RegistrarSignosVitales = 4006; //
            public const int RegistrarExpediente = 4007; //
            public const int RegistrarAntecedente = 4108;
            public const int RegistrarAlergia = 4109;
            public const int RegistrarConsentimiento = 4110;
            public const int ConsultarCatalogoCIE10 = 4111;
            public const int RegistrarConsultaDirecta = 4112;
        }
    }
}
