﻿namespace MedfarLabs.Core.Domain.Const
{
    public static partial class AppAction
    {
        public static class Identity
        {
            public const int RegistrarPersona = 2001; //
            public const int ConsultarPersona = 2002; //
            public const int ActualizarBiometría = 2003; //
            public const int BajaPersona = 2004; //
            public const int RegistrarOrganizacion = 2005; //
            public const int RegistrarSucursal = 2106;
            public const int RegistrarConsultorio = 2107;
            public const int RegistrarInformacionMedico = 2108;
            public const int ActualizarConfiguracionOrganizacion = 2109;
            public const int RegistrarUsuario = 2110;
        }
    }
}
