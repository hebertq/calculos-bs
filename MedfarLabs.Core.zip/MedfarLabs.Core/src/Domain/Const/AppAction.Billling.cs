﻿namespace MedfarLabs.Core.Domain.Const
{
    public static partial class AppAction
    {
        public static class Billling
        {
            public const int GenerarFactura = 3001; //
            public const int AnularFactura = 3002; //
            public const int ConsultarSaldos = 3003; //
            public const int ConfigurarPlanSaaS = 3004; //
            public const int BuscarFactura = 3005; //
            public const int RegistrarPago = 3006; //                                    // 
        }
    }
}
