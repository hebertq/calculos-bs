﻿namespace MedfarLabs.Core.Domain.Const
{
    public static partial class AppAction
    {
        public static class Common
        {
            public const int ConsultarCatálogosMaestros = 6000; //
            public const int ConsultarCatálogosEspecifico = 6001; //
            public const int ConsultarCatálogosItem= 6002; //
        }
    }
}
