﻿namespace MedfarLabs.Core.Domain.Const
{
    public static partial class AppAction
    {
        public static class Laboratory
        {
            public const int RegistrarResultado = 8000; //
            public const int RegistrarOrden = 8001; //
        }
    }
}
