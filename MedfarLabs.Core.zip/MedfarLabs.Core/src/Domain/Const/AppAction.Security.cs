﻿namespace MedfarLabs.Core.Domain.Const
{
    public static partial class AppAction
    {
        public static class Security
        {
            public const int CrearRolGlobal = 1001; //
            public const int AsignarAccionesRol = 1002; //
            public const int CrearGrupoRoles = 1003; //
            public const int AsignarUsuarioGrupo = 1004; //
            public const int ConsultarPermisosUsuario = 1005; //
            public const int RegistrarUsuario = 1006; //
        }
    }
}
