﻿namespace MedfarLabs.Core.Domain.Const
{
    public static partial class AppAction
    {
        public static class Inventory
        {
            public const int RegistrarServicio = 7000; //
            public const int RegistrarBodega = 7001; //
            public const int AjustarStock = 7002; //
            public const int TrasladarInsumos = 7003; //
        }
    }
}
