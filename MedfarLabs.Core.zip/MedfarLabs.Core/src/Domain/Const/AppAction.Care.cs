﻿namespace MedfarLabs.Core.Domain.Const
{
    public static partial class AppAction
    {
        public static class Care
        {
            public const int EmitirReceta = 5000; //
            public const int RegistrarConsulta = 5001; //
            public const int GestionarCita = 5002; //
            public const int CargarResultados = 5003; //
        }
    }
}
