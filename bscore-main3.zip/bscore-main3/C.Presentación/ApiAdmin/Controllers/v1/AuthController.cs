﻿using ApiApplication.Features.Admin.Commands;
using ApiApplication.Features.Admin.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Modelo.Admin;
using Modelo.ClasesGenericas;
using Modelo.Interfaces;
using Modelo.Salida;
using Seguridad.ClasesGenericas;
using Swashbuckle.AspNetCore.Annotations;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace ApiAdmin.Controllers.v1
{
    /// <summary>
    /// Events endpoints
    /// </summary>
    [ApiVersion("1.0")]
    [ApiController]
    [Route("[controller]")]
    [Route("v{version:apiVersion}/[controller]")]
    [SwaggerResponse((int)HttpStatusCode.Accepted, Type = typeof(ResponseData), Description = "Datos validos para su procesamiento")]
    [SwaggerResponse((int)HttpStatusCode.NotFound, Type = typeof(ResponseData), Description = "Recurso no encontrado")]
    [SwaggerResponse((int)HttpStatusCode.BadRequest, Type = typeof(ResponseData), Description = "Validación fallida")]
    [SwaggerResponse((int)HttpStatusCode.InternalServerError, Type = typeof(ResponseData), Description = "Excepción de error de la aplicación")]
    public class AuthController : BaseController
    {
        private readonly IMediator _mediator;
        private readonly JWTSettings _jwtsettings;
        public AuthController(IMediator mediator, IOptions<JWTSettings> jwtsettings)
        {
            _mediator    = mediator;
            _jwtsettings = jwtsettings.Value;
        }

        /// <summary>
        /// Retrieves list of event type names
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetAllUsers")]
        public async Task<ResponseData> GetAllUsers()
        {
            var users = await _mediator.Send(new GetAllUserQuery());
            return SucessResquest(users);
        }

        /// <summary>
        /// Retrieves list of event type names
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetUserById/{user}")]
        public async Task<ResponseData> GetUserById(int @user)
        {
            var users = await _mediator.Send(new GetAllUserQuery());
            ISingleResponse<User> response = new SingleResponse<User>();
            if (users.Respuesta.ExisteError)
                response.Respuesta = users.Respuesta;
            else
            {
                response.Model = users.Model.Where(x => x.id == @user).FirstOrDefault();
            }

            return SucessResquest(response);
        }

        /// <summary>
        /// Retrieves list of event type names
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetUserByEmail/{email}")]
        public async Task<ResponseData> GetUserByEmail(string @email)
        {
            var users = await _mediator.Send(new GetAllUserQuery());
            ISingleResponse<User> response = new SingleResponse<User>();
            if (users.Respuesta.ExisteError)
                response.Respuesta = users.Respuesta;
            else
            {
                response.Model = users.Model.Where(x => x.email == @email).FirstOrDefault();
            }
            return SucessResquest(response);
        }
        // POST: api/Users
        [HttpPost("Login")]
        public async Task<ResponseData> Login([FromBody] UserLogin model)
        {
            ISingleResponse<UserWithToken> response = new SingleResponse<UserWithToken>();
            var users = await _mediator.Send(new GetAllUserQuery());

            if (users.Respuesta.ExisteError)
                response.Respuesta = users.Respuesta;
            else
            {
                var user = users.Model.Where(x => x.email == model.Email_Address && x.password == model.Password).FirstOrDefault();
                if (user != null)
                {
                    RefreshToken refreshToken = GenerateRefreshToken();
                    refreshToken.UserId       = user.id;
                    var tokenadd              = await _mediator.Send(new AddTokenUserCommand(refreshToken));

                    response.Model.SetData(user);
                    response.Model.RefreshToken = refreshToken.Token;
                    response.Model.AccessToken   = GenerateAccessToken(user.id);
                }
            }          
            
            return SucessResquest(response);
        }

        [HttpPost("RefreshToken")]
        public async Task<ResponseData> RefreshToken([FromBody] RefreshRequest refreshRequest)
        {
            ISingleResponse<UserWithToken> response = new SingleResponse<UserWithToken>();
            var userstring = await GetUserFromAccessToken(refreshRequest.AccessToken);
            var user = userstring.Model;

            if (user != null && await ValidateRefreshToken(user, refreshRequest.RefreshToken))
            {
                UserWithToken userWithToken = new UserWithToken();
                userWithToken.SetData(user);
                userWithToken.AccessToken = GenerateAccessToken(user.id);

                response.Model = userWithToken;
            }

            return SucessResquest(response);
        }

        [HttpPost("GetUserByAccessToken")]
        public async Task<ResponseData> GetUserByAccessToken([FromBody] RefreshRequest refreshRequest)
        {
            return SucessResquest(await GetUserFromAccessToken(refreshRequest.AccessToken));          
        }

        private async Task<bool> ValidateRefreshToken(User user, string refreshToken)
        {          
            var datatoken = await _mediator.Send(new GetAllRefreshTokensByUseridQuery(user.id)); 

            RefreshToken refreshTokenUser = datatoken.Model.Where(rt => rt.Token == refreshToken)
                                                .OrderByDescending(rt => rt.Expiry_Date)
                                                .FirstOrDefault();

            if (refreshTokenUser != null && refreshTokenUser.UserId == user.id
                && refreshTokenUser.Expiry_Date > DateTime.UtcNow)
            {
                return true;
            }

            return false;
        }

        private async Task<ISingleResponse<User>> GetUserFromAccessToken(string accessToken)
        {
            ISingleResponse<User> response = new SingleResponse<User>();
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_jwtsettings.SecretKey);

                var tokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey         = new SymmetricSecurityKey(key),
                    ValidateIssuer           = false,
                    ValidateAudience         = false
                };

                SecurityToken securityToken;
                var principle = tokenHandler.ValidateToken(accessToken, tokenValidationParameters, out securityToken);

                JwtSecurityToken jwtSecurityToken = securityToken as JwtSecurityToken;

                if (jwtSecurityToken != null && jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
                {
                    var userId = int.Parse(principle.FindFirst(ClaimTypes.Name)?.Value);                    
                    var users = await _mediator.Send(new GetAllUserQuery());
                    
                    if (users.Respuesta.ExisteError)
                        response.Respuesta = users.Respuesta;
                    else
                    {
                        response.Model = users.Model.Where(x => x.id == userId).FirstOrDefault();
                    }                  
                }
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Servicio, ex, "");
            }

            return response;
        }

        private RefreshToken GenerateRefreshToken()
        {
            RefreshToken refreshToken = new RefreshToken();
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                refreshToken.Token = Convert.ToBase64String(randomNumber);
            }
            refreshToken.Expiry_Date = DateTime.UtcNow.AddMonths(6);
            return refreshToken;
        }

        private string GenerateAccessToken(int userId)
        {
            var tokenHandler    = new JwtSecurityTokenHandler();
            var key             = Encoding.ASCII.GetBytes(_jwtsettings.SecretKey);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, Convert.ToString(userId))
                }),
                Expires = DateTime.UtcNow.AddDays(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key),
                SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
