﻿using ApiApplication.Features.Odoo.Commands;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Salida;
using Seguridad.ClasesGenericas;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;

namespace ApiAdmin.Controllers.v1
{
    /// <summary>
    /// Events endpoints
    /// </summary>
    [ApiVersion("1.0")]
    [ApiController]
    [Route("[controller]")]
    [Route("v{version:apiVersion}/[controller]")]
    [SwaggerResponse((int)HttpStatusCode.Accepted, Type = typeof(ResponseData), Description = "Datos validos para su procesamiento")]
    [SwaggerResponse((int)HttpStatusCode.NotFound, Type = typeof(ResponseData), Description = "Recurso no encontrado")]
    [SwaggerResponse((int)HttpStatusCode.BadRequest, Type = typeof(ResponseData), Description = "Validación fallida")]
    [SwaggerResponse((int)HttpStatusCode.InternalServerError, Type = typeof(ResponseData), Description = "Excepción de error de la aplicación")]
    public class OCommandController : BaseController
    {
        private readonly IMediator _mediator;
        public OCommandController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost("CerrarNominaActivas")]
        public async Task<ResponseData> CerrarNominaActivas([FromBody] int model)
        {
            var response = await _mediator.Send(new CerrarNominaActivasCommand(model));
            return SucessResquest(response);
        }

        [HttpPost("CrearNomina")]
        public async Task<ResponseData> CrearNomina([FromBody]SolicitarNomina model)
        {
            var response = await _mediator.Send(new CrearNominaComnnad(model));
            return SucessResquest(response);

        }
        [HttpPost("AddAllMarcadas/{operacionid}")]
        public async Task<ResponseData> AddAllMarcadas([FromBody] List<HoraEntrada> model,int operacionid)
        {
            var response = await _mediator.Send(new AddAllMarcadasCommand(model, operacionid));
            return SucessResquest(response);

        }

        [HttpPost("AddMarcadasId/{operacionid}")]
        public async Task<ResponseData> AddMarcadasId([FromBody] DiasTrabajados model, int operacionid)
        {
            var response = await _mediator.Send(new AddMarcadasIdCommand(model, operacionid));
            return SucessResquest(response);
        }

        
        [HttpPost("Crudferiado/{operacionid}")]
        public async Task<ResponseData> Crudferiado([FromBody]DiaFeriado model, int operacionid)
        {
            var response = await _mediator.Send(new CrudferiadoCommand(model, operacionid));
            return SucessResquest(response);

        }
    }
}
