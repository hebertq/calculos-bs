﻿using ApiApplication.Features.Odoo.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Salida;
using Seguridad.ClasesGenericas;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;

namespace ApiAdmin.Controllers.v1
{
    /// <summary>
    /// Events endpoints
    /// </summary>
    [ApiVersion("1.0")]
    [ApiController]
    [Route("[controller]")]
    [Route("v{version:apiVersion}/[controller]")]
    [SwaggerResponse((int)HttpStatusCode.Accepted, Type = typeof(ResponseData), Description = "Datos validos para su procesamiento")]
    [SwaggerResponse((int)HttpStatusCode.NotFound, Type = typeof(ResponseData), Description = "Recurso no encontrado")]
    [SwaggerResponse((int)HttpStatusCode.BadRequest, Type = typeof(ResponseData), Description = "Validación fallida")]
    [SwaggerResponse((int)HttpStatusCode.InternalServerError, Type = typeof(ResponseData), Description = "Excepción de error de la aplicación")]
    public class OdQueryController : BaseController
    {
        private readonly IMediator _mediator;
        public OdQueryController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("GetAllEmpleadosActivos")]
        public async Task<ResponseData> GetAllEmpleadosActivos()
        {
            var response = await _mediator.Send(new GetAllEmpleadosQuery());
            return SucessResquest(response);

        }

        [HttpGet("GetAllCombos/{model}")]
        public async Task<ResponseData> GetAllCombos(string model)
        {
            var response = await _mediator.Send(new GetAllComboQuery(model));
            return SucessResquest(response);

        }

        [HttpGet("GetMarcadaId/{modelid}")]
        public async Task<ResponseData> GetMarcadaId(int modelid)
        {
            var response = await _mediator.Send(new GetMarcadaIdQuery(modelid));
            return SucessResquest(response);

        }
       
        [HttpGet("GetAllDiasTrabajados")]
        public async Task<ResponseData> GetAllDiasTrabajados([FromBody] typeeinout model)
        {
            var response = await _mediator.Send(new GetAllDiasTrabajadosQuery(model));
            return SucessResquest(response);
        }
        [HttpGet("GetAllDiasTrabajadosOperacion")]
        public async Task<ResponseData> GetAllDiasTrabajadosOperacion([FromBody] typeeinout model)
        {
            var response = await _mediator.Send(new GetAllDiasTrabajadosOperacionQuery(model));
            return SucessResquest(response);
        }
        [HttpGet("GetAllDiasFeriados")]
        public async Task<ResponseData> GetAllDiasFeriados()
        {
            var response = await _mediator.Send(new GetAllDiasFeriadosQuery());
            return SucessResquest(response);
        }
        [HttpGet("GetAllMarcadasFacturar")]
        public async Task<ResponseData> GetAllMarcadasFacturar([FromBody] typeeinout model)
        {
            var response = await _mediator.Send(new GetAllMarcadasFacturarQuery(model));
            return SucessResquest(response);
        }
        [HttpGet("GetAllDiasxPagar")]
        public async Task<ResponseData> GetAllDiasxPagar([FromBody] typeeinout model)
        {
            var response = await _mediator.Send(new GetAllDiasxPagarQuery(model));
            return SucessResquest(response);
        }
        [HttpGet("GetAllPagoNomina/{modelid}")]
        public async Task<ResponseData> GetAllPagoNomina(int modelid)
        {
            var response = await _mediator.Send(new GetAllPagoNominaQuery(modelid));
            return SucessResquest(response);
        }
    }
}

