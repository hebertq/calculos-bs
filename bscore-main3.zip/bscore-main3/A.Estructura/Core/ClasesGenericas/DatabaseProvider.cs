﻿using Microsoft.Extensions.Configuration;
using Modelo.ClasesGenericas;
using System;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data;
using Modelo.Exceptions;

namespace Core.ClasesGenericas
{
    public abstract class DatabaseProvider : IDisposable
    {
        private readonly IConfiguration _configuration;
        public AppConfig     _config;
        private DbConnection _connection;
        public DatabaseProvider(IConfiguration configuration)
        {
            _configuration = configuration;
            _config = _configuration.Get<AppConfig>();
        }
        public abstract DbProviderFactory Factory { get; }

        public virtual void Dispose()
        {
            _connection?.Dispose();
            _connection = null;
        }
        public abstract string GetConnectionString(InfoContextSQL name);

        public async Task<DbConnection> GetOpenConnection(InfoContextSQL _ContexName)
        {
            try
            {
                _connection = Factory.CreateConnection();
                _connection.ConnectionString = GetConnectionString(_ContexName);

                await _connection.OpenAsync();
                if (_connection.State != ConnectionState.Open)
                    throw new CustomMessageException() { ExceptionMessage = "La coneccioón debe estar abierta!." };
            }
            catch(Exception ex)
            {
                throw new RulesException("Conección", "No ha sido posible establecer la conección con la base de datos",ex);  
            }

            return _connection;
        }
    }
}


