﻿using Core.ClasesGenericas;
using Dapper;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Npgsql;
using NpgsqlTypes;
using System;
using System.Data;
using System.Reflection;
using static Dapper.SqlMapper;

namespace Core.Estructuras
{
    public static class DapperExtension
    {      
        public static DynamicParameters WithSqlParam(this DynamicParameters dbparams, string paramName, object paramValue, DbType tipo)
        {
            dbparams.Add(paramName,paramValue,tipo);
            return dbparams;
        }

        public static void PrepareParameter(this DynamicParameters param, object parameters)
        {           
            if (parameters != null)
            {
                foreach (PropertyInfo prop in parameters.GetType().GetProperties())
                {
                    object value = prop.GetValue(parameters, null);
                    string name  = prop.Name;                   
                    DbType tipo;

                    if (value.GetType().GetProperty("TableName") != null)
                    {
                        tipo = DbType.Object;
                    }
                    if (name.Contains("pij_"))
                    {
                        string jsonstring = JsonConvert.SerializeObject(value);
                        //param.Parameters.Add(new NpgsqlParameter(name, NpgsqlDbType.Jsonb) { Value = jsonstring });
                    }
                    else
                    {
                        tipo = TypeConvertor.ToDbType(prop.PropertyType);
                        param.WithSqlParam(name, value, tipo);
                    }                                          
                }
            }
        }     
    }

    //class JObjectHandler : TypeHandler<JObject>
    //{
    //    private JObjectHandler() { }
    //    public static JObjectHandler Instance { get; } = new JObjectHandler();
    //    public override JObject Parse(object value)
    //    {
    //        var json = (string)value;
    //        return json == null ? null : JObject.Parse(json);
    //    }
    //    public override void SetValue(IDbDataParameter parameter, JObject value)
    //    {
    //        parameter.Value = value?.ToString(Formatting.None);
    //    }
    //}
}
