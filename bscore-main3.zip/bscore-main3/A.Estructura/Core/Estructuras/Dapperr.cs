﻿using Core.ClasesGenericas;
using Core.Interfaces;
using Dapper;
using Modelo.ClasesGenericas;
using Modelo.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Validation;
using System.Linq;
using System.Threading.Tasks;

namespace Core.Estructuras
{
    public class Dapperr : IDapper
    {
        private readonly SqlContext _SqlContext;
        private readonly NpgContext _NpgContex;

        private IDbConnection  db;
        public DatabaseProvider _context { set; get; }
        private IDbTransaction dbTra;
        private bool _IsTransaction = false;
        private bool _disposed = false;
        private string errorMessage = string.Empty;

        public ResultadoGenerico _InfoRespuesta { set; get; } = new ResultadoGenerico();
        public Dapperr(SqlContext sqlcontext, NpgContext npgcontext)
        {
            _SqlContext = sqlcontext;
            _NpgContex  = npgcontext;
        }

        public TipoDB _dbTipo { set; get; } = TipoDB.NPGDB;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        public virtual void Dispose(bool disposing)
        {
            if (!_disposed)
                if (disposing)
                {
                    if (_SqlContext != null)
                        _SqlContext.Dispose();
                    if (_NpgContex != null)
                        _NpgContex.Dispose();
                }                  

            _disposed = true;
            _IsTransaction = false;
        }

        public IDbConnection ConnecDb
        {
            get { return db; }
        }

        public void CreateConnection()
        {
            if(_dbTipo == TipoDB.SQLDB)
            {
                _context = _SqlContext;
            }               
            else if (_dbTipo == TipoDB.NPGDB)
            {
                _context = _NpgContex;
            }
                
            _disposed = false;
        }

        public void Transaction()
        {
             CreateConnection();
            _IsTransaction = true;
            dbTra = db.BeginTransaction();
        }
        public void CommitTran()
        {
            dbTra.Commit();
        }
        public void RollbackTran()
        {
            dbTra.Rollback();
        }

        public InfoContextSQL dbcontex { set; get; }

        public async Task Execute(string sp, object parms, CommandType commandType = CommandType.StoredProcedure)
        {
            CreateConnection();
            using (var connection = await _context.GetOpenConnection(dbcontex))
            {
                try
                {
                    await connection.ExecuteAsync(sp, parms, commandType: commandType).ConfigureAwait(false);
                }
                catch (DbEntityValidationException dbEx)
                {
                    foreach (var validationErrors in dbEx.EntityValidationErrors)
                    {
                        foreach (var validationError in validationErrors.ValidationErrors)
                        {
                            errorMessage += Environment.NewLine + string.Format("Propiedad: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                        }
                    }
                    throw new RulesException("Validación", errorMessage);
                }
                catch (Exception ex)
                {
                    throw new RulesException("Acceso", "No es posible ejecutar la intrucción a base de datos");
                }
            }
        }
        public async Task<T> GetAsync<T>(string sp, object parms, CommandType commandType = CommandType.Text) where T : class, new()
        {
            CreateConnection();
            using (var connection = await _context.GetOpenConnection(dbcontex))
            {
                try
                {
                    return await connection.QuerySingleOrDefaultAsync<T>(sp, parms, commandType: commandType).ConfigureAwait(false);
                }
                catch (DbEntityValidationException dbEx)
                {
                    foreach (var validationErrors in dbEx.EntityValidationErrors)
                    {
                        foreach (var validationError in validationErrors.ValidationErrors)
                        {
                            errorMessage += Environment.NewLine + string.Format("Propiedad: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                        }
                    }
                    throw new RulesException("Validación", errorMessage);
                }
                catch (Exception ex)
                {
                    throw new RulesException("Acceso", "No es posible ejecutar la intrucción a base de datos");
                }
            }
        }
        public async Task<List<T>> GetAllAsync<T>(string sp, object parms, CommandType commandType = CommandType.StoredProcedure) where T : class, new()
        {
            CreateConnection();
            using (var connection = await _context.GetOpenConnection(dbcontex))
            {
                try
                {
                    var result = await connection.QueryAsync<T>(sp, parms, commandType: commandType).ConfigureAwait(false);
                    return result.ToList();
                }
                catch (DbEntityValidationException dbEx)
                {
                    foreach (var validationErrors in dbEx.EntityValidationErrors)
                    {
                        foreach (var validationError in validationErrors.ValidationErrors)
                        {
                            errorMessage += Environment.NewLine + string.Format("Propiedad: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                        }
                    }
                    throw new RulesException("Validación", errorMessage);
                }
                catch (Exception ex)
                {
                    throw new RulesException("Acceso", "No es posible ejecutar la intrucción a base de datos");
                }
            }
        }

        public async Task<DataSet> QueryMultiple(string sp, object parms, CommandType commandType = CommandType.StoredProcedure)
        {
            CreateConnection();
            using (var connection = await _context.GetOpenConnection(dbcontex))
            {
                try
                {
                    var result = await connection.ExecuteReaderAsync(sp, parms, commandType: commandType).ConfigureAwait(false);
                    return ConvertDataReaderToDataSet(result);
                }
                catch (DbEntityValidationException dbEx)
                {
                    foreach (var validationErrors in dbEx.EntityValidationErrors)
                    {
                        foreach (var validationError in validationErrors.ValidationErrors)
                        {
                            errorMessage += Environment.NewLine + string.Format("Propiedad: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                        }
                    }
                    throw new RulesException("Validación", errorMessage);
                }
                catch (Exception ex)
                {
                    throw new RulesException("Acceso", "No es posible ejecutar la intrucción a base de datos");
                }
            }
        }

        public async Task<T> CrudTransAsync<T>(string sp, object parms, CommandType commandType = CommandType.StoredProcedure) where T : class, new()
        {
            CreateConnection();
            using (var connection = await _context.GetOpenConnection(dbcontex))
            {
                try
                {
                    //if (!_IsTransaction)
                    //    await CreateConnection();
                    return await connection.QuerySingleOrDefaultAsync<T>(sp, parms, commandType: commandType, transaction: _IsTransaction ? dbTra : null).ConfigureAwait(false);
                }
                catch (DbEntityValidationException dbEx)
                {
                    foreach (var validationErrors in dbEx.EntityValidationErrors)
                    {
                        foreach (var validationError in validationErrors.ValidationErrors)
                        {
                            errorMessage += Environment.NewLine + string.Format("Propiedad: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                        }
                    }
                    throw new RulesException("Validación", errorMessage);
                }
                catch (Exception ex)
                {
                    throw new RulesException("Acceso", "No es posible ejecutar la intrucción a base de datos");
                }
            }
        }

        private DataSet ConvertDataReaderToDataSet(IDataReader data)
        {
            DataSet ds = new DataSet();
            int i = 0;
            while (!data.IsClosed)
            {
                ds.Tables.Add("Table" + (i + 1));
                ds.EnforceConstraints = false;
                ds.Tables[i].Load(data);
                i++;
            }
            return ds;
        }
    }
}


