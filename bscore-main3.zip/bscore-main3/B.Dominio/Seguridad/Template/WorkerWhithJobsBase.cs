﻿using BPMLogger;
using Microsoft.Extensions.Hosting;
using Modelo.ClasesGenericas;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using static Modelo.ClasesGenericas.AppConfig;
using Utilidades.Interfaces;
using Microsoft.Extensions.Configuration;
using Quartz.Spi;
using Quartz;
using Modelo.Salida;
using Microsoft.Extensions.DependencyInjection;
using Seguridad.ClasesGenericas;

namespace Seguridad.Template
{
    public abstract class WorkerWhithJobsBase : BackgroundService
    {
        private Timer _timer;
        private static object _lock = new object();
        private readonly IUtilidades              _Util;
        private readonly ILoggerBMP               _Log;
        protected ISchedulerFactory               _schedulerFactory;
        protected IJobFactory                     _jobFactory;
        private readonly TimeSpan _period;
        public IScheduler Scheduler { get; set; }
        private readonly AppSettingsSW _ConfigService;
        private int _executionCount = 0;
        public bool IsEnabled { get; set; }

        public LogJob _SegProc;
        public string BathName = "";
        public string ServiceName = "";

        public WorkerWhithJobsBase(IUtilidades Util, ILoggerBMP Log, IConfiguration Conf, ISchedulerFactory schedulerFactory, IJobFactory jobFactory)
        {
            Util.Options      = Conf.Get<AppConfig>();
            _Util             = Util;
            _ConfigService    = _Util.ConfigService;
            _Log              = Log;
            _schedulerFactory = schedulerFactory;
            _jobFactory       = jobFactory;
            _period           = TimeSpan.FromMinutes(_ConfigService.TiempoEspera);
        }
          
        public static IJobDetail CreateJob(JobSchedule schedule)
        {
            var jobType = schedule.JobType;
            return JobBuilder
                .Create(jobType)
                .WithIdentity(jobType.FullName)
                .WithDescription(jobType.Name)
                .Build();
        }

        public static ITrigger CreateTrigger(JobSchedule schedule)
        {
            return TriggerBuilder
                .Create()
                .WithIdentity($"{schedule.JobType.FullName}.trigger")
                .StartNow()
                .Build();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            using PeriodicTimer timer = new PeriodicTimer(_period);
            while (!stoppingToken.IsCancellationRequested && await timer.WaitForNextTickAsync(stoppingToken))
            {                                 
                int nHoraActual = DateTime.Now.Hour;
                if (nHoraActual >= _ConfigService.HoraInicio && nHoraActual <= _ConfigService.HoraFin) //Hora de Ejecucion del Servicio
                {
                    if (Monitor.TryEnter(_lock))
                    {
                        try
                        {
                            await ExecuteJob(stoppingToken);
                        }
                        catch (Exception ex)
                        {
                            _Log.LogError("00000000", "inicio-WorkerWhithJobsBase", ex.Message, ex);
                        }
                        finally
                        {
                            Monitor.Exit(_lock);
                        }
                    }
                }               
            }
        }

        protected virtual async Task ExecuteJob(CancellationToken stoppingToken)
        {
            
        }
       
    }
}
