﻿using Microsoft.AspNetCore.Mvc;
using Modelo.ClasesGenericas;
using Modelo.Salida;
using System.Collections.Generic;

namespace Seguridad.ClasesGenericas
{
    public abstract class ResponseController : ControllerBase
    {
        protected ResponseData ResultResquest(EResponse code = EResponse.OK, object result = null, object data = null,string title = "") => new ResponseData(code: code, data: result, dataresp: data, tit: title);
        protected ResponseData SucessResquest() => ResultResquest(EResponse.OK, result: null);
        protected ResponseData SucessResquest(object result) => ResultResquest(EResponse.OK, result: result,title: "Datos validos para procesamiento");
        protected ResponseData SucessResquestOther(object result) => ResultResquest(EResponse.OK, result:null, data: result, title: "Datos validos para procesamiento");
        protected ResponseData UnexpectedErrorResquest(object result = null) => ResultResquest(EResponse.UnexpectedError, result, title: "Excepción de error de la aplicación");
        protected ResponseData NoDataResquest(object result = null) => ResultResquest(EResponse.NoData, result);
        protected ResponseData NoPermissionResquest(object result = null) => ResultResquest(EResponse.NoPermission, result);
        protected ResponseData ValidationErrorResquest(List<string> errorList) => ResultResquest(EResponse.ValidationError, result: errorList, title: "Validación fallida");
        protected ResponseData ValidationErrorResquest(string errorList) => ResultResquest(EResponse.ValidationError, result: errorList, title: "Validación fallida");
        protected ResponseData UnSuccessResquest() => ResultResquest(EResponse.UnSuccess, title: "Excepción de error de la aplicación");
        protected ResponseData CreateResquest(object result) => result is null ? UnSuccessResquest() : SucessResquestOther(result);
    }
}
