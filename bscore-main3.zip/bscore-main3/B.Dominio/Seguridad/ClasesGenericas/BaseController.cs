﻿using Modelo.Salida;
using System;
using System.ComponentModel.DataAnnotations;

namespace Seguridad.ClasesGenericas
{
    public abstract class BaseController : ResponseController
    {
        protected delegate ResponseData ExecuteReponse(object res, object err);
        protected delegate object ExecuteAction();

        protected ResponseData Execute(ExecuteReponse response, ExecuteAction action, object error)
        {
            try
            {
                return response(action(), error);
            }           
            catch (Exception ex)
            {
                return UnexpectedErrorResquest(ex.Message);
            }
        }

        protected void NoDataValidate(bool condition, string message = null)
        {
            if (condition)
                throw new Exception(message);
        }
        protected void ValidationValidate(bool condition, string message = null)
        {
            if (condition)
                throw new ValidationException(message);
        }
        protected void NoPermissionExceptionValidate(bool condition, string message = null)
        {
            if (condition)
                throw new Exception(message);
        }

        protected object GetUserData()
        {
            NoPermissionExceptionValidate(!User.Identity.IsAuthenticated, "No permission");
            return "id:1 - name: Joe";
        }
    }
}

