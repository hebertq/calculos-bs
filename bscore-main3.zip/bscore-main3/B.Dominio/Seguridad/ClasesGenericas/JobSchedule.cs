﻿using Modelo.Entidades;
using System;
using System.Collections.Generic;

namespace Seguridad.ClasesGenericas
{
    public class JobSchedule
    {
        public JobSchedule(Type jobType)
        {
            JobType = jobType;
        }

        public Type JobType { get; }
    }

    public class JobScheduleWork
    {     
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string TipoJob { get; set; }
        DateTime InicioEjecucion { get; set; }
        DateTime? FinEjecucion { get; set; }
        public JobSchedule JobExecute { get; set; }
        public string Eventos { set; get; } = "";
        public int Prioridad { get; set; }
    }
}
