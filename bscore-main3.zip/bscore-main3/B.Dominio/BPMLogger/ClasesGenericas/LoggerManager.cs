﻿using log4net;
using log4net.Config;
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Xml;

namespace BPMLogger.ClasesGenericas
{
    public class LoggerManager 
    {
        private static ILog LogEmail  = null;
        private static ILog LogSql    = null;
        private static ILog logFile   = null;
        public LoggerManager()
        {
            try
            {
                string Dominio = string.Empty;
                try
                {
                    Dominio = Directory.GetCurrentDirectory();
                }
                catch 
                {
                    Dominio = AppDomain.CurrentDomain.BaseDirectory;
                }

                string DataFilePath = Path.Combine(Dominio, "log4net.config");
                XmlDocument log4netConfig = new XmlDocument();

                if (File.Exists(DataFilePath))
                {
                    using (var fs = File.OpenRead(DataFilePath))
                    {
                        log4netConfig.Load(fs);
                        var repo = LogManager.CreateRepository(Assembly.GetEntryAssembly(),typeof(log4net.Repository.Hierarchy.Hierarchy));
                        string ruta = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase);
                        GlobalContext.Properties["FilePath"] = ruta.Substring(6, ruta.Length - 6);
                        XmlConfigurator.Configure(repo, log4netConfig["log4net"]);
                    }

                    LogEmail = LogManager.GetLogger("BpmSmtpAppender");
                    LogSql   = LogManager.GetLogger("BizAgiWSLogger");
                    logFile  = LogManager.GetLogger("LogFileAppender");
                }              
            }
            catch (Exception ex)
            {
             #pragma warning disable CA1416 // Validate platform compatibility
                EventLog.WriteEntry("BIZEMIRDBath", "El servicio no ha podido cargar archivo de log4net", EventLogEntryType.Error);
                EventLog.WriteEntry("BIZEMIRDBath", ex.Message, EventLogEntryType.Error);
             #pragma warning restore CA1416 // Validate platform compatibility
             throw ex;
            }
        }
        
        /// <summary>
        /// Retorna el LogManager Appender a usar
        /// </summary>
        /// <returns></returns>
        private ILog Log(TipoLog tipo)
        {
            switch(tipo)
            {
                case TipoLog.DataBase:
                    return LogSql;
                case TipoLog.Email:
                    return LogEmail;
                case TipoLog.File:
                    return logFile;
                default:
                    return LogSql;
            }
        }
        /// <summary>
        /// Log de error con objeto Exception
        /// Envia automaticamene un email si en el config del proyecto
        /// se ha definido un Appender para correo BpmSmtpAppender
        /// </summary>
        /// <param name="mensaje"></param>
        /// <param name="tipo"></param>
        /// <param name="numero"></param>
        /// <param name="servicio"></param>
        /// <param name="e"></param>
        public void LogError(string mensaje, string numero, int servicio, TipoTransaccion tipotra, TipoLog tipolo,Exception e = null )
        {
            try
            {
                log4net.GlobalContext.Properties["tipo"]     = (int)tipotra;
                log4net.GlobalContext.Properties["numero"]   = numero;
                log4net.GlobalContext.Properties["servicio"] = servicio;

                var manager = Log(tipolo);
                if(e != null)
                    manager.Error(mensaje, e);
                else
                    manager.Error(mensaje, new Exception("Mensaje Excepcion Error"));               
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        /// <summary>
        /// Informacion del Log
        /// </summary>
        /// <param name="mensaje"></param>
        /// <param name="tipo"></param>
        /// <param name="numero"></param>
        /// <param name="servicio"></param>
        /// <param name="e"></param>
        public void LogInfo(string mensaje, string numero, int servicio, TipoTransaccion tipotra , TipoLog tipolo)
        {
            try
            {
                log4net.GlobalContext.Properties["tipo"]     = (int)tipotra;
                log4net.GlobalContext.Properties["numero"]   = numero;
                log4net.GlobalContext.Properties["servicio"] = servicio;

                var manager = Log(tipolo);             
                manager.Info(mensaje, new Exception("Mensaje Excepcion Info"));
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Log Debug con el mensaje deseado
        /// </summary>
        /// <param name="mensaje"></param>
        /// <param name="numero"></param>
        /// <param name="servicio"></param>
        public void LogDebug(string mensaje, string numero, int servicio, TipoTransaccion tipotra, TipoLog tipolo)
        {
            try
            {
                log4net.GlobalContext.Properties["tipo"]     = (int)tipotra;
                log4net.GlobalContext.Properties["numero"]   = numero;
                log4net.GlobalContext.Properties["servicio"] = servicio;

                var manager = Log(tipolo);
                manager.Debug(mensaje);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Genera un log con etiqueta Warning
        /// </summary>
        /// <param name="mensaje"></param>
        /// <param name="numero"></param>
        /// <param name="servicio"></param>
        public void LogWarning(string mensaje, string numero, int servicio, TipoTransaccion tipotra, TipoLog tipolo)
        {
            try
            {
                log4net.GlobalContext.Properties["tipo"]     = (int)tipotra;
                log4net.GlobalContext.Properties["numero"]   = numero;
                log4net.GlobalContext.Properties["servicio"] = servicio;
                var manager = Log(tipolo);
                manager.Warn(mensaje, new Exception("Mensaje Excepcion Advertencia"));
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        /// <summary>
        /// Log de error Fatal con o sin Exception, 
        /// Envia automaticamene un email si en el config del proyecto
        /// se ha definido un Appender para correo BpmSmtpAppender
        /// </summary>
        /// <param name="mensaje"></param>
        /// <param name="numero"></param>
        /// <param name="servicio"></param>
        /// <param name="tipo"></param>
        public void LogFatal(string mensaje, string numero, int servicio, TipoTransaccion tipotra , Exception e, TipoLog tipolo)
        {
            try
            {
                log4net.GlobalContext.Properties["tipo"]     = (int)tipotra;
                log4net.GlobalContext.Properties["numero"]   = numero;
                log4net.GlobalContext.Properties["servicio"] = servicio;

                var manager = Log(tipolo);
                manager.FatalFormat("Caso {0} | Servicio {1} | Mensaje {2} | Exception {3}", numero, servicio, mensaje, e);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
