﻿using Modelo.ClasesGenericas;
using Modelo;
using System;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Threading.Tasks;
using Utilidades.Interfaces;
using Blazored.LocalStorage;
using Modelo.Salida;
using System.Reflection;

namespace HostService.ClasesGenericas
{
    public abstract class ServiceHost
    {
        private  HttpClient _httpClient;
        private   ILocalStorageService _localStorageService { get; }
        protected IUtilidades _Util;
        public ServiceHost(IUtilidades util, ILocalStorageService ls)
        {         
            _localStorageService = ls;
            _Util = util;           
        }
        public async Task<Message<ResponseData>> GetAsync(Uri requestUrl)
        {
            string metodo = $"HttpClient_{MethodBase.GetCurrentMethod().Name}_{requestUrl}";
            _httpClient = new HttpClient();
            await addHeaders();
            Message<ResponseData> Result = new Message<ResponseData>();
            try
            {
                using (HttpResponseMessage response = await _httpClient.GetAsync(requestUrl, HttpCompletionOption.ResponseHeadersRead))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        response.EnsureSuccessStatusCode();
                        var data = await response.Content.ReadAsStringAsync();
                        Result.Data = _Util.ObtenerRegistro<ResponseData>(data);
                    }
                    else
                    {
                        string status = response.StatusCode.ToString();
                        Result.SetErroAcces("Error al aceder a " + requestUrl.ToString(), metodo, status);
                    }
                }
            }
            catch (CoreException ex)
            {
                Result.SetErrorExep(ex, metodo);
            }

            return Result;
        }
        public async Task<Message<ResponseData>> GetAsync<T>(Uri requestUrl,T content)
        {
            string metodo = $"HttpClient_{MethodBase.GetCurrentMethod().Name}_{requestUrl}";
            _httpClient = new HttpClient();
            await addHeaders();
            Message<ResponseData> Result = new Message<ResponseData>();
            try
            {
                var requestContent = _Util.CreateHttpContent(content);
                var request        = new HttpRequestMessage(HttpMethod.Get, requestUrl);
                request.Content    = requestContent;

                using (HttpResponseMessage response = await _httpClient.SendAsync(request))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        response.EnsureSuccessStatusCode();
                        var data = await response.Content.ReadAsStringAsync();
                        Result.Data = _Util.ObtenerRegistro<ResponseData>(data);
                    }
                    else
                    {
                        string status = response.StatusCode.ToString();
                        Result.SetErroAcces("Error al aceder a " + requestUrl.ToString(), metodo, status);
                    }
                }               
            }
            catch (CoreException ex)
            {
                Result.SetErrorExep(ex, metodo);
            }
            
            return await Task.FromResult(Result);
        }
    

        /// <summary>
        /// Common method for making POST calls
        /// </summary>
        public async Task<Message<ResponseData>> PostAsync<T>(Uri requestUrl, T content)
        {
            string metodo = $"HttpClient_{MethodBase.GetCurrentMethod().Name}_{requestUrl}";
            _httpClient = new HttpClient();
            await addHeaders();
            Message<ResponseData> Result = new Message<ResponseData>();
            try
            {                   
                using (HttpResponseMessage response = await _httpClient.PostAsync(requestUrl.ToString(), _Util.CreateHttpContent(content)))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        response.EnsureSuccessStatusCode();
                        var data = await response.Content.ReadAsStringAsync();
                        Result.Data = _Util.ObtenerRegistro<ResponseData>(data);
                    }
                    else
                    {
                        string status = response.StatusCode.ToString();
                        Result.SetErroAcces("Error al aceder a " + requestUrl.ToString(), metodo, status);
                    }
                }                               
            }
            catch (CoreException ex)
            {
                Result.SetErrorExep(ex, metodo);
            }

            return Result;
        }
        
        public Uri CreateRequestUri(string relativePath, string queryString = "")
        {
            string path = string.Format(System.Globalization.CultureInfo.InvariantCulture, relativePath);
            var endpoint = new Uri(new Uri(_Util.BaseUrlApiLog), path);
            var uriBuilder = new UriBuilder(endpoint);
            uriBuilder.Query = queryString;
            return uriBuilder.Uri;
        }

        private async Task addHeaders()
        {
           
            _httpClient.DefaultRequestHeaders.Remove("userIP");
            _httpClient.DefaultRequestHeaders.Add("userIP", "192.168.1.1");
            _httpClient.BaseAddress = new Uri(_Util.BaseUrlApiLog);
            _httpClient.DefaultRequestHeaders.Accept.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            _httpClient.DefaultRequestHeaders.ConnectionClose = false;

            if (_localStorageService != null)
            {
                var token = await _localStorageService.GetItemAsync<string>("accessToken");
                if (token != null)
                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}




