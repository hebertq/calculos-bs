﻿using Core.Estructuras;
using Core.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Repositorio.Clases;
using Repositorio.Interfaces;


namespace Repositorio.Extensions
{
    public static class DependencyInjection
    {
        public static void AddDataRepositories(this IServiceCollection services)
        {
            services.AddSingleton<SqlContext>();
            services.AddSingleton<NpgContext>();
            
            services.AddScoped<IDapper, Dapperr>();
            services.AddScoped<IOdooRepositorio, OdooRepositorio>();
            services.AddScoped<IAdminRepositorio, AdminRepositorio>();

        }
    }
}
