﻿using Core.Interfaces;
using Modelo.ClasesGenericas;
using Modelo.Interfaces;
using Repositorio.ClasesGenericas;
using System.Data;
using System.Reflection;
using System.Threading.Tasks;
using System;
using Utilidades.Interfaces;
using Modelo.Admin;
using Repositorio.Interfaces;
using Modelo.Entidades;

namespace Repositorio.Clases
{
    internal class AdminRepositorio : RepositorioBase, IAdminRepositorio
    {
        public AdminRepositorio(IDapper dapper, IUtilidades util) : base(dapper, util)
        {
            _dapper.dbcontex = InfoContextSQL.Rrhhbussersa;
            _dapper._dbTipo  = TipoDB.NPGDB;
        }

        public async Task<IListResponse<User>> GetAllUsers()
        {
            IListResponse<User> response = new ListResponse<User>();
            try
            {
                string func = "select id,email,password,nombres,apellidos,grupoid,(select json_agg(json_build_object('id',t.id,'nombre',t.nombre)) from admon.getmenus(grupoid) t) nav_menu from admon.mstusuario";
                var result = await _dapper.GetAllAsync<User>(func, null, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = result;
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }

        public async Task<IListResponse<RefreshToken>> GetAllRefreshTokensByUserid(int id)
        {
            IListResponse<RefreshToken> response = new ListResponse<RefreshToken>();
            try
            {
                string func = "select * from admon.mstrefreshtoken where userid = @Id";
                var result = await _dapper.GetAllAsync<RefreshToken>(func, new {Id=id}, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = result;
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }

        public async Task<IResponse> AddRefreshTokensByUserid(RefreshToken token)
        {
            IResponse response = new ErrorResponse();
            try
            {
                string func = "insert into admon.mstrefreshtoken(userid, token, expiry_date) values(@UserId, @Token, @Expiry_Date)";
                await _dapper.Execute(func, new { UserId = token.UserId, Token  = token.Token, Expiry_Date  = token.Expiry_Date}, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
               
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }

        public async Task<IListResponse<Menus>> GetAllMenusGrupo(int grupo)
        {
            var response = new ListResponse<Menus>();
            try
            {
                string func = "select * from admon.getmenus(@pii_grupo)";
                var result = await _dapper.GetAllAsync<Menus>(func, new { pii_grupo = grupo }, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = result;
            }
            catch (CoreException ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
    }
}
