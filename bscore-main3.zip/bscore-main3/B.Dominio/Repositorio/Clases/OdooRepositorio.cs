﻿using Core.Interfaces;
using Modelo.ClasesGenericas;
using Modelo.Interfaces;
using Repositorio.ClasesGenericas;
using System.Reflection;
using System.Threading.Tasks;
using Utilidades.Interfaces;
using Repositorio.Interfaces;
using System.Data;
using Modelo.Entidades.Entradas.Odoo;
using System.Collections.Generic;
using System.Linq;

namespace Repositorio.Clases
{
    internal class OdooRepositorio : RepositorioBase, IOdooRepositorio
    {
        public OdooRepositorio(IDapper dapper, IUtilidades util) : base(dapper, util)
        {
            _dapper.dbcontex = InfoContextSQL.Odoo;
            _dapper._dbTipo  = TipoDB.NPGDB;
        }
        public async Task<IListResponse<Combos>> GetAllEmpleados()
        {
            string metodo = $"Rep_Db_Combos{MethodBase.GetCurrentMethod().Name}";
            IListResponse<Combos> response = new ListResponse<Combos>();

                string func = "select x_empleado_id id,e.name as nombre " +
                              "from public.hr_employee e "+
                              "inner join hr_contract c on c.id = e.contract_id " +
                              "where c.active = true " +
                              "and c.state = 'open'";
            var result  = await _dapper.GetAllAsync<Combos>(func, null,CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else                  
                    response.Model = result;
 

            return response;
        }

        public async Task<IListResponse<EmpleadosActivos>> GetAllEmpleadosActivos()
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            var response = new ListResponse<EmpleadosActivos>();

            string func = "select x_empleado_id idnomina,e.name as nombrecompleto,e.identification_id nocedula," +
                          "replace((case when length(trim(COALESCE(e.ssnid,'0'))) < 5 then '0' else trim(COALESCE(e.ssnid,'0')) end),'-','')::double precision  noinss,e.x_activo_inss activoinss,c.id nocontrato,c.date_start fechaini " +
                          "from public.hr_employee e " +
                          "inner join hr_contract c on c.id = e.contract_id " +
                          "where c.active = true " +
                          "and c.state    = 'open'";

            var result = await _dapper.GetAllAsync<EmpleadosActivos>(func, null, CommandType.Text);

            if (_dapper._InfoRespuesta.ExisteError)
                response.Respuesta = _dapper._InfoRespuesta;
            else
                response.Model = result;


            return response;
        }

        public async Task<IResponse> Crudferiado(DiaFeriado param, int op)
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            var response = new ErrorResponse();
    
                var query = await _dapper.GetAllAsync<ErrorMjsBd>("select * from public.crudferiado(@pii_dia,@pii_mes,@pii_anyo,@piv_descripcion,@pii_municipio,@pii_operacion)", new
                {
                    pii_dia         = param.dia,
                    pii_mes         = param.mes,
                    pii_anyo        = param.anyo,
                    piv_descripcion = param.descripcion,
                    pii_municipio   = param.municipio,
                    pii_operacion   = op
                }, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Respuesta.SetErrorDb(query.FirstOrDefault(), metodo);
           

            return response;
        }

        public async Task<IResponse> AddAllMarcadas(List<HoraEntrada> param, int operacion)
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            var response = new ErrorResponse();
           
                var result = await _dapper.GetAsync<ErrorMjsBd>("select * from public.add_payroll_marking_json(@pij_marcadas,@pii_area)", new
                {
                    pij_marcadas = new JsonParameter<List<HoraEntrada>>(param),
                    pii_area     = operacion
                }, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else if (result.iserror)
                    response.Respuesta.SetErrorDb(result, metodo);   
                else
                    response.Respuesta.SetErrorDb(result, metodo, true);

            return response;
        }

        public async Task<ISingleResponse<DiasTrabajados>> AddMarcadasId(DiasTrabajados param, int operacion)
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            ISingleResponse<DiasTrabajados> response = new SingleResponse<DiasTrabajados>();
            
                var request = new HoraEntrada() { id = param.id,nombre = param.nombre,entrada = param.entrada,salida = param.salida,fecha = param.fecha.ToString("yyyy-mm-dd"),bono = (double)param.bono,almuerzocena = (double)param.comida };
                var lista = new List<HoraEntrada>();
                lista.Add(request);

                var result = await _dapper.GetAsync<ErrorMjsBd>("select * from public.add_payroll_marking_json(@pij_marcadas,@pii_area)", new
                {
                    pij_marcadas = new JsonParameter<List<HoraEntrada>>(lista),
                    pii_area = operacion
                },CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                {
                    if (result.iserror)
                        response.Respuesta.SetErrorDb(result, "Rep_Db_AddMarcadasId");
                    else
                    {
                        int codigo = 0;
                        codigo = result.codid;
                        if (codigo > 0 && result.querydb != null)
                            response.Model = _Util.ObtenerRegistro<DiasTrabajados>(result.querydb);
                    }                                    
                }
            
           
            return response;
        }

        public async Task<ISingleResponse<DiasTrabajados>> GetMarcadaId(int idmarcada)
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            var response = new SingleResponse<DiasTrabajados>();
           
                var query = await _dapper.GetAsync<DiasTrabajados>("select * from public.get_employee_days_worked_id(@pii_marca)", new
                {
                    pii_marca = idmarcada
                }, CommandType.Text); 

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = query;
            
           
            return response;
        }

        public async Task<IResponse> CerrarNominaActivas(int operacion)
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            var response = new ErrorResponse();
           
                var query = await _dapper.GetAsync<ErrorMjsBd>("select * from public.add_close_payslip_run(@pii_nomina)", new
                {
                    pii_nomina = operacion
                }, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                   response.Respuesta.SetErrorDb(query, metodo);
            
            
            return response;
        }
        
        public async Task<IResponse> CrearNomina(SolicitarNomina nomina)
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            var response = new ErrorResponse();
           
                var result = await _dapper.GetAsync<ErrorMjsBd>("select * from public.add_payslips(@pidt_inicio::date,@pidt_fin::date,@piv_nombre,@piv_cliente,@pij_detalle)", new
                {
                    pidt_inicio = nomina.perido.entrada,
                    pidt_fin    = nomina.perido.salida,
                    piv_nombre  = nomina.nombre,
                    piv_cliente = nomina.cliente,
                    pij_detalle = new JsonParameter<List<diasxpagarperiodo>>(nomina.detalle)
                    
                }, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else if (result.iserror)
                    response.Respuesta.SetErrorDb(result, metodo);
                else
                    response.Respuesta.SetErrorDb(result, metodo, true);

            return response;
        }

        public async Task<IListResponse<Combos>> GetAllOperaciones()
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            IListResponse<Combos> response = new ListResponse<Combos>();
           
                var query = await _dapper.GetAllAsync<Combos>("select * from public.get_all_deparment_operation()", null, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = query.ToList();
           
            
            return response;
        }

        public async Task<IListResponse<Combos>> GetAllOMuncipiosActivos()
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            IListResponse<Combos> response = new ListResponse<Combos>();
           
                var query = await _dapper.GetAllAsync<Combos>("select * from public.get_all_municipalities()", null, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = query.ToList();
            
  
            return response;
        }

        public async Task<IListResponse<DiasTrabajados>> GetAllDiasTrabajados(typeeinout rango)
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            var response = new ListResponse<DiasTrabajados>();

                var query = await _dapper.GetAllAsync<DiasTrabajados>("select * from public.get_all_employee_days_worked_department(@pidt_inicio,@pidt_fin,@pii_department)", new
                {
                    pidt_inicio   = rango.entrada,
                    pidt_fin      = rango.salida,
                    pii_department = rango.id
                }, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = query.ToList();
                      

            return response;
        }

        public async Task<IListResponse<DiasxempleadosOpera>> GetAllDiasTrabajadosOperacion(typeeinout rango)
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            var response = new ListResponse<DiasxempleadosOpera>();
            
                var query = await _dapper.GetAllAsync<DiasxempleadosOpera>("select * from public.get_all_employee_days_worked_grouped_department(@pidt_inicio::date ,@pidt_fin::date,@pii_operacion)", new
                {
                    pidt_inicio   = rango.entrada,
                    pidt_fin      = rango.salida,
                    pii_operacion = rango.id
                }, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = query.ToList();
            

            return response;
        }

        public async Task<IListResponse<DiaFeriado>> GetAllDiasFeriados()
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            var response = new ListResponse<DiaFeriado>();
           
                var query = await _dapper.GetAllAsync<DiaFeriado>("select * from public.getealldiasferiados()", null, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = query.ToList();
           
            
            return response;
        }

        public async Task<IListResponse<DiasTrabajadosAreas>> GetAllMarcadasFacturar(typeeinout rango)
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            var response = new ListResponse<DiasTrabajadosAreas>();
              var query = await _dapper.GetAllAsync<DiasTrabajadosAreas>("select * from public.get_all_marked_billed_client(@pidt_inicio::date,@pidt_fin::date,@pii_operacion)", new
                {
                    pidt_inicio   = rango.entrada,
                    pidt_fin      = rango.salida,
                    pii_operacion = rango.id
                },CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = query.ToList();
                     

            return response;
        }

        public async Task<IListResponse<diasxpagarperiodo>> GetAllDiasxPagar(typeeinout rango)
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            var response = new ListResponse<diasxpagarperiodo>();
            var query = await _dapper.GetAllAsync<diasxpagarperiodo>("select * from public.get_all_employee_sumatory_days_worked_department(@pidt_inicio::date,@pidt_fin::date,@pii_operacion)", new
                {
                    pidt_inicio   = rango.entrada,
                    pidt_fin      = rango.salida,
                    pii_operacion = rango.id
                }, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = query.ToList();           

            return response;
        }

        public async Task<IListResponse<Combos>> GetAllComboNomina()
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            var response = new ListResponse<Combos>();
            var query = await _dapper.GetAllAsync<Combos>("select * from public.get_all_payslip_run_active()", null, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = query.ToList();
            
            return response;
        }

        public async Task<IListResponse<nominatype>> GetAllPagoNomina(int idnomina)
        {
            string metodo = $"Rep_Db_{MethodBase.GetCurrentMethod().Name}";
            var response = new ListResponse<nominatype>();
            
                var query = await _dapper.GetAllAsync<nominatype>("select * from public.get_all_payslip_id_employee(@pii_nomina)", new
                {
                    pii_nomina = idnomina
                }, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = query.ToList();
           
             return response;
        }
    }
}
