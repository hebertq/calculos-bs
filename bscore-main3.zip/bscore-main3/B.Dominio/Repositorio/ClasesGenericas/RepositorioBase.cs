﻿using Core.Interfaces;
using System.Data;
using Utilidades.Interfaces;
using Npgsql;
using NpgsqlTypes;
using static Dapper.SqlMapper;
using System.Text.Json;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace Repositorio.ClasesGenericas
{
    public abstract class RepositorioBase
    {
        protected IUtilidades _Util;
        protected IDapper    _dapper;
        public RepositorioBase(IDapper dapper, IUtilidades util)
        {
            _dapper = dapper;
            _Util   = util;
        }
    }

    public class JsonParameter<T> : ICustomQueryParameter
    {
        private readonly string _value;
        public JsonParameter(T value)
        {
            _value = JsonConvert.SerializeObject(value);
        }
        public void AddParameter(IDbCommand command, string name)
        {
            var parameter = new NpgsqlParameter(name, NpgsqlDbType.Jsonb);
            parameter.Value = _value;

            command.Parameters.Add(parameter);
        }
    }
}
