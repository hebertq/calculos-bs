﻿using Modelo.ClasesGenericas;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Repositorio.Interfaces
{
    public interface IOdooRepositorio
    {
        Task<IListResponse<Combos>> GetAllEmpleados();    
        Task<IResponse> Crudferiado(DiaFeriado param, int op);        
        Task<IResponse> AddAllMarcadas(List<HoraEntrada> param, int operacion);      
        Task<ISingleResponse<DiasTrabajados>> AddMarcadasId(DiasTrabajados param, int operacion);       
        Task<ISingleResponse<DiasTrabajados>> GetMarcadaId(int idmarcada);        
        Task<IResponse> CerrarNominaActivas(int operacion);        
        Task<IResponse> CrearNomina(SolicitarNomina nomina);      
        Task<IListResponse<Combos>> GetAllOperaciones();      
        Task<IListResponse<Combos>> GetAllOMuncipiosActivos();       
        Task<IListResponse<DiasTrabajados>> GetAllDiasTrabajados(typeeinout rango);      
        Task<IListResponse<DiasxempleadosOpera>> GetAllDiasTrabajadosOperacion(typeeinout rango);
        Task<IListResponse<DiaFeriado>> GetAllDiasFeriados();      
        Task<IListResponse<DiasTrabajadosAreas>> GetAllMarcadasFacturar(typeeinout rango);      
        Task<IListResponse<diasxpagarperiodo>> GetAllDiasxPagar(typeeinout rango);
        Task<IListResponse<Combos>> GetAllComboNomina();
        Task<IListResponse<nominatype>> GetAllPagoNomina(int idnomina);
        Task<IListResponse<EmpleadosActivos>> GetAllEmpleadosActivos();
    }
}
