﻿
using System;

namespace Modelo.Entidades.Entradas.Odoo
{
    public class HoraEntrada
    {
        public HoraEntrada()
        {
            id = 0;
            nombre = string.Empty;
        }
        public int id { set; get; }
        public string entrada { set; get; }
        public string salida { set; get; }
        public string fecha { set; get; }
        public string nombre { set; get; }
        public double bono { set; get; } = 0;
        public double almuerzocena { set; get; } = 0;

        public string entradastr
        {
            get
            {
                return fecha + " " + entrada;
            }
        }
        public string salidastr
        {
            get
            {
                return fecha + " " + salida;
            }
        }
    }

    public class EntradaSalidacsv
    {
        public EntradaSalidacsv()
        {
            id = 0;
        }
        public int id { set; get; }
        public DateTime entradasalida { set; get; }
        public string fecha { set; get; }
        public bool entrada { set; get; } = false;
        public bool salida { set; get; } = false;
    }
}
