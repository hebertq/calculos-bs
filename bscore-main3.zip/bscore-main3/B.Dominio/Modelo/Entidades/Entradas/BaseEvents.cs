﻿using Modelo.ClasesGenericas;
using Modelo.Validaciones;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Modelo.Entidades.Entradas
{
    public abstract class BaseEvents
    {
        [JsonIgnore]
        public string evento { set; get; } = string.Empty;
        [JsonIgnore]
        public Bancos pais { set; get; } = Bancos.BLNI;
        [JsonIgnore]
        public TipoServicio servicio { set; get; } = TipoServicio.CMN;
        public string usuario { set; get; } = string.Empty;
        public string casenumber { set; get; } = "000000000";
        public int caseid { set; get; } = 0;

        [JsonIgnore]
        public int noreg { set; get; } = 0;
        [JsonIgnore]
        public byte[] jobdata { set; get; }

        public TipoServicio getServicio()
        {
            string strservicio = Enum.GetNames(typeof(TipoServicio)).Where(x => evento.Contains(x)).First();
            return Enum.Parse<TipoServicio>(strservicio);
        }

        public Bancos getBanco()
        {
            string strbanco = Enum.GetNames(typeof(Bancos)).Where(x => evento.Contains(x)).First();
            return Enum.Parse<Bancos>(strbanco);
        }
    }

    public class SendEvent : BaseEvents { }
    public abstract class ListBaseEventsTrgg<TModel> : BaseEvents where TModel : new()
    {
        public List<TModel> Model { get; set; } = new List<TModel>();
        public void setJobData()
        {
            string data = JsonConvert.SerializeObject(Model);
            byte[] bytes = Encoding.ASCII.GetBytes(data);
            noreg = Model.Count;
            jobdata = bytes;
        }
        public void setRemoveData()
        {
            Model.RemoveAt(0);
        }
        public void setDataConfig() { }
    }

    public abstract class SingleBaseEventsTrgg<TModel> : BaseEvents where TModel : new()
    {
        public TModel Model { get; set; } = new TModel();
        public void setJobData()
        {
            string data = JsonConvert.SerializeObject(Model);
            byte[] bytes = Encoding.ASCII.GetBytes(data);
            noreg = 1;
            jobdata = bytes;
        }
    }

    public class requestEventsRules : BaseValidationRuleSet<BaseEvents>
    {
        public requestEventsRules(BaseEvents arg)
        {
            BusinessObject = arg;
            ValidateRequired("casenumber", "Número del caso");
            ValidateRequired("caseid", "El identificador del caso");
        }
    }
}
