﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Entidades.Entradas
{
    public class GenericEvents
    {
        public string Pais { set; get; }
        public string Evento { set; get; }
    }
}
