﻿namespace Modelo.ClasesGenericas
{
    public enum MotivosCalCRC:int
    {
         MAN    = 1,
         RAU    = 2,
         CLIVIN = 3,
         PEPFDP = 4,
         PEPDDP = 5,
         PNP    = 7,
         FAC    = 8
    }
}
