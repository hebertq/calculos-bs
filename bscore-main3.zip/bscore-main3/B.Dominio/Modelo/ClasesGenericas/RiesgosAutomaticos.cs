﻿namespace Modelo.ClasesGenericas
{
    public static class RiesgosAutomaticos
    {
        public static string SinRiesgoAutomatico = "999";
        public static string FideicomisoTenedoraAcciones = "014";
        public static string FamiliarCercanoPep = "058";
        public static string AsociadoPep = "059";
    }

    public static class TipoClientes
    {
        public static string Fideicomiso = "00060";

    }
    public static class Paises
    {
        public static string Nicaragua = "NIC";
    }
}
