﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.ClasesGenericas
{
    public class ParentData
    {
        public int Id { get; set; } = 0;
        public string Combo { get; set; }
    }
}
