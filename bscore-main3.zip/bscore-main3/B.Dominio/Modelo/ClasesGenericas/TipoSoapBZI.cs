﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.ClasesGenericas
{
    public enum TipoSoapBZI
    {
        SetEvent = 1,
        SaveActivity = 2,
        SaveEntity = 3
    }
}
