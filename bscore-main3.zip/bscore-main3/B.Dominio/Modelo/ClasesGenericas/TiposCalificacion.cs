﻿
namespace Modelo.ClasesGenericas
{
    public enum TiposCalificacion
    {

        RiesgoAlto  = 3,   //Prepago y prepago regalo , BackToBack , Tarjetas Prepagos, Fideicomiso
        RiesgoMedio = 2,
        RiesgoBajo  = 1,  //Leasing,TarjetasCredito, Prestamos , Certificados de Depósito a Plazo Fijo / Certicash Préstamos (consumo, maestrías, súper nómina,
                        //auto plan, crédito universal, hipotecarios, comerciales, líneas de crédito, garantías, factoring)
    }
}
