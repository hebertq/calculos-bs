﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.ClasesGenericas
{
    public enum TipoEvento:int
    {
        Proceamiento = 1,
        Reporteria = 2,
        Avance_Casos = 3,
        Envio_Subcriptor = 4
    }
}
