﻿
namespace Modelo.ClasesGenericas
{
    public enum TipoDB
    {
        ///<summary>
        /// Contexto para SQLDB
        /// </summary>
        SQLDB,
        ///<summary>
        /// Contexto para DB2
        /// </summary>
        DB2DB,
        /// <summary>
        /// Contexto para PostgreSql
        /// </summary>
        NPGDB
    }
}
