﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.ClasesGenericas
{
    public enum TipoServicio
    {
        CMN  = 1,
        ACN  = 2,
        ACJ  = 3,
        EMI  = 4,
        CSBI = 5,
        MNGR = 6
    }
}
