﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Modelo.Admin
{
    public class JWTSettings
    {
        public string SecretKey { get; set; }
    }
}
