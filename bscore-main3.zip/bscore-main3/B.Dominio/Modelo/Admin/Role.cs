﻿using System;
using System.Collections.Generic;

namespace Modelo.Admin
{
    public class Role
    {
        public short RoleId { get; set; }
        public string RoleDesc { get; set; }
    }
}
