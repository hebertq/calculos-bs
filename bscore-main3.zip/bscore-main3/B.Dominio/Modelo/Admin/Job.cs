﻿using System;
using System.Collections.Generic;

namespace Modelo.Admin
{
    public class Job
    {
        public short JobId { get; set; }
        public string JobDesc { get; set; }
    }
}
