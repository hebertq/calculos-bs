﻿using ApplicationWeb.Features.Odoo.Commands;
using MediatR;
using Modelo.Interfaces;
using HostService.Interfaces;

namespace ApplicationWeb.Features.Odoo.Handlers.Write
{
    public class AddAllMarcadasHandler : IRequestHandler<AddAllMarcadasCommand, IResponse>
    {
        private readonly IOdooService _Odo;
        public AddAllMarcadasHandler(IOdooService adm) { _Odo = adm; }
        public async Task<IResponse> Handle(AddAllMarcadasCommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(await _Odo.AddAllMarcadas(request.model,request.operacion));
        }
    }
}
