﻿using MediatR;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Interfaces;

namespace ApplicationWeb.Features.Odoo.Queries
{
    public record GetAllDiasxPagarQuery(typeeinout model) : IRequest<IListResponse<diasxpagarperiodo>>;
}
