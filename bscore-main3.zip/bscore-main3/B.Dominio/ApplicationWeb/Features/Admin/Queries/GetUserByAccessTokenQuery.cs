﻿using MediatR;
using Modelo.Admin;
using Modelo.Interfaces;


namespace ApplicationWeb.Features.Admin.Queries
{
    public record GetUserByAccessTokenQuery(RefreshRequest model) : IRequest<ISingleResponse<User>>;
}
