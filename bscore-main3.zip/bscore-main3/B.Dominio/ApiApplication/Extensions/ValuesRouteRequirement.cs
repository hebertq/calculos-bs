﻿using Microsoft.AspNetCore.Authorization;

namespace ApiApplication.Extensions
{
    public class ValuesRouteRequirement : IAuthorizationRequirement { }
}
