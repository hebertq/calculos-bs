﻿using Microsoft.AspNetCore.Http;
using Modelo.Salida;
using System.Net;
using Microsoft.AspNetCore.Builder;
using Modelo.Exceptions;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Modelo.Interfaces;

namespace ApiApplication.Middleware
{
    public class ErrorHandlerMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly JsonSerializerSettings _jsonSettings;
        private readonly IUserInfo _IUser;
        public ErrorHandlerMiddleware(RequestDelegate next,IUserInfo user)
        {
            _next = next;
            _IUser = user;

            _jsonSettings = new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                Formatting = Formatting.Indented,
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                NullValueHandling = NullValueHandling.Ignore
            };
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception error)
            {
                Guid id = Guid.NewGuid();
                var response = context.Response;
                response.ContentType = "application/json";
                var ErrObbj = new LogDbError();
                string MsjError = string.Format("Estimado usuario, ha ocurrido un error interno,{0}:",
                                       Environment.NewLine + "por favor contacte con el administrador del sistema" + System.Environment.NewLine);
                object salida = null;

                if (context.Response.HasStarted)
                {
                    throw;
                }
                switch (error)
                {
                    case RulesException ex:
                        response.StatusCode = (int)HttpStatusCode.BadRequest;
                        var modelState = new ModelStateDictionary();
                        ex.AddModelStateErrors(modelState);
                        var json = JsonConvert.SerializeObject(modelState.Errors(true), _jsonSettings);
                        var daer = JsonConvert.DeserializeObject<List<ErrorInfo>>(json.ToString(), _jsonSettings);
                        MsjError += string.Format("Status: {0}{1}", HttpStatusCode.BadRequest.ToString() + System.Environment.NewLine, "Tipo de excepción: " + System.Environment.NewLine);
                        foreach (var item in daer)
                        {
                            if (item.Key == "request")
                            {
                                MsjError += string.Format("{0}: {1}", item.Key, "Error al serializar los datos enviados." + System.Environment.NewLine);
                                ErrObbj.Request = item.Value;
                            }
                            else if (item.Key == "salida")
                                salida = item.Value;
                            else
                            {
                                string valor = item.Value.ToString().Replace("[", "").Replace("]", "").Replace("\x022", "").Replace("\r\n", "").Trim();
                                MsjError += string.Format("{0}: {1}", item.Key, valor + System.Environment.NewLine);
                            }
                        }
                        break;
                    case CustomMessageException ex:
                        response.StatusCode = (int)HttpStatusCode.InternalServerError;
                        MsjError += string.Format("Status: {0}{1}{2}", HttpStatusCode.InternalServerError.ToString() + System.Environment.NewLine,
                                    "Tipo de excepción: " + System.Environment.NewLine,
                                    "Error: " + ex.ExceptionMessage + System.Environment.NewLine);

                        break;
                    case UnauthorizedAccessException ex:
                        response.StatusCode = (int)HttpStatusCode.Unauthorized;
                        MsjError += string.Format("Status: {0}{1}{}", HttpStatusCode.InternalServerError.ToString() + System.Environment.NewLine,
                                    "Tipo de excepción: " + System.Environment.NewLine,
                                    "Error: " + ex.Message + System.Environment.NewLine);
                        break;

                    case CustomException ex:
                        response.StatusCode = (int)HttpStatusCode.BadRequest;
                        MsjError += string.Format("Status: {0}{1}{2}", HttpStatusCode.InternalServerError.ToString() + System.Environment.NewLine,
                                    "Tipo de excepción: " + System.Environment.NewLine,
                                    "Error: " + ex.Message + System.Environment.NewLine);
                        break;

                    case NotFoundException ex:
                        response.StatusCode = (int)HttpStatusCode.NotFound;
                        MsjError += string.Format("Status: {0}{1}{2}", HttpStatusCode.InternalServerError.ToString() + System.Environment.NewLine,
                                    "Tipo de excepción: " + System.Environment.NewLine,
                                    "Error: " + ex.Message + System.Environment.NewLine);
                        break;
                    default:
                        response.StatusCode = (int)HttpStatusCode.InternalServerError;
                        MsjError += string.Format("Status: {0}{1}{2}", HttpStatusCode.InternalServerError.ToString() + System.Environment.NewLine,
                                    "Tipo de excepción: " + System.Environment.NewLine,
                                    "Error: " + error.Message + System.Environment.NewLine);
                        break;
                }


                string NoLog = "LOG";
                if (string.IsNullOrEmpty(_IUser.UserName))
                {
                    Random generator = new Random();
                    int r = generator.Next(100000, 1000000);
                    NoLog += r.ToString();
                }
                else
                {
                    NoLog = _IUser.UserName;
                }

                MsjError += string.Format("Origen del error: {0}NoLog: {1} Fecha: {2}",
                                          error.TargetSite.ReflectedType.FullName + System.Environment.NewLine,
                                          NoLog,
                                          DateTime.Now);

                var responsedata = new ResponseData(id, response.StatusCode, "Excepción controlada", MsjError, salida);
                var result       = JsonConvert.SerializeObject(responsedata, _jsonSettings);

                ErrObbj.ErrorType    = response.StatusCode.ToString();
                ErrObbj.ErrorMessage = MsjError;
                ErrObbj.ErrorTrace   = error.StackTrace;

                //_logger.LogError(NoLog, $"ErrorHandlerMiddleware: {response.StatusCode} ", "Excepción controlada", JsonConvert.SerializeObject(ErrObbj), error);
                await response.WriteAsync(result);
            }
        }
    }

    public static class CustomExceptionMiddlewareExtensions
    {
        public static IApplicationBuilder UseCustomExceptiontusMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ErrorHandlerMiddleware>();
        }
    }

    public class LogDbError
    {
        public string ErrorType { get; set; }
        public string ErrorMessage { get; set; } = string.Empty;
        public string ErrorTrace { get; set; } = string.Empty;
        public object Request { set; get; }

        public void SetError(string typeerr, string errmsj, string eerrtrace, object rquest = null)
        {
            ErrorType = typeerr;
            ErrorTrace = typeerr;
            ErrorMessage = eerrtrace;
            Request = Request;
        }
    }

    public class ErrorInfo
    {
        public string Key { set; get; }
        public object Value { set; get; }
    }
}

