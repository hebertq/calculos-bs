﻿using MediatR;
using Modelo.Interfaces;

namespace ApiApplication.Features.Odoo.Commands
{
    public record CerrarNominaActivasCommand(int model) : IRequest<IResponse>;
}
