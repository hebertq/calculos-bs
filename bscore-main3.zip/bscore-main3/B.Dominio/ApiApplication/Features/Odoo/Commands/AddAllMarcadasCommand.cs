﻿using MediatR;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Interfaces;

namespace ApiApplication.Features.Odoo.Commands
{
    public record AddAllMarcadasCommand(List<HoraEntrada> model,int operacion) : IRequest<IResponse>;
}
