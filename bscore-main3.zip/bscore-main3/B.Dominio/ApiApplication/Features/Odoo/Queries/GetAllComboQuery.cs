﻿using MediatR;
using Modelo.ClasesGenericas;
using Modelo.Interfaces;

namespace ApiApplication.Features.Odoo.Queries
{
    public record GetAllComboQuery(string model) : IRequest<IListResponse<Combos>>;
}
