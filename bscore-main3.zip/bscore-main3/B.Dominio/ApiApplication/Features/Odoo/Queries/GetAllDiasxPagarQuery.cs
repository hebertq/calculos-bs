﻿using MediatR;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Interfaces;

namespace ApiApplication.Features.Odoo.Queries
{
    public record GetAllDiasxPagarQuery(typeeinout model) : IRequest<IListResponse<diasxpagarperiodo>>;
}
