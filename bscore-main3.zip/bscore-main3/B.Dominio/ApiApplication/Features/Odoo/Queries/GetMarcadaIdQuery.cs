﻿using MediatR;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Interfaces;


namespace ApiApplication.Features.Odoo.Queries
{
    public record GetMarcadaIdQuery(int model) : IRequest<ISingleResponse<DiasTrabajados>>;
}
