﻿using ApiApplication.Features.Odoo.Queries;
using MediatR;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Interfaces;
using Repositorio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiApplication.Features.Odoo.Handlers.Read
{
    public class GetAllDiasFeriadosHandler : IRequestHandler<GetAllDiasFeriadosQuery, IListResponse<DiaFeriado>>
    {
        private readonly IOdooRepositorio _Odo;
        public GetAllDiasFeriadosHandler(IOdooRepositorio adm) { _Odo = adm; }
        public async Task<IListResponse<DiaFeriado>> Handle(GetAllDiasFeriadosQuery request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(await _Odo.GetAllDiasFeriados());
        }
    }
}
