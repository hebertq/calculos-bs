﻿using ApiApplication.Features.Odoo.Queries;
using MediatR;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Interfaces;
using Repositorio.Interfaces;


namespace ApiApplication.Features.Odoo.Handlers.Read
{
    public class GetAllMarcadasFacturarHandler : IRequestHandler<GetAllMarcadasFacturarQuery, IListResponse<DiasTrabajadosAreas>>
    {
        private readonly IOdooRepositorio _Odo;
        public GetAllMarcadasFacturarHandler(IOdooRepositorio adm) { _Odo = adm; }
        public async Task<IListResponse<DiasTrabajadosAreas>> Handle(GetAllMarcadasFacturarQuery request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(await _Odo.GetAllMarcadasFacturar(request.model));
        }
    }
}
