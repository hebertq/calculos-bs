﻿using ApiApplication.Features.Odoo.Queries;
using MediatR;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Interfaces;
using Repositorio.Interfaces;


namespace ApiApplication.Features.Odoo.Handlers.Read
{
    public class GetMarcadaIdHandler : IRequestHandler<GetMarcadaIdQuery, ISingleResponse<DiasTrabajados>>
    {
        private readonly IOdooRepositorio _Odo;
        public GetMarcadaIdHandler(IOdooRepositorio adm) { _Odo = adm; }
        public async Task<ISingleResponse<DiasTrabajados>> Handle(GetMarcadaIdQuery request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(await _Odo.GetMarcadaId(request.model));
        }
    }
}
