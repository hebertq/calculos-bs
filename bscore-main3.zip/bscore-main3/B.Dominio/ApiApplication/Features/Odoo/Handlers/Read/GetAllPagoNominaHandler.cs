﻿using ApiApplication.Features.Odoo.Queries;
using MediatR;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Interfaces;
using Repositorio.Interfaces;


namespace ApiApplication.Features.Odoo.Handlers.Read
{
    public class GetAllPagoNominaHandler : IRequestHandler<GetAllPagoNominaQuery, IListResponse<nominatype>>
    {
        private readonly IOdooRepositorio _Odo;
        public GetAllPagoNominaHandler(IOdooRepositorio adm) { _Odo = adm; }
        public async Task<IListResponse<nominatype>> Handle(GetAllPagoNominaQuery request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(await _Odo.GetAllPagoNomina(request.model));
        }
    }
}
