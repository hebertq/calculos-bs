﻿using ApiApplication.Features.Odoo.Queries;
using MediatR;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Interfaces;
using Repositorio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiApplication.Features.Odoo.Handlers.Read
{
    public class GetAllDiasTrabajadosHandler : IRequestHandler<GetAllDiasTrabajadosQuery, IListResponse<DiasTrabajados>>
    {
        private readonly IOdooRepositorio _Odo;
        public GetAllDiasTrabajadosHandler(IOdooRepositorio adm) { _Odo = adm; }
        public async Task<IListResponse<DiasTrabajados>> Handle(GetAllDiasTrabajadosQuery request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(await _Odo.GetAllDiasTrabajados(request.model));
        }
    }
}
