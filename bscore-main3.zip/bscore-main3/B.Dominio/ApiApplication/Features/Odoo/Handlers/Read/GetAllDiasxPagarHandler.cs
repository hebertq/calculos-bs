﻿using ApiApplication.Features.Odoo.Queries;
using MediatR;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Interfaces;
using Repositorio.Interfaces;

namespace ApiApplication.Features.Odoo.Handlers.Read
{
    public class GetAllDiasxPagarHandler : IRequestHandler<GetAllDiasxPagarQuery, IListResponse<diasxpagarperiodo>>
    {
        private readonly IOdooRepositorio _Odo;
        public GetAllDiasxPagarHandler(IOdooRepositorio adm) { _Odo = adm; }
        public async Task<IListResponse<diasxpagarperiodo>> Handle(GetAllDiasxPagarQuery request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(await _Odo.GetAllDiasxPagar(request.model));
        }
    }
}
