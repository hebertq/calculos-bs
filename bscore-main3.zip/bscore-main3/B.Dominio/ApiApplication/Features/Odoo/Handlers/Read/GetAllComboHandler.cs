﻿using ApiApplication.Features.Odoo.Queries;
using MediatR;
using Modelo.ClasesGenericas;
using Modelo.Interfaces;
using Repositorio.Interfaces;

namespace ApiApplication.Features.Odoo.Handlers.Read
{
    public class GetAllComboHandler : IRequestHandler<GetAllComboQuery, IListResponse<Combos>>
    {
        private readonly IOdooRepositorio _Odoo;
        public GetAllComboHandler(IOdooRepositorio odo) { _Odoo = odo; }
        public async Task<IListResponse<Combos>> Handle(GetAllComboQuery request, CancellationToken cancellationToken)
        {
            IListResponse<Combos> response = new ListResponse<Combos>();
            response = request.model switch
            {
                "Nominas"     => await _Odoo.GetAllComboNomina(),
                "Empleados"   => await _Odoo.GetAllEmpleados(),
                "Municipios"  => await _Odoo.GetAllOMuncipiosActivos(),
                "Operaciones" => await _Odoo.GetAllOperaciones(),
                _ => throw new NotImplementedException("No existe el catalogo")
            } ;
          
            return await Task.FromResult(response);
        }
    }
}
