﻿using ApiApplication.Features.Odoo.Commands;
using MediatR;
using Modelo.Entidades.Entradas.Odoo;
using Modelo.Interfaces;
using Repositorio.Interfaces;


namespace ApiApplication.Features.Odoo.Handlers.Write
{
    public class AddMarcadasIdHandler : IRequestHandler<AddMarcadasIdCommand, ISingleResponse<DiasTrabajados>>
    {
        private readonly IOdooRepositorio _Odo;
        public AddMarcadasIdHandler(IOdooRepositorio adm) { _Odo = adm; }
        public async Task<ISingleResponse<DiasTrabajados>> Handle(AddMarcadasIdCommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(await _Odo.AddMarcadasId(request.model,request.operacion));
        }
    }
}
