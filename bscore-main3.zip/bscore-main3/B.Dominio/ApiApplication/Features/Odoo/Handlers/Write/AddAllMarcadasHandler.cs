﻿using ApiApplication.Features.Odoo.Commands;
using MediatR;
using Modelo.Interfaces;
using Repositorio.Interfaces;

namespace ApiApplication.Features.Odoo.Handlers.Write
{
    public class AddAllMarcadasHandler : IRequestHandler<AddAllMarcadasCommand, IResponse>
    {
        private readonly IOdooRepositorio _Odo;
        public AddAllMarcadasHandler(IOdooRepositorio adm) { _Odo = adm; }
        public async Task<IResponse> Handle(AddAllMarcadasCommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(await _Odo.AddAllMarcadas(request.model,request.operacion));
        }
    }
}
