﻿using ApiApplication.Features.Odoo.Commands;
using MediatR;
using Modelo.Interfaces;
using Repositorio.Interfaces;


namespace ApiApplication.Features.Odoo.Handlers.Write
{
    public class CrudferiadoHandler : IRequestHandler<CrudferiadoCommand, IResponse>
    {
        private readonly IOdooRepositorio _Odo;
        public CrudferiadoHandler(IOdooRepositorio adm) { _Odo = adm; }
        public async Task<IResponse> Handle(CrudferiadoCommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(await _Odo.Crudferiado(request.model,request.operacion));
        }
    }
}
