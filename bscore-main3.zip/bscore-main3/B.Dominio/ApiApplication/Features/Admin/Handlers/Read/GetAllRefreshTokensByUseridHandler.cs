﻿using ApiApplication.Features.Admin.Queries;
using MediatR;
using Modelo.Admin;
using Modelo.ClasesGenericas;
using Modelo.Interfaces;
using Repositorio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiApplication.Features.Admin.Handlers.Read
{
    public class GetAllRefreshTokensByUseridHandler : IRequestHandler<GetAllRefreshTokensByUseridQuery, IListResponse<RefreshToken>>
    {
        private readonly IAdminRepositorio _Adm;
        public GetAllRefreshTokensByUseridHandler(IAdminRepositorio adm) { _Adm = adm; }
        public async Task<IListResponse<RefreshToken>> Handle(GetAllRefreshTokensByUseridQuery request, CancellationToken cancellationToken)
        {
            IListResponse<RefreshToken> response = new ListResponse<RefreshToken>();
            var fideauto = await _Adm.GetAllRefreshTokensByUserid(request.id);
            if (!fideauto.Respuesta.ExisteError)
            {
                response.Model = fideauto.Model;
            }
            else
                response.Respuesta = fideauto.Respuesta;

            return await Task.FromResult(response);
        }
    }
}
