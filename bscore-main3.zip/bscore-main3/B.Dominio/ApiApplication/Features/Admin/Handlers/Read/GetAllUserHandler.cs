﻿using ApiApplication.Features.Admin.Queries;
using MediatR;
using Modelo.Admin;
using Modelo.ClasesGenericas;
using Modelo.Interfaces;
using Repositorio.Interfaces;

namespace ApiApplication.Features.Admin.Handlers.Read
{
    public class GetAllUserHandler : IRequestHandler<GetAllUserQuery, IListResponse<User>>
    {
        private readonly IAdminRepositorio _Adm;
        public GetAllUserHandler(IAdminRepositorio adm) { _Adm = adm; }
        public async Task<IListResponse<User>> Handle(GetAllUserQuery request, CancellationToken cancellationToken)
        {
            IListResponse<User> response = new ListResponse<User>();
            var fideauto = await _Adm.GetAllUsers();
            if (!fideauto.Respuesta.ExisteError)
            {
                response.Model = fideauto.Model;
            }
            else
                response.Respuesta = fideauto.Respuesta;

            return await Task.FromResult(response);
        }
    }
}
