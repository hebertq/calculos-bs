﻿using AutoMapper;
using PdfReportGenerator.Application.Common.Interfaces;
using PdfReportGenerator.Application.Todo.Commands.v1;
using PdfReportGenerator.Application.Todo.Dto.v1;
using PdfReportGenerator.Domain.Entities.Todos;
using MediatR;

namespace PdfReportGenerator.Application.Todo.Handlers.v1
{
    public class CreateTodoCommandHandler : IRequestHandler<CreateTodoCommand, TodoDto>
    {
        private readonly ITodoService _todoService;
        private readonly IMapper _mapper;

        public CreateTodoCommandHandler(ITodoService todoService, IMapper mapper)
        {
            _todoService = todoService;
            _mapper = mapper;
        }

        public async Task<TodoDto> Handle(CreateTodoCommand request, CancellationToken cancellationToken)
        {
            var response = await _todoService.CreateTodo(_mapper.Map<TodoEntity>(request));

            return _mapper.Map<TodoDto>(response);
        }
    }
}
