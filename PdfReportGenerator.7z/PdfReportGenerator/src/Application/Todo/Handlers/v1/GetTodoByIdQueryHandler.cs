﻿using AutoMapper;
using LAFISE.CrossCutting.Core.Exceptions;
using PdfReportGenerator.Application.Common.Interfaces;
using PdfReportGenerator.Application.Todo.Dto.v1;
using PdfReportGenerator.Application.Todo.Queries.v1;
using MediatR;

namespace PdfReportGenerator.Application.Todo.Handlers.v1
{
    public class GetTodoByIdQueryHandler : IRequestHandler<GetTodoByIdQuery, TodoDto>
    {
        private readonly ITodoService _todoService;
        private readonly IMapper _mapper;
        private readonly IPdfGenerator _report;
        public GetTodoByIdQueryHandler(ITodoService todoService, IMapper mapper, IPdfGenerator report)
        {
            _todoService = todoService;
            _mapper = mapper;
            _report = report;
        }

        public async Task<TodoDto> Handle(GetTodoByIdQuery request, CancellationToken cancellationToken)
        {
            var data = _report.MyPrimerReporte();
            var todo = await _todoService.GetTodoById(request.Id);

            if (todo is null)
                throw new NotFoundException($"The todo with id {request.Id} doesn't exist");

            return _mapper.Map<TodoDto>(todo);
        }
    }
}
