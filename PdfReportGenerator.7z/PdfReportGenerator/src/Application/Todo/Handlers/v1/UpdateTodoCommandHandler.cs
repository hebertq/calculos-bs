﻿using AutoMapper;
using LAFISE.CrossCutting.Core.Exceptions;
using PdfReportGenerator.Application.Common.Interfaces;
using PdfReportGenerator.Application.Todo.Commands.v1;
using PdfReportGenerator.Application.Todo.Dto.v1;
using PdfReportGenerator.Domain.Entities.Todos;
using MediatR;

namespace PdfReportGenerator.Application.Todo.Handlers.v1
{
    public class UpdateTodoCommandHandler : IRequestHandler<UpdateTodoCommand, TodoDto>
    {
        private readonly ITodoService _todoService;
        private readonly IMapper _mapper;

        public UpdateTodoCommandHandler(ITodoService todoService, IMapper mapper)
        {
            _todoService = todoService;
            _mapper = mapper;
        }

        public async Task<TodoDto> Handle(UpdateTodoCommand request, CancellationToken cancellationToken)
        {
            var todoToUpdate = await _todoService.GetTodoById(request.Id);

            if (todoToUpdate is null)
                throw new NotFoundException($"The todo with id {request.Id} doesn't exist");

            var todoUpdated = await _todoService.UpdateTodo(request.Id, _mapper.Map<TodoEntity>(request));

            return _mapper.Map<TodoDto>(todoUpdated);
        }
    }
}
