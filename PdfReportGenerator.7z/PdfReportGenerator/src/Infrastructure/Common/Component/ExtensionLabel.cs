﻿using QuestPDF.Fluent;
using QuestPDF.Infrastructure;

namespace PdfReportGenerator.Infrastructure.Common.Component
{
    public static class ExtensionLabel
    {
        // displays only text label
        public static void LabelCell(this IContainer container, string text,int font = 9) => container.Cell(true).Text(text).FontSize(font);

        // allows you to inject any type of content, e.g. image
        public static void ValueCell(this IContainer container,string text, int font = 9) => container.Cell(false).Text(text).FontSize(font);
    }
}
