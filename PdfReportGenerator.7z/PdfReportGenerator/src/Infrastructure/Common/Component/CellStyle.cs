﻿using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace PdfReportGenerator.Infrastructure.Common.Component
{
    public static class CellStyle
    {
        public static IContainer Cell(this IContainer container, bool dark)
        {
            return container
            .Border(0.5f)
            .BorderColor(Colors.Grey.Medium)
            .Background(dark ? Colors.Grey.Lighten2 : Colors.White)
            .AlignMiddle()
            .AlignCenter()
            .Padding(5);
        }

        // Estilo por defecto para las celdas
        private static IContainer DefaultCellStyleTable(this IContainer container) =>
            container
                .Border(0.5f)
                .BorderColor(Colors.Grey.Medium)
                .Padding(5)
                .AlignCenter()
                .AlignMiddle();

        // Estilo para las celdas del encabezado
        private static IContainer HeaderCellStyleTable(this IContainer container) =>
            container
                .Border(0.5f)
                .BorderColor(Colors.Grey.Darken1)
                .Background(Colors.Grey.Lighten3)
                .Padding(5)
                .AlignCenter()
                .AlignMiddle();

        public static IContainer CellStylHeeaderTable(this IContainer cell) => cell.HeaderCellStyleTable();

        public static IContainer CellStylRowTable(this IContainer cell) => cell.DefaultCellStyleTable();
    }
}
