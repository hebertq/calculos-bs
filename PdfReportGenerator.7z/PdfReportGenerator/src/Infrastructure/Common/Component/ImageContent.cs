﻿using PdfReportGenerator.Infrastructure.Common.Interfaces;
using QuestPDF.Fluent;

namespace PdfReportGenerator.Infrastructure.Common.Component
{
// Clase para manejar imágenes
    public class ImageContent : IContentElement
    {
        private string _imagePath;
        private float _width;
        private float _height;

        public ImageContent(string imagePath, float width = 100, float height = 100)
        {
            _imagePath = imagePath;
            _width = width;
            _height = height;
        }

        public void Render(ColumnDescriptor container)
        {
            container.Item().Width(_width).Height(_height).Image(_imagePath);
        }
    }
}
