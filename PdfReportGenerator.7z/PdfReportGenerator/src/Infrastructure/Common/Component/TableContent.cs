﻿using System.Collections;
using PdfReportGenerator.Infrastructure.Common.Interfaces;
using QuestPDF.Fluent;

namespace PdfReportGenerator.Infrastructure.Common.Component
{
    // Clase para manejar tablas
    public class TableContent<Tmodel> : IContentElement where Tmodel : class
    {
        private readonly Dictionary<string, int>? _headers;
        private readonly bool _automaticheader;
        private readonly bool _tableextend;
        public TableContent(Dictionary<string, int>? headers = null, bool automaticheader = true, bool tableextend = false)
        {
            _headers = headers;
            _automaticheader = automaticheader;
            _tableextend = tableextend;
        }
        public Tmodel? Model { get; set; }

        public List<List<string>>? TableRows { get; set; }

        public void Render(ColumnDescriptor container)
        {
            container.Item().Table(table => CreateTable(table));
        }
        public bool IsList(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            var type = obj.GetType();

            // Verificar si el tipo es una lista genérica
            if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(List<>))
            {
                return true;
            }

            // Verificar si el tipo implementa IList
            return typeof(IList).IsAssignableFrom(type);
        }
        public string FooterTable { set; get; }

        protected virtual void CreaateHeader(TableCellDescriptor header){}

        protected virtual void CreateTableExtend(TableDescriptor table) 
        {
            table.ColumnsDefinition(columns =>
            {
                columns.ConstantColumn(100);
                columns.RelativeColumn();
                columns.ConstantColumn(100);
                columns.RelativeColumn();
            });

            table.ExtendLastCellsToTableBottom();           
        }

        private void CreateTable(TableDescriptor table)
        {          
            if(_tableextend)
            {
                CreateTableExtend(table);
            }
            else
            {
                table.ColumnsDefinition(columns =>
                {
                    foreach (var item in _headers)
                    {
                        if (item.Value == 0)
                            columns.RelativeColumn();
                        else
                            columns.ConstantColumn(item.Value);
                    }
                });

                // Renderizar las cabeceras
                if (_headers != null && _headers.Any())
                {
                    table.Header(header =>
                    {
                        if (_automaticheader)
                        {
                            foreach (var headerText in _headers)
                            {
                                header.Cell()
                                      .RowSpan(2)
                                      .CellStylHeeaderTable()
                                      .ExtendHorizontal()
                                      .AlignCenter()
                                      .Text(headerText.Key)
                                      .FontSize(9);
                            }
                        }
                        else
                            CreaateHeader(header);
                    });
                }

                if(TableRows is not null)
                {
                    //Renderizar las filas                   
                    foreach (var row in TableRows)
                    {
                        foreach (var cellData in row)
                        {
                            table.Cell()
                                .CellStylRowTable()
                                .ExtendHorizontal()
                                .AlignLeft()
                                .Text(cellData)
                                .FontSize(8);
                        }
                    }
                }

            }            
        }
    }
}
