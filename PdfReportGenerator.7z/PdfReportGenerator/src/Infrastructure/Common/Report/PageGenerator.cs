﻿using PdfReportGenerator.Infrastructure.Common.Component;
using PdfReportGenerator.Infrastructure.Common.Interfaces;
using QuestPDF.Fluent;
using QuestPDF.Helpers;

namespace PdfReportGenerator.Infrastructure.Common.Report
{
    public class PageGenerator
    {
        private List<IContentElement> _contentElements = new List<IContentElement>();

        // Método para agregar texto al documento PDF
        public PageGenerator AddText(string text, float fontSize = 12, bool bold = false)
        {
            _contentElements.Add(new TextContent(text, fontSize, bold));
            return this; // Permite el encadenamiento de métodos
        }

        // Método para agregar una tabla al documento PDF
        public PageGenerator AddTable<Tmodel>(Dictionary<string, int> headers, bool automaticheaders = true) where Tmodel : class
        {
            // Si no se proporcionan cabeceras, se pasa una lista vacía o se omiten
            _contentElements.Add(new TableContent<Tmodel>(headers, automaticheaders));
            return this;
        }

        // Método para agregar una tabla al documento PDF
        public PageGenerator AddTable<Tmodel>(TableContent<Tmodel> table) where Tmodel : class
        {
            // Si no se proporcionan cabeceras, se pasa una lista vacía o se omiten
            _contentElements.Add(table);
            return this;
        }

        // Método para agregar una imagen al documento PDF
        public PageGenerator AddImage(string imagePath, int width = 100, int height = 100)
        {
            _contentElements.Add(new ImageContent(imagePath, width, height));
            return this;
        }

        public void CreatePage(PageDescriptor page, PageSize pageSize, HeaderComponent _Header)
        {
            page.Margin(15); // Márgenes
            page.Size(pageSize); // Tamaño de la página
            page.Header().PaddingBottom(20)
            .AlignCenter()
                .AlignMiddle()
                .Component(_Header); // Agregar encabezado

            page.Content().Column(column =>
            {
                // Agregar cada elemento de contenido en la columna
                foreach (var contentElement in _contentElements)
                {
                    contentElement.Render(column);
                }
            });
        }
    }
}
