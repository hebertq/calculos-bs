﻿using System.Reflection.PortableExecutable;
using PdfReportGenerator.Domain.Entities.Nomina;
using PdfReportGenerator.Infrastructure.Common.Component;
using QuestPDF.Fluent;
using QuestPDF.Helpers;

namespace PdfReportGenerator.Infrastructure.Common.Report.Nomina
{
    public class TablaNomina:TableContent<nominaall>
    {
        public TablaNomina(nominaall model, Dictionary<string, int>? headers = null, bool automatic = false, bool tableextend = false) 
            :base(headers, automatic, tableextend)
        {
            //if (model is IList)
            //    TableRows = model.ConvertList();

            Model = model;
        }
        protected override void CreaateHeader(TableCellDescriptor header) 
        {
            // please be sure to call the 'header' handler!
            header.Cell().ColumnSpan(17).LabelCell("Detalle de pago de los empleados",13);
            header.Cell().RowSpan(2).CellStylHeeaderTable().ExtendHorizontal().AlignCenter().Text("Cedula").FontSize(9);
            header.Cell().RowSpan(2).CellStylHeeaderTable().ExtendHorizontal().AlignCenter().Text("Nombre").FontSize(9);

            header.Cell().ColumnSpan(3).CellStylHeeaderTable().Text("Salario Base").FontSize(9);
            header.Cell().ColumnSpan(2).CellStylHeeaderTable().Text("Bono").FontSize(9);
            header.Cell().ColumnSpan(2).CellStylHeeaderTable().Text("Horas Ext").FontSize(9);
            header.Cell().ColumnSpan(2).CellStylHeeaderTable().Text("O Ingreso").FontSize(9);

            header.Cell().RowSpan(2).CellStylHeeaderTable().ExtendHorizontal().AlignCenter().Text("Total Ingresos").FontSize(9);
            header.Cell().ColumnSpan(2).CellStylHeeaderTable().Text("Deducciones").FontSize(9);

            header.Cell().RowSpan(2).CellStylHeeaderTable().ExtendHorizontal().AlignCenter().Text("Total Dedución").FontSize(9);
            header.Cell().RowSpan(2).CellStylHeeaderTable().ExtendHorizontal().AlignCenter().Text("Neto").FontSize(9);
            header.Cell().RowSpan(2).CellStylHeeaderTable().ExtendHorizontal().AlignCenter().Text("Firma").FontSize(9);

            header.Cell().CellStylHeeaderTable().Text("Base").FontSize(9);
            header.Cell().CellStylHeeaderTable().Text("Dias").FontSize(9);
            header.Cell().CellStylHeeaderTable().Text("Basico").FontSize(9);

            header.Cell().CellStylHeeaderTable().Text("Trans").FontSize(9);
            header.Cell().CellStylHeeaderTable().Text("Cump").FontSize(9);

            header.Cell().CellStylHeeaderTable().Text("Cant").FontSize(9);
            header.Cell().CellStylHeeaderTable().Text("Valor").FontSize(9);

            header.Cell().CellStylHeeaderTable().Text("vac").FontSize(9);
            header.Cell().CellStylHeeaderTable().Text("Otros").FontSize(9);           
           
            header.Cell().CellStylHeeaderTable().Text("Inss").FontSize(9);
            header.Cell().CellStylHeeaderTable().Text("Otro").FontSize(9);          
        }

        protected override void CreateTableExtend(TableDescriptor table)
        {
            table.ColumnsDefinition(columns =>
            {
                columns.ConstantColumn(100);
                columns.RelativeColumn();
                columns.ConstantColumn(100);
                columns.RelativeColumn();
            });

            table.ExtendLastCellsToTableBottom();
            table.Cell().ColumnSpan(4).LabelCell("Detalle de pago de los empleados", 13);
            table.Cell().LabelCell("Report number1");
            table.Cell().ValueCell(Placeholders.Paragraph());

            table.Cell().LabelCell("Date1");
            table.Cell().ValueCell(Placeholders.ShortDate());

            table.Cell().LabelCell("Inspector1");
            table.Cell().ValueCell("Marcin Ziąbek");

            table.Cell().LabelCell("Report number2");
            table.Cell().ValueCell(Placeholders.Paragraph());

            table.Cell().LabelCell("Date2");
            table.Cell().ValueCell(Placeholders.ShortDate());

            table.Cell().LabelCell("Inspector2");
            table.Cell().ValueCell("Marcin Ziąbek");

            table.Cell().ColumnSpan(2).LabelCell("Morning weather");
            table.Cell().ColumnSpan(2).LabelCell("Evening weather");

            table.Cell().ValueCell("Time");
            table.Cell().ValueCell("7:13");

            table.Cell().ValueCell("Time");
            table.Cell().ValueCell("18:25");

            table.Cell().ValueCell("Description");
            table.Cell().ValueCell("Sunny");

            table.Cell().ValueCell("Description");
            table.Cell().ValueCell("Windy");

            table.Cell().ValueCell("Wind");
            table.Cell().ValueCell("Mild");

            table.Cell().ValueCell("Wind");
            table.Cell().ValueCell("Strong");

            table.Cell().ValueCell("Temperature");
            table.Cell().ValueCell("17°C");

            table.Cell().ValueCell("Temperature");
            table.Cell().ValueCell("32°C");

            table.Cell().LabelCell("Remarks");
            table.Cell().ColumnSpan(3).ValueCell(Placeholders.Paragraph());

        }
    }
}
