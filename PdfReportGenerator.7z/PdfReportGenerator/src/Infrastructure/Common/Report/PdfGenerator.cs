﻿using PdfReportGenerator.Infrastructure.Common.Component;
using QuestPDF.Fluent;
using QuestPDF.Helpers;

namespace PdfReportGenerator.Infrastructure.Common.Report
{
    public class PdfGenerator
    {
        private string? _title;
        private string? _name;
        private string? _detail;
        private string? _type;
        private string? _pathimage;

        // Constructor para inicializar los parámetros y la lista de elementos de contenido
        public PdfGenerator(string title, string? name = null, string? detail = null, string? type = null, string? pathimage = null)
        {
            _title = title ?? throw new ArgumentNullException(nameof(title), "Title cannot be null.");
            _name = name;
            _detail = detail;
            _type = type;
            _pathimage = pathimage;
        }
    
        public List<PageGenerator> PagesArray { set; get; } = [];
        // Método para generar el PDF
        public byte[]? GeneratePdf(PageSize pageSize)
        {
            // Crear el componente de encabezado
            var _Header = new HeaderComponent(_title, _name, _detail, _type, _pathimage);

            if (PagesArray.Count == 0)
                return null;

            // Crear el documento PDF
            var document = Document.Create(container =>
            {
                foreach (var pageItem in PagesArray)
                {
                    container
                    .Page(page => pageItem.CreatePage(page, pageSize, _Header));
                }                
            });

            // Generar el PDF y devolverlo como un arreglo de bytes
            return document.GeneratePdf();
        }
    }
}
