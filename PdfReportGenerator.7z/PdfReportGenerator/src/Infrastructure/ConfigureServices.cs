﻿using PdfReportGenerator.Application.Common.Interfaces;
using PdfReportGenerator.Infrastructure.Services;
using Microsoft.Extensions.Configuration;

namespace Microsoft.Extensions.DependencyInjection
{
public static class ConfigureServices
{
public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
{
services.AddSingleton<ITodoService, TodoService>();
services.AddSingleton<IPdfGenerator, ReportService>();

return services;
}
}
}
