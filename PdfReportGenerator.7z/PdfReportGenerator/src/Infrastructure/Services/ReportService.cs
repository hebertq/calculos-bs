﻿using PdfReportGenerator.Application.Common.Interfaces;
using PdfReportGenerator.Infrastructure.Common.Report.Nomina;
using QuestPDF.Infrastructure;

namespace PdfReportGenerator.Infrastructure.Services
{
    public class ReportService: IPdfGenerator
    {
        public ReportService() 
        {
            QuestPDF.Settings.License = LicenseType.Community;
        }
        public string MyPrimerReporte()
        {
            return NominaMensual.GenerarReporte();
        }
    }
}
