﻿using System.Reflection;

namespace PdfReportGenerator.Domain.Extensions
{
    public static class ListaConverterExtension
    {
        /// <summary>
        /// Convierte una lista de objetos a una lista de listas de cadenas.
        /// </summary>
        /// <typeparam name="T">Tipo de los objetos en la lista.</typeparam>
        /// <param name="inputList">Lista de objetos a convertir.</param>
        /// <returns>Lista de listas de cadenas representando las propiedades de los objetos.</returns>
        public static List<List<string>> ConvertList<T>(this List<T> inputList)
        {
            if (inputList == null || !inputList.Any())
                return new List<List<string>>();

            // Obtén las propiedades públicas del tipo T
            var propiedades = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            return inputList.Select(item =>
            {
                // Convierte las propiedades del objeto actual a cadenas
                return propiedades.Select(prop =>
                {
                    var valor = prop.GetValue(item); // Obtiene el valor de la propiedad
                    return valor?.ToString() ?? string.Empty; // Convierte a cadena o usa cadena vacía si es nulo
                }).ToList();
            }).ToList();
        }
    }
}
