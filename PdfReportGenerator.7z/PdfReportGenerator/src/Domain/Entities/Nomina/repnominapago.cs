﻿namespace PdfReportGenerator.Domain.Entities.Nomina
{
    public class repnominapago
    {
        public string fecha_ini { set; get; }
        public string fecha_fin { set; get; }
        public List<nominaall> nominatotal { set; get; }
        public List<nominaalltarjeta> desglocetarjeta { set; get; }
        public List<nominadesgefectivo> desgloceefectivo { set; get; }
        public string titulo { set; get; }
    }
}
