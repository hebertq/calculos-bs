﻿namespace PdfReportGenerator.Domain.Entities.Todos
{
    public class TodoEntity
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public float Version { get; set; }
    }
}
