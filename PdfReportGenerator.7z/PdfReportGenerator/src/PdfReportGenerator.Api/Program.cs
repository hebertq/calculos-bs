﻿using PdfReportGenerator.Api;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Rewrite;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

// Add AWS Lambda support. When application is run in Lambda Kestrel is swapped out as the web server with Amazon.Lambda.AspNetCoreServer. This
// package will act as the webserver translating request and responses between the Lambda event source and ASP.NET Core.
builder.Services.AddAWSLambdaHosting(LambdaEventSource.RestApi);

builder.Services.AddApplicationServices();
builder.Services.AddInfrastructureServices(builder.Configuration);
builder.Services.AddApiServices();
builder.Services.AddAutoMapper(typeof(Program));

var app = builder.Build();
var env = builder.Environment;
var provider = app.Services.GetRequiredService<IApiVersionDescriptionProvider>();

app.UseHealthChecks("/health");
app.UseHttpsRedirection();

app.UseSwagger(settings =>
{
    settings.RouteTemplate = "swagger/{documentName}/swagger.json";
});

app.UseSwaggerUI(settings =>
{
    foreach (var description in provider.ApiVersionDescriptions.Select(des => des.GroupName)
                 .Where(des => des is not null))
    {
        settings.SwaggerEndpoint(
            $"{description}/swagger.json",
            description.ToUpperInvariant());
    }

    settings.RoutePrefix = "swagger";
});

app.UseRouting();

var option = new RewriteOptions();
option.AddRedirect("^$", "swagger");
app.UseRewriter(option);

app.UseXRay("PdfReportGenerator");

app.UseEndpoints(endpoints =>
{
    if (env.IsDevelopment())
    {
        endpoints.MapControllers().WithMetadata(new AllowAnonymousAttribute());
    }
    else
    {
        endpoints.MapControllers();
    }
});

app.Run();

/// <summary>
/// Class type program for testing
/// </summary>
public partial class Program { }
