﻿namespace PdfReportGenerator.Api.IntegrationTests
{
    public static class UrlHelpers
    {
        public static string ToRequestUrl(this string resource, int version = 1) => $"api/v{version}/{resource}";
    }
}
