﻿using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Text.Json.Serialization;
using LAFISE.CrossCutting.Core.Entities.Rest;
using LAFISE.CrossCutting.Rest;
using LAFISE.CrossCutting.Rest.Interfaces;
using Microsoft.Extensions.Logging;
using RestSharp;
using Yoh.Text.Json.NamingPolicies;

namespace PdfReportGenerator.Api.IntegrationTests
{
    public class TestRestApiService<TError>
        : RestApiService<TError> where TError : class
    {
        public TestRestApiService(
            HttpClient httpClient,
            ILogger<RestApiService<TError>> logger,
            IRestApiErrorHandler<TError> restApiErrorHandler) : base(httpClient, logger, restApiErrorHandler)
        {
            // TODO: customize serializer options here
            SerializerOptions.PropertyNamingPolicy = JsonNamingPolicies.SnakeCaseLower;
            SerializerOptions.IncludeFields = true;
            SerializerOptions.Converters.Add(new JsonStringEnumConverter());
        }

        public new Task<Result<T, TError>> GetRequest<T>(RestRequest request,
            [CallerMemberName] string callerMemberName = "")
            where T : class
        {
            return base.GetRequest<T>(request, callerMemberName);
        }

        public new Task<Result<string, TError>> GetRequest(RestRequest request,
            [CallerMemberName] string callerMemberName = "")
        {
            return base.GetRequest(request, callerMemberName);
        }

        public new Task<Result<T, TError>> PostRequest<T>(RestRequest request,
            [CallerMemberName] string callerMemberName = "")
            where T : class
        {
            return base.PostRequest<T>(request, callerMemberName);
        }

        public new Task<Result<string, TError>> PostRequest(RestRequest request,
            [CallerMemberName] string callerMemberName = "")
        {
            return base.PostRequest(request, callerMemberName);
        }

        public new Task<Result<T, TError>> PutRequest<T>(RestRequest request,
            [CallerMemberName] string callerMemberName = "")
            where T : class
        {
            return base.PutRequest<T>(request, callerMemberName);
        }

        public new Task<Result<string, TError>> PutRequest(RestRequest request,
            [CallerMemberName] string callerMemberName = "")
        {
            return base.PutRequest(request, callerMemberName);
        }

        public new Task<Result<T, TError>> PatchRequest<T>(RestRequest request,
            [CallerMemberName] string callerMemberName = "")
            where T : class
        {
            return base.PatchRequest<T>(request, callerMemberName);
        }

        public new Task<Result<string, TError>> PatchRequest(RestRequest request,
            [CallerMemberName] string callerMemberName = "")
        {
            return base.PatchRequest(request, callerMemberName);
        }

        public new Task<Result<T, TError>> DeleteRequest<T>(RestRequest request,
            [CallerMemberName] string callerMemberName = "") where T : class
        {
            return base.DeleteRequest<T>(request, callerMemberName);
        }

        public new Task<Result<string, TError>> DeleteRequest(RestRequest request,
            [CallerMemberName] string callerMemberName = "")
        {
            return base.DeleteRequest(request, callerMemberName);
        }

        public new Task<Result<T, TError>> ExecuteRequest<T>(RestRequest request,
            [CallerMemberName] string callerMemberName = "") where T : class
        {
            return base.ExecuteRequest<T>(request, callerMemberName);
        }

        public new Task<Result<string, TError>> ExecuteRequest(
            RestRequest request,
            [CallerMemberName] string callerMemberName = "")
        {
            return base.ExecuteRequest(request, callerMemberName);
        }
    }

    public class TestRestApiService
        : TestRestApiService<object>
    {
        public TestRestApiService(HttpClient httpClient, ILogger<RestApiService<object>> logger,
            IRestApiErrorHandler<object> restApiErrorHandler) : base(httpClient, logger, restApiErrorHandler)
        {
        }
    }
}
