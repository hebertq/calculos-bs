﻿using Microsoft.Extensions.Logging;
using Polly.Timeout;
using System.Net.Http.Json;
using website.ServiceDefaults.ApiContract;
using website.ServiceDefaults.Interface;

namespace website.ServiceDefaults.Service.Generic
{
    public class ApiClient : IApiClient
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<ApiClient> _logger;

        public ApiClient(HttpClient httpClient, ILogger<ApiClient> logger)
        {
            _httpClient = httpClient;
            _logger = logger;
        }

        // GET Genérico
        public async Task<TResponse?> GetAsync<TResponse>(string endpoint)
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<TResponse>(endpoint);
            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex, endpoint);
                return default;
            }
        }

        public async Task<string?> UploadFileAsync(byte[] fileBytes, string? fileName)
        {
            using var content = new ByteArrayContent(fileBytes);
            content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

            // Redmine espera el nombre del archivo por QueryString en el upload
            var response = await _httpClient.PostAsync($"uploads.json?filename={fileName}", content);

            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<RedmineUploadResponse>();
                return result?.upload?.token;
            }

            return null;
        }

        // POST Genérico que devuelve un objeto (ej: la respuesta de Redmine)
        public async Task<TResponse?> PostAsync<TRequest, TResponse>(string endpoint, TRequest data)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync(endpoint, data);
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadFromJsonAsync<TResponse>();
            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex, endpoint);
                return default;
            }
        }

        // POST Genérico que solo devuelve éxito/fallo
        public async Task<bool> PostAsync<TRequest>(string endpoint, TRequest data)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync(endpoint, data);
                if (response.StatusCode == System.Net.HttpStatusCode.UnprocessableEntity)
                {
                    var errorJson = await response.Content.ReadAsStringAsync();
                    _logger.LogError("Errores de validación: {errorJson}", errorJson);
                }
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex, endpoint);
                return false;
            }
        }

        private void ManejarExcepcion(Exception ex, string endpoint)
        {
            if (ex is TimeoutRejectedException)
                _logger.LogError("Timeout de Polly disparado en: {endpoint}", endpoint);
            else
                _logger.LogError("Error en ApiClient al llamar a {endpoint}: {Message}", endpoint, ex.Message);
        }
    }
}
