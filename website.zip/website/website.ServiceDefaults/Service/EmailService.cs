﻿using System.Net.Mail;
using System.Net;
using website.ServiceDefaults.Interface;

namespace website.ServiceDefaults.Service
{
    public class EmailService : IEmailService
    {
        public async Task<bool> SendEmailAsync(string to, string subject, string body)
        {
            try
            {
                var client = new SmtpClient("tu-servidor-smtp.com", 587)
                {
                    Credentials = new NetworkCredential("tu-correo@bussersa.com.ni", "tu-password"),
                    EnableSsl = true
                };
                var mailMessage = new MailMessage("web@bussersa.com.ni", to, subject, body);
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
