﻿using website.ServiceDefaults.Interface;
using website.ServiceDefaults.Models;

namespace website.ServiceDefaults.Service
{
    public class RedmineService : IRedmineService
    {
        private readonly IApiClient _apiClient;

        public RedmineService(IApiClient apiClient)
        {
            _apiClient = apiClient;
        }

        public async Task<bool> CrearSolicitudEmpleoAsync(SolicitudEmpleoModel modelo)
        {
            // Extraemos IDs de configuración para mayor flexibilidad
            var projectId = "rrhh-bs";
            var trackerId = 24;

            var peticion = new RedmineRequest
            {
                issue = new RedmineIssue
                {
                    project_id = projectId,
                    tracker_id = trackerId,
                    subject = $"Solicitud Empleo: {modelo.NombresApellidos}",
                    description = $"Candidato para el cargo: {modelo.Cargo}. \nDirección: {modelo.Direccion}",
                    custom_fields = new List<RedmineCustomField>
                    {
                        new() { id = 50, value = modelo.NombresApellidos },
                        new() { id = 36, value = modelo.Cedula },
                        new() { id = 41, value = modelo.Sexo },
                        new() { id = 56, value = modelo.EstadoCivil },
                        new() { id = 40, value = modelo.FechaNacimiento.ToShortDateString() },
                        new() { id = 38, value = modelo.Telefono },
                        new() { id = 44, value = modelo.ContactoEmergencia },
                        new() { id = 45, value = modelo.TelefonoEmergencia },
                        new() { id = 42, value = modelo.Inss },
                        new() { id = 39, value = modelo.Cargo },
                        new() { id = 43, value = modelo.LugarNacimiento }
                        // Agrega aquí los IDs que configuraste en tu Redmine de AWS
                    }
                }
            };

            return await _apiClient.PostAsync("issues.json", peticion);
        }
    }
}
