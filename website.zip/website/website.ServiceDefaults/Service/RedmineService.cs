﻿using website.ServiceDefaults.Interface;
using website.ServiceDefaults.Models;

namespace website.ServiceDefaults.Service
{
    public class RedmineService : IRedmineService
    {
        private readonly IApiClient _apiClient;

        public RedmineService(IApiClient apiClient)
        {
            _apiClient = apiClient;
        }

        public async Task<bool> CrearSolicitudEmpleoAsync(SolicitudEmpleoModel modelo)
        {
            // Extraemos IDs de configuración para mayor flexibilidad
            var projectId = "rrhh-bs";
            var trackerId = 24;
            List<RedmineUpload> listaAdjuntos = new();
            // PASO 1: Si hay un archivo, subirlo primero
            if (modelo.ArchivoCV != null && modelo.ArchivoCV.Length > 0)
            {
                // El ApiClient debe tener un método que acepte byte[] y devuelva el token
                var uploadResponse = await _apiClient.UploadFileAsync(modelo.ArchivoCV, modelo.NombreArchivoCV!);

                if (uploadResponse != null)
                {
                    listaAdjuntos.Add(new RedmineUpload
                    {
                        token = uploadResponse,
                        filename = modelo.NombreArchivoCV ?? "CV_Candidato.pdf",
                        content_type = "application/pdf"
                    });
                }
            }

            var peticion = new RedmineRequest
            {
                issue = new RedmineIssue
                {
                    project_id = projectId,
                    tracker_id = trackerId,
                    subject = $"Solicitud Empleo: {modelo.NombreCompleto}",
                    description = BuildDescription(modelo),
                    uploads = listaAdjuntos.Any() ? listaAdjuntos : null,
                    custom_fields = new List<RedmineCustomField>
                    {
                        new() { id = 50, value = modelo.NombreCompleto },
                        new() { id = 36, value = modelo.Cedula },
                        new() { id = 41, value = modelo.Sexo },
                        new() { id = 56, value = modelo.EstadoCivil },
                        new() { id = 40, value = modelo.FechaNacimiento.ToString("yyyy-MM-dd") },
                        new() { id = 38, value = modelo.Telefono },
                        new() { id = 44, value = modelo.ContactoEmergencia },
                        new() { id = 45, value = modelo.TelefonoEmergencia },
                        new() { id = 42, value = modelo.NumeroInss??"" },
                        new() { id = 43, value = modelo.LugarNacimiento },
                        new() { id = 37, value = modelo.Direccion }
                        // Agrega aquí los IDs que configuraste en tu Redmine de AWS
                    }
                }
            };

            return await _apiClient.PostAsync("issues.json", peticion);
        }

        public async Task<bool> CrearTicketContactoAsync(FormularioContacto modelo)
        {
            // Configuraciones para Contacto (pueden ser distintas a RRHH)
            var projectId = "contabilidad"; // ID de tu proyecto comercial en Redmine
            var trackerId = 25; // Tracker de "Soporte" o "Tarea"

            var peticion = new RedmineRequest
            {
                issue = new RedmineIssue
                {
                    project_id = projectId,
                    tracker_id = trackerId,
                    subject = $"PROSPECTO: {modelo.Empresa}",
                    description = $"Solicitud técnica recibida desde la web:\n\n" +
                                  $"Unidad de Interés: {modelo.ServicioInteres}\n" +
                                  $"Mensaje: {modelo.Mensaje}",
                    custom_fields = new List<RedmineCustomField>
                    {
                        // Ejemplo: IDs de campos personalizados para ventas
                        new() { id = 124, value = modelo.Nombre },
                        new() { id = 125, value = modelo.Email },
                        new() { id = 126, value = modelo.Telefono },
                        new() { id = 127, value = modelo.Empresa }
                    }
                }
            };

            return await _apiClient.PostAsync("issues.json", peticion);
        }

        // Método auxiliar para mantener limpio el objeto principal
        private string BuildDescription(SolicitudEmpleoModel m) =>
            $"Candidato para el área: {m.AreaInteres}\n" +
            $"Para el cargo de: {m.Cargo}\n" +
            $"Habilidades: {m.Habilidades}\n";
    }
}
