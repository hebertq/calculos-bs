﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace website.ServiceDefaults.ApiContract
{
    // Respuesta que nos da Redmine al subir el archivo
    public class RedmineUploadResponse
    {
        public UploadDetail upload { get; set; } = new();
    }

    public class UploadDetail
    {
        public string token { get; set; } = string.Empty;
    }
}
