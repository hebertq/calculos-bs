﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using website.ServiceDefaults.Interface;
using website.ServiceDefaults.Policies;
using website.ServiceDefaults.Service;
using website.ServiceDefaults.Service.Generic;

namespace website.ServiceDefaults
{
    public static class ConfigureServices
    {
        /// <summary>
        /// Adds all the dependency injection of the services used in the Application Layer
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddApplicationServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IEmailService, EmailService>();
            services.AddScoped<IRedmineService, RedmineService>();
        
            // 2. Registro del ApiClient con HttpClientFactory y Resiliencia
            services.AddHttpClient<IApiClient, ApiClient>(client =>
            {
                // Usamos la configuración pasada por parámetro
                var baseUrl = configuration["Redmine:BaseUrl"] ?? throw new Exception("Redmine BaseUrl no configurada");
                var apiKey = configuration["Redmine:ApiKey"] ?? throw new Exception("Redmine ApiKey no configurada");

                client.BaseAddress = new Uri(baseUrl);
                client.DefaultRequestHeaders.Add("X-Redmine-API-Key", apiKey);
            })
            // Inyectamos el Pipeline de Resiliencia de Polly v8
            .AddResilienceHandler("redmine-pipeline", builder =>
            {
                ResiliencePolicyFactory.ConfigureBussersaResilience(builder);
            });
            return services;
        }
    }
}
