﻿using Polly;
using System.Net;

namespace website.ServiceDefaults.Policies
{
    public static class ResiliencePolicyFactory
    {
        public static void ConfigureBussersaResilience(ResiliencePipelineBuilder<HttpResponseMessage> builder)
        {
            builder
                .AddRetry(new Polly.Retry.RetryStrategyOptions<HttpResponseMessage>
                {
                    // Reintenta en errores 5xx o 408 (Timeout)
                    ShouldHandle = new PredicateBuilder<HttpResponseMessage>()
                        .Handle<HttpRequestException>()
                        .HandleResult(r => r.StatusCode >= HttpStatusCode.InternalServerError || r.StatusCode == HttpStatusCode.RequestTimeout),
                    MaxRetryAttempts = 3,
                    BackoffType = DelayBackoffType.Exponential,
                    UseJitter = true, // Evita que todos los reintentos golpeen AWS al mismo tiempo
                    Delay = TimeSpan.FromSeconds(2)
                })
                .AddTimeout(TimeSpan.FromSeconds(15)); // Timeout total por intento
        }
    }
}
