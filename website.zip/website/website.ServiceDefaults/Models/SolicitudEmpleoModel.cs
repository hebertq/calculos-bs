﻿using System.ComponentModel.DataAnnotations;

namespace website.ServiceDefaults.Models
{
    public class SolicitudEmpleoModel
    {
        [Required(ErrorMessage = "El nombre es obligatorio")]
        public string NombreCompleto { get; set; } = string.Empty;

        [Required(ErrorMessage = "La cédula es requerida")]
        public string Cedula { get; set; } = string.Empty;

        public string? NumeroInss { get; set; }
        public DateTime FechaNacimiento { get; set; } = DateTime.Today.AddYears(-18);
        public string Sexo { get; set; } = "Hombre";
        public string EstadoCivil { get; set; } = "Soltero(a)";
        [Required(ErrorMessage = "El municipio de recidencia es requerido")]
        public string LugarNacimiento { get; set; } = string.Empty;

        [Required(ErrorMessage = "La dirección es necesaria para contactarle")]
        public string Direccion { get; set; } = string.Empty;

        [Required(ErrorMessage = "Por favor, detalle sus habilidades técnicas o profesionales")]
        [MinLength(10, ErrorMessage = "Sea más específico en sus habilidades (mínimo 10 caracteres)")]
        public string Habilidades { get; set; } = string.Empty;

        [Required(ErrorMessage = "El teléfono es vital para contactarle")]
        [RegularExpression(@"^\d{4}-\d{4}$", ErrorMessage = "El formato debe ser 0000-0000")]
        public string Telefono { get; set; } = string.Empty;
        public string Cargo { get; set; } = "Operador de almacen";
        public string AreaInteres { get; set; } = "CEDI General";
        public string ContactoEmergencia { get; set; } = string.Empty;
        public string TelefonoEmergencia { get; set; } = string.Empty;
        public byte[]? ArchivoCV { get; set; }
        public string? NombreArchivoCV { get; set; }
    }

    // Estructura que requiere el JSON de Redmine
    public class RedmineRequest
    {
        public RedmineIssue issue { get; set; } = new();
    }

    public class RedmineIssue
    {
        public string project_id { get; set; } = "";
        public int tracker_id { get; set; }
        public string subject { get; set; } = "";
        public string description { get; set; } = "";
        public List<RedmineUpload>? uploads { get; set; }
        public List<RedmineCustomField> custom_fields { get; set; } = new();
    }

    public class RedmineCustomField
    {
        public int id { get; set; }
        public string value { get; set; } = "";
    }

    public class RedmineUpload
    {
        public string token { get; set; } = "";
        public string filename { get; set; } = "";
        public string content_type { get; set; } = "application/pdf";
    }
}
