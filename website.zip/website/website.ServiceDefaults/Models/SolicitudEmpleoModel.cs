﻿namespace website.ServiceDefaults.Models
{
    public class SolicitudEmpleoModel
    {
        public string NombresApellidos { get; set; } = "";
        public string Cedula { get; set; } = "";
        public string Direccion { get; set; } = "";
        public string Telefono { get; set; } = "";
        public string Cargo { get; set; } = "";
        public DateTime FechaNacimiento { get; set; } = DateTime.Now.AddYears(-20);
        public string Sexo { get; set; } = "Hombre";
        public string Inss { get; set; } = "";
        public string LugarNacimiento { get; set; } = "";
        public string ContactoEmergencia { get; set; } = "";
        public string TelefonoEmergencia { get; set; } = "";
        public string TallaCamisa { get; set; } = "M";
        public string TallaCinturon { get; set; } = "M";
        public string TallaZapatos { get; set; } = "";
        public string EstadoCivil { get; set; } = "Soltero(a)";
    }

    // Estructura que requiere el JSON de Redmine
    public class RedmineRequest
    {
        public RedmineIssue issue { get; set; } = new();
    }

    public class RedmineIssue
    {
        public string project_id { get; set; } = "";
        public int tracker_id { get; set; }
        public string subject { get; set; } = "";
        public string description { get; set; } = "";
        public List<RedmineCustomField> custom_fields { get; set; } = new();
    }

    public class RedmineCustomField
    {
        public int id { get; set; }
        public string value { get; set; } = "";
    }
}
