﻿namespace website.ServiceDefaults.Interface
{
    public interface IApiClient
    {
        Task<TResponse?> GetAsync<TResponse>(string endpoint);
        Task<TResponse?> PostAsync<TRequest, TResponse>(string endpoint, TRequest data);
        Task<bool> PostAsync<TRequest>(string endpoint, TRequest data);
        Task<string?> UploadFileAsync(byte[] fileBytes, string fileName);
    }
}
