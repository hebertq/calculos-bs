﻿using website.ServiceDefaults.Models;

namespace website.ServiceDefaults.Interface
{
    public interface IRedmineService
    {
        Task<bool> CrearSolicitudEmpleoAsync(SolicitudEmpleoModel modelo);
    }
}
