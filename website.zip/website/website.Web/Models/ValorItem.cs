namespace website.Web.Models
{
    public class ValorItem
    {
        public string Titulo { get; set; } = string.Empty;
        public string Icono { get; set; } = string.Empty;
        public string Desc { get; set; } = string.Empty;
    }
}
