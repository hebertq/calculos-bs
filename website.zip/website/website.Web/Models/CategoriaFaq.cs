// Estructuras de datos para el manejo din�mico
public class CategoriaFaq
{
    public string Nombre { get; set; }
    public string Icono { get; set; }
    public string IdAcordeon { get; set; }
    public List<FaqItem> Preguntas { get; set; }
}

// Clase interna para manejar los datos
public class FaqItem
{
    public int Id { get; set; }
    public string Icono { get; set; }
    public string Pregunta { get; set; }
    public string Respuesta { get; set; }
}

