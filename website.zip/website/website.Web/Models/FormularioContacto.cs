using System.ComponentModel.DataAnnotations;
namespace website.Web.Models // Aseg�rate que el namespace coincida con tu proyecto
{
    public class FormularioContacto
    {
        [Required(ErrorMessage = "El nombre es obligatorio")]
        [StringLength(50, ErrorMessage = "Nombre demasiado largo")]
        public string Nombre { get; set; } = string.Empty;

        [Required(ErrorMessage = "La empresa es obligatoria")]
        public string Empresa { get; set; } = string.Empty;

        [Required(ErrorMessage = "El email es obligatorio")]
        [EmailAddress(ErrorMessage = "Ingrese un correo v�lido")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Seleccione un servicio de inter�s")]
        public string ServicioInteres { get; set; } = string.Empty;

        [Required(ErrorMessage = "Por favor, detalle su requerimiento")]
        [MinLength(10, ErrorMessage = "El mensaje debe ser m�s descriptivo")]
        public string Mensaje { get; set; } = string.Empty;
    }
}

