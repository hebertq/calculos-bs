namespace website.Web.Components // Aseg�rate que el namespace coincida con tu proyecto
{
    public class prueba
    {
        
    }
}
